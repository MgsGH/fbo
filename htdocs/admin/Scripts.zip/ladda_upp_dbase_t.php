<!DOCTYPE HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<!-- denna version l�gger alla dagsummor i en mysqlfil oavsett platskod 
dbasefiler ska vara kopierade till: PPMMDD.txt delimited with ; -->
<SCRIPT LANGUAGE="JavaScript">
<!-- Original: Mike Fernandez This script and many more are available free online at The JavaScript Source http://javascript.internet.com -->
function submitForm(s) {
s.value = "Data �verf�rs...";
}
</script>
<style type="text/css">
body {
font-family: Verdana, sans serif;
font-size: 11px;
color: #000080;
}
table{
font-family: Verdana, sans serif;
font-size: 11px;
color: #000080;
}
button {width: 90px; font-family: Verdana, sans-serif; font-size: 11px; background-color: #0099FF; color: #FFFFFF; border-left: 2 solid #D2EFFD; border-right: 2 solid #0066FF; border-top: 2 solid #D2EFFD; border-bottom: 2 solid #0066FF}

A {text-decoration: none}
</style>
<?php
//funktion som �vers�tter DOS-text till Windowstext - sista elementet �r en fyrkant som ers�tts med en punkt
function dostowin($text)
{
   $dos = array ("\x27", "\x86", "\x84", "\x94", "\x8F", "\x8E", "\x99", "");
   $win = array ("\x92", "\xE5", "\xE4", "\xF6", "\xC5", "\xC4", "\xD6", "\x2E");
   return str_replace($dos, $win, $text);
}
?>
</head>

<body>
<div style="width:910px; margin:auto;">
<b>LADDA UPP FILER TILL HEMSIDAN.</b><br>
H�r laddar man uppdateringar till hemsidan. V�lj aktuell uppdatering nedan och fyll sedan i namnet p� den fil som skall laddas. 
Dessa filer har skapats vid inmatning/sammanr�kningar i dBASE och ligger i mappen 
C:\dbase4\konv.<br>
<?php
if (!empty($_REQUEST['Filen']))
{setlocale(LC_ALL, 'sve');
$filen=$_REQUEST['Filen'];
 if (file_exists ('dbkonv/'.$filen) && !empty($_REQUEST['filtyp']))
 {$konv_fil = file('dbkonv/'.$filen);
  switch ($_REQUEST['filtyp'])
  {
  case 'rmdagsum':
  $dbfields='(P, DATUM, SNR, ART, SUMMA)';
  $falt1='P';
  $falt2='DATUM';
  $sokstr1=substr($filen,0,2);
  $sokstr2=date('Y').'-'.substr($filen,2,2).'-'.substr($filen,4,2);
  if ($sokstr1=='FA' || $sokstr1=='FB' || $sokstr1=='FC' || $sokstr1=='�V' || $sokstr1=='PU')
  {$dbtabell='rmdagsum';}
  else
  {$dbtabell='ovda2sum';}
  break;
  case 'rastsum':
  $dbtabell='rastbas'; 
  $dbfields='(YEAR, VE, SNR, ART, KANAL, BLACK, ANGSN, NABMA, SLALH, REVLA, KNOSE, SUMMA)'; 
  $falt1='YEAR';
  $falt2='VE';
  $sokstr1=date('Y');
  $sokstr2=substr($filen,4,2);
  break;

  case 'strtemp':
  $dbtabell='strtemp'; 
  $dbfields='(P, DATUM, SNR, ART, SUMMA)';
  $falt1='P';
  $falt2='DATUM';
  $sokstr1='DS';
  $sokstr2=date('Y').'-'.substr($filen,2,2).'-'.substr($filen,4,2);
  break;
  
  case 'stdagsum':
  $dbtabell='Sddagsum'; 
  $dbfields='(P, DATUM, SNR, ART, SUMMA)';
  $falt1='P';
  $falt2='DATUM';
  $sokstr1='SD';
  $sokstr2=substr($filen,3,4).'-08-11';
  break;
  
  case 'st_trend':
  $dbtabell='St_trend'; 
  $dbfields='(P, YEAR, SNR, ART, SUMMA)';
  $falt1='P';
  $falt2='YEAR';
  $sokstr1='ST';
  $sokstr2=substr($filen,3,4).'-08-11';
  break;
  } 
  //anslut databas
  $connect = mysqli_connect('cpsrv04.misshosting.com', 'hkghbhzh_persona', '03nanth3', 'hkghbhzh_fbodata')
  or die (mysqli_error($connect));
  //h�r ska en kontroll om filen redan �r inmatad utf�ras
  $sql=("select * from $dbtabell where $falt1='$sokstr1' and $falt2='$sokstr2'");
  $query=mysqli_query($connect, $sql) or die (mysqli_error($connect));
  if (mysqli_num_rows($query)>0)
  {echo '<p><b>OBS. Data f�r '.$falt1.'='.$sokstr1.' och '.$falt2.'='.$sokstr2.' �r redan inmatade!</b></p>
   <a href="ladda_upp_dbase_t.php">G�r om proceduren..</a>';
   //st�ng databaskopplingen 
   mysqli_close($connect);}
  else
  {foreach ($konv_fil as $text) 
   {//ta bort delimiters
   $konv_txt = str_replace(';', '', dostowin($text));
   //g�r en array av textstr�ngen
   $konv_arr = explode (',',trim($konv_txt));
   if ($_REQUEST['filtyp']=='rastsum')
    {$add_DATA = "INSERT INTO $dbtabell() 
    VALUES ('$konv_arr[0]', '$konv_arr[1]', '$konv_arr[2]', '$konv_arr[3]', '$konv_arr[4]', '$konv_arr[5]',
    '$konv_arr[6]', '$konv_arr[7]', '$konv_arr[8]', '$konv_arr[9]', '$konv_arr[10]', '$konv_arr[11]')";
    mysqli_query($connect, $add_DATA);}
   else
    {$add_DATA = "INSERT INTO $dbtabell() 
    VALUES ('$konv_arr[0]', '$konv_arr[1]', '$konv_arr[2]', '$konv_arr[3]', '$konv_arr[4]')";
    mysqli_query($connect, $add_DATA);}
   }
  //st�ng databaskopplingen 
  mysqli_close($connect);
  switch ($_REQUEST['filtyp'])
  {
  case 'rmdagsum':
  file_put_contents ('senaste_dag.txt', $filen);
  break;
  case 'rastsum':
  file_put_contents ('senaste_rast.txt', $filen);
  break;
  case 'strtemp':
    file_put_contents ('senaste_prel.txt', $filen);
  break;
  case 'stdagsum':
  file_put_contents ('senaste_str.txt', $filen);
  break;
  case 'st_trend':
  file_put_contents ('senaste_trend.txt', $filen);
  break;
  }
  echo '<p><b>Klart! Filen '.$filen.' �r �verf�rd till databasen!</b><br> 
  <a href="ladda_upp_dbase_t.php">�terg� till formul�ret / �verf�r fler filer.</a>';
 }
 }
 else
  {echo '<p><b>Formul�ret �r felaktigt ifyllt.<br/> 
  Kontrollera att filval �r f�rprickat och att filnamnet har �ndelsen.txt.</b><br>
  <a href="ladda_upp_dbase_t.php">G�r om proceduren..</a>';}  
}
else
{
?>
<form name="dbtransfer" method="post" action="<?php $_SERVER['PHP_SELF'] ?>" onSubmit="return submitForm(this.Filnamn)">
<b>V�lj vilken sorts fil som ska �verf�ras:
<br>
&nbsp;</b><table width="900" border="0" cellpadding="2" bordercolor="#0099FF" style="border:1px solid #0099FF; border-collapse: collapse; padding-left:4px; padding-right:4px; padding-top:1px; padding-bottom:1px">
<tr>
<td width="20" bgcolor="#D2EFFD"><input type="radio" name="filtyp" value="rmdagsum"></td>
<td bgcolor="#D2EFFD">Ringm�rkning, dagssummor (filnamn: PPMMDD.txt d�r PP=platskod, MM=aktuell m�nad och DD=aktuell dag).</input></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>
<i>Senast �verf�rda dagssumma: </i>
<?php
if (file_exists ('senaste_dag.txt'))
 {echo '<b>'.file_get_contents('senaste_dag.txt', null).'</b>';}
?>
</td></tr> 
<tr>
<td width="20" bgcolor="#D2EFFD"><input type="radio" name="filtyp" value="rastsum"></td>
<td bgcolor="#D2EFFD">Rastf�gelr�kning (filnamn: RFRVVV.txt d�r VV=aktuell vecka).</input></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>
<i>Senast �verf�rda rastr�kning: </i>
<?php
if (file_exists ('senaste_rast.txt'))
 {echo '<b>'.file_get_contents('senaste_rast.txt', null).'</b>';}
?>
</td></tr>
<tr>
<td width="20" bgcolor="#D2EFFD"><input type="radio" name="filtyp" value="strtemp"></td>
<td bgcolor="#D2EFFD">Str�ckr�kning, prelimin�ra dagssummor fr�n p�g�ende s�song (filnamn: 
DSMMDD.txt d�r MM=aktuell m�nad och DD=aktuell dag).</input></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>
<i>Senast �verf�rda prelimin�ra dagssumma: </i>
<?php
if (file_exists ('senaste_prel.txt'))
 {echo '<b>'.file_get_contents('senaste_prel.txt', null).'</b>';}
?>
</td></tr>
<tr>
<td width="20" bgcolor="#D2EFFD"><input type="radio" name="filtyp" value="stdagsum"></td>
<td bgcolor="#D2EFFD">Str�ckr�kning, dagssummor (filnamn: STD����.txt d�r ����=aktuellt 
�r). OBS. �VERF�RS �RSVIS EFTER NK:s JUSTERINGAR</input></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>
<i>Senast �verf�rda dagssummor (�rtal): </i> 
<?php
if (file_exists ('senaste_str.txt'))
 {echo '<b>'.file_get_contents('senaste_str.txt', null).'</b>';}
?>
</td></tr>
<tr>
<td width="20" bgcolor="#D2EFFD"><input type="radio" name="filtyp" value="st_trend"></td>
<td bgcolor="#D2EFFD">Str�ckr�kning, s�songsssummor (filnamn: STREND��.txt d�r ��=aktuellt �r).
OBS. �VERF�RS �RSVIS EFTER NK:s JUSTERINGAR</input></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>
<i>Senast �verf�rda s�songsssummor (�rtal): </i> 
<?php
if (file_exists ('senaste_str.txt'))
 {echo '<b>'.file_get_contents('senaste_trend.txt', null).'</b>';}
?>
</td></tr>
</table>
<p> Ange filnamn: 
<input type="text" size="12" name="Filen" style="border-left: 1px solid #0066CC; border-right: 1px solid #99CCFF; border-top: 1px solid #0066CC; border-bottom: 1px solid #99CCFF"><br>
<br>
Skicka till databas <input name="Filnamn" type="submit" value="Skicka" 
style="color: #FFFFFF; font-size: 11px; font-weight: bold; font-family: Verdana; 
border-left: 2px solid #99CCFF; border-right: 2px solid #0066CC; 
border-top: 2px solid #99CCFF; border-bottom: 2px solid #0066CC; 
margin-top: 0; margin-bottom: 0; background-color: #0099FF">&nbsp
�ndra/Radera <input name="tabort" type="reset" value="Radera"
style="color: #FFFFFF; font-size: 11px; font-weight: bold; font-family: Verdana; 
border-left: 2px solid #99CCFF; border-right: 2px solid #0066CC; 
border-top: 2px solid #99CCFF; border-bottom: 2px solid #0066CC; 
margin-top: 0; margin-bottom: 0; background-color: #0099FF">
</form>
<?php
}
?>
</div>
</body>
</html>