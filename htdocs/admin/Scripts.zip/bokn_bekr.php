<?php
require_once "../incl_filer/db_connect.php"; //databasanslutning
setlocale(LC_TIME, 'swedish');
$idag=date("Y-m-d");
$idnr=$_REQUEST['id']; //ska skickas som GET vid knapptryckning visa boknbekr.
$sql_bb="Select * from guidebokning WHERE G_ID='$idnr'";
$query_bb=mysqli_query($connect, $sql_bb) OR DIE (mysqli_error($connect));
while ($row=mysqli_fetch_assoc($query_bb))
{//hämta data - alltid bara en post
 $grupp=$row['Grupp'];
 $gatuadr=$row['G_gatuadr'];
 $ponr=$row['G_postnr'];
 $town=$row['G_ort'];
 $best=$row['Best_namn'];
 $btel_1=$row['Best_tel1'];
}
$sql_bt="Select * from besokstider WHERE G_ID='$idnr' AND Datum>'$idag' ORDER by Datum,Tid";
$query_bt=mysqli_query($connect, $sql_bt) OR DIE (mysqli_error($connect));
$ant_bokn=mysqli_num_rows($query_bt);
?>
<html>

<head>
<meta http-equiv="Content-Language" content="sv">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="printmall.css" media="print"> 
<title>Bokningsbekräftelse</title>
<style type="text/css">
body, table
{
font-family: Arial;
font-size: 14px;
}
button 
{width: 90px;
 font-family: Verdana, sans-serif; 
 font-size: 11px; font-weight: bold; 
 background-color: #5981D2; color: #FFFFFF; 
 border-left: 2 solid #BECCEE; 
 border-right: 2 solid #315EBB; 
 border-top: 2 solid #BECCEE; 
 border-bottom: 2 solid #315EBB;
}
input.submit
{font-family: Verdana, sans-serif; 
 font-size: 11px; font-weight: bold; 
 background-color: #5981D2; color: #FFFFFF; 
 border-left: 2 solid #BECCEE; 
 border-right: 2 solid #315EBB; 
 border-top: 2 solid #BECCEE; 
 border-bottom: 2 solid #315EBB;
}
</style>
</head>

<body>
<div align="center" id="knapp" name="knapp" > 
Kolla att nedanstående uppgifter är riktiga.<br>
Skriv ut på papper eller till pdf (välj Adobe pdf som skrivare).<br>
<form name="skriv ut" style="margin-top:6">
<input type="button" value="Skriv ut" onClick="window.print();" class="submit"
 onMouseOver="this.style.color='blue'" 
 onMouseOut="this.style.color='#FFFFFF'">
&nbsp;
<button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color='blue'" 
 onMouseOut="this.style.color='#FFFFFF'">Tillbaka</button>
</form>
</div>
<div align="center">
<table width=660>
<tr>
<td valign="top" width="98">
<img border="0" src="bilder/fbodekal_87x138.jpg" width="87" height="138"></td>
<td width="479" valign="top"><font FACE="Arial">
<p align="center"><b><font size="3">BOKNINGSBEKRÄFTELSE FÖR GUIDNING<br>
VID FALSTERBO FÅGELSTATION</font></b></p>
<p align="center" style="margin-top:6px; margin-bottom:6px"><b><font size="3">
<?php echo $grupp.'<br>'.$gatuadr.', '.$ponr.' '.$town; ?></font></b></p>
<p align="center" style="margin-top:6px; margin-bottom:6px">
Kontaktperson: <b><?php echo $best.', '.$btel_1; ?></b></p>
</td>
<td width="83" align="right"><font style="font-size:10px">I samarbete med:</font>
<p style="margin-top:10; margin-bottom:10"><img border="0" src="bilder/sfrlogoh48px.jpg" width="83" height="48"></p>
<p style="margin-top:10; margin-bottom:10"><img border="0" src="bilder/vellinge83px.jpg" width="83" height="55"></p>
</td>
</tr>
<tr><td colspan="3" valign="top">
<p>Vi har bokat följande tid(er):
<?php
echo '<table width="335" style="cell-padding:3px; border-collapse: collapse;">
<tr height="21">
<td colspan="2">Dag</td><td width="5">&nbsp;</td><td width="90">Månad</td><td width="60">År</td><td width="40">Kl.</td>
<td width="50" align="right">Antal</td></tr>';
while ($row=mysqli_fetch_assoc($query_bt))
{$timestamp = strtotime($row['Datum']); 
 $veckodag=ucfirst(strftime('%A', $timestamp));  
 $dato=strftime('%d', $timestamp);
 if (substr($dato,0,1)==0)
 {$dato=substr($dato,1,1);}
 $manad=strftime('%B', $timestamp);
 $artal=strftime('%Y', $timestamp);
 
 echo '<tr height="21"> 
 <td width="65"><b><font size="3">'.$veckodag.'</font></b></td>
 <td width="25" align="right"><b><font size="3">'.$dato.'</font></b></td>
 <td width="5">&nbsp;</td>
 <td width="90"><b><font size="3">'.$manad.'</font></b></td>
 <td width="60"><b><font size="3">'.$artal.'</font></b></td>
 <td width="40"><b><font size="3">'.$row['Tid'].'</font></b></td>
 <td width="50" align="right"><b><font size="3">'.$row['G_antal'].'</font></b></td></tr>';
} 
echo '</table>';
?>
</p>
<!-- nya texten börjar HÄR-->
<p><span style="font size:16 px"><b>Guidningarna äger rum vid Falsterbo fyr </b></span>(se kartan på sid. 2.)<br>
Parkera på P-platsen vid Kolabacken (Fyrvägens slut). 
Observera att s.k. dragspelsbussar inte får köra in på Fyrvägen (vändplats saknas).<br>
Gå sedan i samlad trupp på grusvägen över golfbanan ut 
till fyren. Se upp för golfbollar! Greener och sandbunkrar på golfbanan får ej 
beträdas.<br>
<b>Vänta utanför Fyrträdgården vid grinden på sjösidan</b>, tills er guide möter upp.</p>

<p><span style="font size:16 px"><b>Fångstnät</b></span><br>
Fåglarna fångas i tunna nät som finns uppsatta vid buskagen i och omkring fyrträdgården. 
Näten vittjas en gång i halvtimmen av fågelstationens personal.<br>
<b>Gå aldrig fram till näten</b>, vare sig det finns fågel i dem eller ej.</p>
<p><b><font size="3">Lämplig utrustning</font></b><br>
Det blåser ofta vid Falsterbo och vinden kyler! Ta därför med varma kläder 
och regnplagg. En kikare kan vara bra att ha med sig.</p>

<p><span style="font size:16 px"><b>Det är viktigt att ni kommer på den överenskomna tiden!</b></span><br>
Vid förseningar ber vi er att snarast ta kontakt på tel. 040-473703 eller 
0705-685810 (Sophie Ehnbom). 
Ofta finns ofta fler inbokningar efter er. Hela dagsschemat med guidningar kan därför bli 
förskjutet om ni inte kommer på utsatt tid.</p>

<p><span style="font size:16 px"><b>Betalning</b></span><br>
Pris: 50 kr/person. Minimiavgift: 500kr.<br>
Avgiften kan betalas via kontantkort, Swish eller mot faktura, som ni får vid besöket.</p>

<p><span style="font size:16 px"><b>Avbokning></b></span><br>
Om ni av någon anledning inte kan komma, måste ni snarast avboka guidningen.
Utebliven avbokning debiteras med en minimiavgift (500 kr).
</p>
<p>&nbsp;</p>
<p><b><font size="3">VÄLKOMNA!<br>
</font></b><br>
Sophie Ehnbom, guideansvarig</p>
<p>&nbsp;</p>
<p><b>Nästa sida: Så hittar ni till Falsterbo fyr.</b></p>
<hr style="border: 1px solid #000000">
<table width="100%" border="0" cell-spacing="0">
<tr>
<td width="281" valign="top">Adress:<br>
Fyrvägen 35<br>
239 40 FALSTERBO</td>
<td width="242" valign="top">
Telefon:<br>
040-473703 </td>
<td width="117" valign="top">
e-post:<br>
falsterbo@skof.se</td>
</tr>
</table>
</div>
<br style="page-break-after:always;">
<div align="center" id="printmap" name="printmap">
<p>Sidan 2.</p>
<p><span style="font-size:14px">SÅ HÄR HITTAR NI TILL FALSTERBO FYR</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center">
<img border="0" src="bilder/guidekarta_m_stigar_w.jpg" width="510" height="554"></p>
<p align="center">
Gul markering: Promenadväg<br>
Orange markering: Promenad- eller körväg</p>
<p align="center">
<img border="0" src="bilder/p-plats.jpg" width="30" height="30" align="middle" 
hspace="5">&nbsp; Parkeringsplats&nbsp;&nbsp;&nbsp;&nbsp; <img border="0" 
src="bilder/wc.jpg" width="30" height="30" align="middle" hspace="5"> Toalett&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img border="0" src="bilder/busshållplats.jpg" width="32" height="31" 
align="middle" hspace="5"> Busshållplats, Skånetrafiken</p>
</div>
</body>
</html>