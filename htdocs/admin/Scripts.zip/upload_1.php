<?php
/*
Mycket enkelt upload-script av jostor.
F�r anv�ndas fritt.
Ska fungera p� alla PHP-versioner �ver 4.1.0,
och p� de flesta system.
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Ladda upp en fil</title>
<link rel="stylesheet" type="text/css" href="../bluemall.css">
</head>

<body style="background: #F2F5FF">
<?php 
$arsmapp=date('Y');
// upload_dir=Mappen d�r filerna ska hamna
if (isset($_FILES['uplfile'])) 
{if ($_REQUEST['bildkat']=='dagbok')
 {$upload_dir='../news/dagbok/'.$arsmapp.'/upl_bilder/';}
 elseif ($_REQUEST['bildkat']=='schinzii')
 {$upload_dir='../research/schinzii/'.$arsmapp.'/upl_bilder/';}
 elseif ($_REQUEST['bildkat']=='galleri')
 {$upload_dir='../galleri/maxipix/';}
 elseif ($_REQUEST['bildkat']=='start')
 {$upload_dir='../galleri/midipix/';}
 elseif ($_REQUEST['bildkat']=='thumbs')
 {$upload_dir='../galleri/minipix/';}
    
 // De till�tna filtyperna, separerade med komman, utan mellanrum
	$filetypes = 'jpg,gif,png';

 // Den st�rsta till�tna storleken (500 kB)
	$maxsize = (1024*500);

 // Kontrollera att det angavs en fil
	if(empty($_FILES['uplfile']['name']))
		die('Ingen fil har valts');

 // Kontrollera storleken
	if($_FILES['uplfile']['size'] > $maxsize)
		die('Filen du valde �r f�r stor. Maxstorleken �r '.(string)($maxsize/1024).' KB.');

 // Kontrollera filtypen
	$types = explode(',', $filetypes);
	$file = explode('.', $_FILES['uplfile']['name']);
	$extension = $file[sizeof($file)-1];
	if(!in_array(strtolower($extension), $types))
		die('Du har en felaktig filtyp. Endast .jpg, .gif och .png �r till�tet!');

 //Generera unikt filnamn
 //$bokstav = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6');
   $thefile = $_FILES['uplfile']['name'];
 //while (file_exists($upload_dir.$thefile)) { $img = $bokstav[rand(0, count($bokstav)-1)].$thefile; }

 // Flytta filen r�tt
	if (is_uploaded_file($_FILES['uplfile']['tmp_name']) && move_uploaded_file($_FILES['uplfile']['tmp_name'],$upload_dir.$thefile)) 
    {
	 echo 'Filen laddades upp!';
	} 
    else 
    {
	 echo 'Ett fel uppstod och filen kunde inte laddas upp.';
	}
}
else
{
 echo '<b>Ladda upp bilder till</b> ';
 if ($_REQUEST['bildtyp']=='dagbok')
 {
  $bildtyp='dagbok';
  echo '<b>DAGBOKEN</b>';
  $bildstorlek='att den maximala bildbredden inte �verstiger 700 px.';
 }
 elseif ($_REQUEST['bildtyp']=='schinzii')
 {
  $bildtyp='schinzii';
  echo '<b>ESKILSTORPSDAGBOKEN</b>';
  $bildstorlek='att den maximala bildbredden inte �verstiger 700 px.';
 }
 elseif ($_REQUEST['bildtyp']=='galleri')
 { 
  $bildtyp='galleri';
  echo '<b>GALLERIET</b>';
  $bildstorlek='att bildstorleken b�r vara 800x438 px. Viss avvikelse (10%) kan tolereras.';
 }
 elseif ($_REQUEST['bildtyp']=='startsida')
 { 
  $bildtyp='start';
  echo '<b>STARTSIDAN</b>';
  $bildstorlek='att bildstorleken <b>m�ste</b> vara 500x300 px.';
 }
 elseif ($_REQUEST['bildtyp']=='thumbs')
 { 
  $bildtyp='thumbs';
  echo '<b>THUMBNAILS</b>';
  $bildstorlek='att bildstorleken b�r vara 170x93 px. Viss avvikelse (�10%) kan tolereras.';
 }
 echo '
 <p><b>T�nk p�:</b><br>
 att redigera bilderna innan du laddar upp dem.<br> 
 att kontrollera att uppl�sningen �r 72 dpi.<br>
 att minimera filstorleken (anv�nd &quot;Spara f�r webben&quot; i Photoshop).<br>
 att filnamnet f�r <b>inte</b> inneh�lla bokst�verna �,�,� och <b>bara sm�</b> bokst�ver.<br>
 '.$bildstorlek.'</p>
 <form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="multipart/form-data">
 <b>Ange exakt filnamn (inkl. filtyp. t.ex. skatbo.jpg):</b><br>
 <input type="file" name="uplfile" size="60" style="font-family: Verdana; font-size: 11px">&nbsp;</input><br>
 <input type="hidden" value="'.$bildtyp.'" name="bildkat"></input>
 <p>
 <input type="submit" value="Ladda upp filen" class="submit" 
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"></input>
 </p></form>';
}
?>
<p> 
<button
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'" 
onclick="javascript: window.close()">St�ng</button>
</p>
</body>
</html>