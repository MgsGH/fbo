<?php
date_default_timezone_set("CET");
include "../incl_filer/db_connect.php"; //databasanslutning 

$sql_bytnamn="SELECT * FROM  namechange, artnamn
WHERE namechange.art = artnamn.ART
ORDER BY namechange.snr";
$query_bytnamn=mysqli_query($connect, $sql_bytnamn) or die (mysqli_error($connect));

while($row=mysqli_fetch_assoc($query_bytnamn))
{echo ucfirst(mb_strtolower($row['SVNAMN'])).' <i>'.$row['LATNAMN'].'</i><br>';}

?>