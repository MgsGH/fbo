<?php 
include "../incl_filer/db_connect.php"; //databasanslutning

//data levererade från inmatningsformulär
if (isset($_REQUEST['ny_inm2']) && !empty($_REQUEST['mno2']) && !empty($_REQUEST['pubaar2'])   
&& !empty($_REQUEST['forf2']) && !empty($_REQUEST['sve_tit2']) && !empty($_REQUEST['journal2']) && !empty($_REQUEST['forf_enamn2'])
&& (!empty($_REQUEST['arter2']) || !empty($_REQUEST['artnamn2']) || !empty($_REQUEST['sokord2']) || !empty($_REQUEST['sve_sok2'])))
{
 //DIREKT INMATNING TILL HUVUDLISTAN
 $ny_num=$_REQUEST['mno2'];
 $ny_aar=$_REQUEST['pubaar2'];
 $ny_pdf=$_REQUEST['pdf2']; //måste justeras för J eller N se nedan
 $ny_forf=$_REQUEST['forf2'];
 $ny_sve_tit=$_REQUEST['sve_tit2'];
 $ny_eng_tit=$_REQUEST['eng_tit2'];
 $ny_journal=$_REQUEST['journal2'];
 //SÖKORD M.M.
 $ny_forf_enamn=$_REQUEST['forf_enamn2']; //TEXT
 $ny_befint_art=$_REQUEST['arter2']; //arter som finns, TEXT TIDIGARE ARRAY 
 $ny_art=$_REQUEST['artnamn2']; //arter som ska läggas till TEXT
 $ny_befint_sok=$_REQUEST['sokord2']; //sökord som finns TEXT TIDIGARE ARRAY
 $ny_sve_sok=$_REQUEST['sve_sok2']; //sökord som ska läggas till TEXT
 $ny_eng_sok=$_REQUEST['eng_sok2']; //sökord som ska läggas till TEXT

 //pdf finns-finns ej
 if($ny_pdf!='J')
 {
  $ny_pdf='N';
  $pdftxt='pdf finns inte.';
 }
 else
 {
  $ny_pdf='J';
  $pdftxt='pdf finns.';
 }
 //***************************************** ARTER *****************************************
 //$ny_befint_art finns i listan TEXT
 //$ny_art arter som skrivits in och ska läggas till TEXT

 if ($ny_befint_art!='' && $ny_art=='') //bara befintliga arter FUNKAR
 {
  //TA UT ENGELSKA ARTNAMN OCH LÄGG TILL I INPUT_ART
  $new_sp='';
  $array_befart=explode(',', $ny_befint_art);
  foreach($array_befart as $bef)
  {
   $VERSALART=strtoupper($bef);
   $sql_findname="select SVNAMN, ENGNAMN, LATNAMN from artnamn where SVNAMN='$VERSALART' order by SVNAMN";
   $query_findname=mysqli_query($connect, $sql_findname) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_findname))
   {
    $svnamn=strtolower($row['SVNAMN']);
    $engnamn=$row['ENGNAMN'];
    $latnamn=$row['LATNAMN']; //läggs t.v. inte i sökorden
    if ($new_sp=='')
    {
     $new_sp=$engnamn;
    }
    else
    {
     $new_sp=$new_sp.','.$engnamn;
    }
   }
  }
  $input_art_s=$ny_befint_art;
  $input_art_e=$new_sp; 
  //echo $input_art_s.'<br>'.$input_art_e;    //TESTRAD - SKA TAS BORT
 }
 elseif ($ny_befint_art=='' && $ny_art!='') //bara nya arter INSKRIVNA SOM TEXT
 {
  //lägg till de nya arterna i artlistan
  $array_art=explode(',', $ny_art);
  $new_sp='';
  foreach($array_art as $art)
  {
   $VERSALART=strtoupper($art);
   $sql_findname="select SVNAMN, ENGNAMN, LATNAMN from artnamn where SVNAMN='$VERSALART' order by SVNAMN";
   $query_findname=mysqli_query($connect, $sql_findname) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_findname))
   {
    $svnamn=strtolower($row['SVNAMN']);
    $engnamn=$row['ENGNAMN'];
    $latnamn=$row['LATNAMN'];
    $sql_laggtill_art="insert into fbomedd_arter (Sve_art, Eng_art, Lat_art) values ('$svnamn', '$engnamn', '$latnamn')";
    mysqli_query($connect, $sql_laggtill_art) or die (mysqli_error($connect));
    //echo $svnamn.' '.$engnamn.' '.$latnamn.' har lagts till i artlistan.<br>'; //TESTRAD - SKA TAS BORT
    if ($new_sp=='')
    {
     $new_sp=$engnamn;
    }
    else
    {
     $new_sp=$new_sp.','.$engnamn;
    }
   }
  }
  $input_art_s=$ny_art;
  $input_art_e=$new_sp;
  //echo $input_art_s.'<br>'.$input_art_e;    //TESTRAD - SKA TAS BORT
 }
 elseif ($ny_befint_art!='' && $ny_art!='')  //både befintliga ARRAY och nya TEXT arter
 {
  //TA UT ENGELSKA ARTNAMN OCH LÄGG TILL I INPUT_ART
  $new_sp1='';
  $array_befart=explode(',', $ny_befint_art);
  foreach($array_befart as $bef)
  {
   $VERSALART=strtoupper($bef);
   $sql_findname="select SVNAMN, ENGNAMN, LATNAMN from artnamn where SVNAMN='$VERSALART' order by SVNAMN";
   $query_findname=mysqli_query($connect, $sql_findname) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_findname))
   {
    $svnamn=strtolower($row['SVNAMN']);
    $engnamn=$row['ENGNAMN'];
    $latnamn=$row['LATNAMN']; //läggs t.v. inte i sökorden
    if ($new_sp1=='')
    {
     $new_sp1=$engnamn;
    }
    else
    {
     $new_sp1=$new_sp1.','.$engnamn;
    }
   }
  }
  //lägg till de nya arterna i artlistan
  $array_art=explode(',', $ny_art);
  $new_sp2='';
  foreach($array_art as $art)
  {
   $VERSALART=strtoupper($art);
   $sql_findname2="select SVNAMN, ENGNAMN, LATNAMN from artnamn where SVNAMN='$VERSALART' order by SVNAMN";
   $query_findname2=mysqli_query($connect, $sql_findname2) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_findname2))
   {
    $svnamn=strtolower($row['SVNAMN']);
    $engnamn=$row['ENGNAMN'];
    $latnamn=$row['LATNAMN'];
    $sql_laggtill_art="insert into fbomedd_arter (Sve_art, Eng_art, Lat_art) values ('$svnamn', '$engnamn', '$latnamn')";
    mysqli_query($connect, $sql_laggtill_art) or die (mysqli_error($connect));
    //echo $svnamn.' '.$engnamn.' '.$latnamn.' har lagts till i artlistan.<br>'; //TESTRAD - SKA TAS BORT
    if ($new_sp2=='')
    {
     $new_sp2=$engnamn;
    }
    else
    {
     $new_sp2=$new_sp2.','.$engnamn;
    }
   }
  }
  $input_art_s=$ny_befint_art.','.$ny_art;
  $input_art_e=$new_sp1.','.$new_sp2;
  //echo $input_art_s.'<br>'.$input_art_e;    //TESTRAD - SKA TAS BORT 
 }
 elseif ($_REQUEST['arter']=='' && $ny_art=='')
 {
  $input_art_s='';
  $input_art_e='';
 }
 //***************************************** SLUT ARTER FUNKAR *********************************************

 //********************************************** SÖKORD ***************************************************
 //$ny_befint_sok=sökord som finns i listan NU TEXT 
 //$ny_sve_sok=sökord som ska läggas till TEXT
 //$ny_eng_sok=sökord som ska läggas till TEXT
 if ($ny_befint_sok!='' && $ny_sve_sok=='' && $ny_eng_sok=='') //inga nya sökord
 {
  //ta ut motsv sökord ur den engelska listan
  $bef_word='';
  $array_befsok=explode(',', $ny_befint_sok);
  foreach($array_befsok as $sok)
  {
   $sql_motsv="select * from fbomedd_svsearch, fbomedd_ensearch where Svesearch='$sok' and s_id=e_id";
   $query_motsv=mysqli_query($connect, $sql_motsv) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_motsv))
   {
    $sokw=$row['Engsearch'];
    if ($bef_word=='')
    {
     $bef_word=$sokw;
    }
    else
    {
     $bef_word=$bef_word.','.$sokw;
    } 
   }
  }
  $input_sok_s=$ny_befint_sok; //inmatning till fbomeddelanden sve_search
  $input_sok_e=$bef_word; //inmatning till fbomeddelanden eng_search
  //echo $input_sok_s.'<br>'.$input_sok_e;    //TESTRAD - SKA TAS BORT      
 }
 elseif ($ny_befint_sok=='' && $ny_sve_sok!='' && $ny_eng_sok!='') //enbart nya sökord
 {
  //lägg till i den SVENSKA söklistan
  $array_ny_sve=explode(',', $ny_sve_sok);
  foreach($array_ny_sve as $sve)
  { 
   $sql_laggtill_soks="insert into fbomedd_svsearch (Svesearch) values ('$sve')";
   mysqli_query($connect, $sql_laggtill_soks) or die (mysqli_error($connect));
   //echo $sve.' har lagts till i listan med svenska sökord.<br>';
  }
  //lägg till i den ENGELSKA söklistan
  $array_ny_eng=explode(',', $ny_eng_sok);
  foreach($array_ny_eng as $eng)
  { 
   $sql_laggtill_soke="insert into fbomedd_ensearch (Engsearch) values ('$eng')";
   mysqli_query($connect, $sql_laggtill_soke) or die (mysqli_error($connect));
   //echo $eng.' har lagts till i listan med engelska sökord.<br>'; 
  }
  $input_sok_s=$ny_sve_sok; //=de som skrivits in 
  $input_sok_e=$ny_eng_sok; //=de som skrivits in 
  //echo $input_sok_s.'<br>'.$input_sok_e;    //TESTRAD - SKA TAS BORT
 }
 elseif ($ny_befint_sok!='' && $ny_sve_sok!='' && $ny_eng_sok!='') //både befintliga och nya sökord
 {
  //befintliga sökord
  //ta ut motsv sökord ur den engelska listan
  $bef_word='';
  $array_befsok=explode(',', $ny_befint_sok); 
  foreach($array_befsok as $sok)
  {
   $sql_motsv="select * from fbomedd_svsearch, fbomedd_ensearch where Svesearch='$sok' and s_id=e_id";
   $query_motsv=mysqli_query($connect, $sql_motsv) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_motsv))
   {
    $sokw=$row['Engsearch'];
    if ($bef_word=='')
    {
     $bef_word=$sokw;
    }
    else
    {
     $bef_word=$bef_word.','.$sokw;
    } 
   }
  }
  $input_sok_s1=$ny_befint_sok; //inmatning till fbomeddelanden sve_search
  $input_sok_e1=$bef_word; //inmatning till fbomeddelanden eng_search
  //echo $input_sok_s1.'<br>'.$input_sok_e1;    //TESTRAD - SKA TAS BORT 

  //nya sökord
  //lägg till i den SVENSKA söklistan
  $array_ny_sve=explode(',', $ny_sve_sok);
  foreach($array_ny_sve as $sve)
  { 
   $sql_laggtill_soks="insert into fbomedd_svsearch (Svesearch) values ('$sve')";
   mysqli_query($connect, $sql_laggtill_soks) or die (mysqli_error($connect));
   //echo $sve.' har lagts till i listan med svenska sökord.<br>';
  }
  //lägg till i den ENGELSKA söklistan
  $array_ny_eng=explode(',', $ny_eng_sok);
  foreach($array_ny_eng as $eng)
  { 
   $sql_laggtill_soke="insert into fbomedd_ensearch (Engsearch) values ('$eng')";
   mysqli_query($connect, $sql_laggtill_soke) or die (mysqli_error($connect));
   //echo $eng.' har lagts till i listan med engelska sökord.<br>'; 
  }
  $input_sok_s=$input_sok_s1.','.$ny_sve_sok; //=befintliga + de som skrivits in 
  $input_sok_e=$input_sok_e1.','.$ny_eng_sok; //=befintliga + de som skrivits in 
  //echo $input_sok_s.'<br>'.$input_sok_e;    //TESTRAD - SKA TAS BORT
 }
 else //inga sökord angivna
 {
  $input_sok_s='';
  $input_sok_e='';
 }
 //***************************************************SLUT SÖKORD*****************************************
} 
else
{
 die ('Något gick åt helvete - försök igen!');
}

if ($input_art_s=='' && $input_sok_s!='') //inga arter angivna, sökord finns
{
 $input_sve=$input_sok_s; //inmatning till fbomeddelanden sve_search
 $input_eng=$input_sok_e; //inmatning till fbomeddelanden eng_search
}
elseif ($input_art_s!='' && $input_sok_s=='') //arter angivna, sökord saknas
{
 $input_sve=$input_art_s; //inmatning till fbomeddelanden sve_search
 $input_eng=$input_art_e; //inmatning till fbomeddelanden eng_search
}
elseif ($input_art_s!='' && $input_sok_s!='') //både arter och sökord angivna
{
 $input_sve=$input_art_s.','.$input_sok_s; //inmatning till fbomeddelanden sve_search
 $input_eng=$input_art_e.','.$input_sok_e; //inmatning till fbomeddelanden eng_search
}
else //varken arter eller sökord angivna
{
 echo 'Du måste ange minst en sökvariabel. Det kan vara en art eller ett sökord.';
} 
//*********************************************UPPDATERA  HUVUDTABELLEN**********************************

$sql_final="insert into fbomeddelanden (no, author, year, title, summary, journal, pdf, sve_search, eng_search) 
values ('$ny_num', '$ny_forf', '$ny_aar', '$ny_sve_tit', '$ny_eng_tit', '$ny_journal', '$ny_pdf', '$input_sve', '$input_eng')";
mysqli_query($connect, $sql_final) or die (mysqli_error($connect));
$resultat='KLART! Nya data är inmatade utan fel.';

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 

<html lang="sv">

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta http-equiv="content-style-type" content="text/css">
<meta name="author" content="FF">
<meta name="keywords" content="">
<meta http-equiv="imagetoolbar" content="no">
<title>Adm. av publikationslistan</title>
<link rel="stylesheet" href="../bluemall.css" type="text/css">
<script type="text/javascript" LANGUAGE="JavaScript">
function fonster(URL)
{
//url är sökvägen till filen som öppnas i fönstret linkfonster
var oppna = open(URL, 'linkfonster', 'directories=no,location=no,menubar=no,status=no,toolbar=no,scrollbars=yes,resizable=yes,width=530,height=600,top=60,left=310')
}
</script>

<script type="text/javascript" language="JavaScript" src="../overlib.js">
</script>
<script type="text/javascript" language="JavaScript">
  var ol_width=100;
</script>
</head>

<body style="margin-top: 3px">
<div id="page-container2" style="margin-top:25px">
<p class="stortext_fet" align="center">Nedanstående data har nu lagts till i databasen för Falsterbomeddelanden</p>
<table width="750px" align="center" cellpadding="5px" cellspacing="0" border="0">
<?php
echo '
<tr bgcolor="#E1E8F7"><td width="200px">Meddelande nr.:</td><td width="550px">'.$ny_num.', '.$pdftxt.'</td></tr>
<tr><td>Författare:</td><td>'.$ny_forf.'</td></tr>
<tr bgcolor="#E1E8F7"><td>Status för författarlistan:</td><td>';
 //***************************** FÖRFATTARE - INMATAT SOM TEXT **************************
 $array_forf=explode(',', $ny_forf_enamn);
 foreach($array_forf as $forf)
 {//kolla om författaren finns
  //ta ut lista med författare
  $sqlval_1="Select * from fbomedd_authors where Author='$forf'";
  $query_1=mysqli_query($connect, $sqlval_1) or die (mysqli_error($connect));
  $match_1=mysqli_num_rows($query_1);
  if ($match_1==0)
  {
   $sql_laggtill_forf="insert into fbomedd_authors (Author) values ('$forf')";
   mysqli_query($connect, $sql_laggtill_forf) or die (mysqli_error($connect));
   echo $forf.' har lagts till i listan med författare.<br>';
  }
  else
  {
   while($row=mysqli_fetch_assoc($query_1))
   {echo $row['Author'].' finns redan i listan med författare.<br>';}
  }
 }
 //**********************************SLUT FÖRFATTARE FUNKAR *******************************
echo '</td></tr> 
<tr><td>Publiceringsår:</td><td>'.$ny_aar.'</td></tr>
<tr bgcolor="#E1E8F7"><td>Titel:</td><td>'.$ny_sve_tit.'</td></tr>
<tr><td>Summary:</td><td>'.$ny_eng_tit.'</td></tr>
<tr bgcolor="#E1E8F7"><td>Tidskrift:</td><td>'.$ny_journal.'</td></tr>
<tr><td>Svenska sökord:</td><td>'.$input_sve.'</td></tr>
<tr bgcolor="#E1E8F7"><td>Engelska sökord:</td><td>'.$input_eng.'</td></tr>
<tr><td>Status för artlistorna (sv+eng):</td><td>';
if (!empty($ny_art))
{echo $ny_art.' har lagts till i artlistorna.';}
else
{echo 'Ingen ny art har lagts till i listorna.';}
echo '</td></tr>
<tr bgcolor="#E1E8F7"><td>Status för söklistorna (sv+eng):</td><td>';
if (!empty($ny_sve_sok) && !empty($ny_eng_sok))
{
 echo $ny_sve_sok.' har lagts till i listan med svenska sökord<br>
 och motsvarande<br>
 '.$ny_eng_sok.' har lagts till i listan med engelska sökord.';
}
else
{
 echo 'Inga nya sökord har lagts till i listorna.';
} 
echo '</td></tr>
</table>
<p class="stortext_fet" align="center">'.$resultat.'<br>
<a href="publ_inm.php">Fler? Klicka här!</a></p>';
?>
</div>
</body>
</html>
