<?php 
include "../incl_filer/db_connect.php"; //databasanslutning 
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Ny kategori</title>
<LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
</head>

<body style="background: #F2F5FF">
<?php
if (isset($_REQUEST['nykats']))
{if ($_REQUEST['nykat']!='------ v�lj h�r ------')
 {$nykat=$_REQUEST['nykat'];
  $sqlnykat="SELECT * from kategorilista WHERE GSYSNR='$nykat'";
  $query=mysqli_query($connect, $sqlnykat) or die (mysqli_error($connect));
  while($row=mysqli_fetch_assoc($query))
  {
   $gsysnr=$row['GSYSNR'];
   $gruppnamn=$row['Gruppnamn'];
   $groupname=$row['Groupname'];
  }
 $sqlinkat="INSERT INTO	grupper (GSYSNR, Gruppnamn, Groupname)
 values ('$gsysnr', '$gruppnamn', '$groupname')";
 mysqli_query($connect, $sqlinkat) or die (mysqli_error($connect));
 echo '<span style="font-size: 11 px; color: navy">
 Gruppen '.$gruppnamn.' har lagts till bland valbara alternativ.</span>';
 $sqlutkat="DELETE FROM kategorilista WHERE GSYSNR='$gsysnr'";
 mysqli_query($connect, $sqlutkat) or die (mysqli_error($connect));
 echo '<p><span style="font-size: 11 px; color: navy">
 Gruppen '.$gruppnamn.' har bort fr�n listan �ver oanv�nda kategorier.</span>';
 }
 else
 {
 echo '<span style="font-size: 11 px; color: navy">
 Ingen kategori vald! St�ng f�nstret och g�r om proceduren.</span>';
 }
}
else
{
$sqlkat="SELECT * from kategorilista ORDER BY GSYSNR";
$query=mysqli_query($connect, $sqlkat) or die (mysqli_error($connect));
echo '<form method="POST" name="Add kategori" action="'. $_SERVER['PHP_SELF'].'">
<p><span style="font-size: 11 px; color: navy">
<b>Ny kategori</b> (v�lj fr�n listan):<br>
Den valda kategorin l�ggs till bland alternativ i galleriet och tas bort fr�n denna lista.</span> 
<p>
<select name="nykat" style="font-size: 11 px; color: navy">
<option selected>------ v�lj h�r ------</option>';
while($row=mysqli_fetch_assoc($query))
 {echo '<option value="'.$row['GSYSNR'].'">'.$row['Gruppnamn'].'</option>';}
echo '</select><br>
<p>
<input type="submit" value="Skicka" name="nykats" class="submit"
onMouseOver=this.style.color="blue" 
onMouseOut=this.style.color="#FFFFFF">
'.$row['GSYSNR'].'
</p>';
}
?>
<p>
<button
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'" 
onclick="javascript: window.close()">St�ng</button></p>
</body>
</html>
