<?php 
include "../incl_filer/db_connect_skofsales.php"; //databasanslutning
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="imagetoolbar" content="no">
<title>Formul�rresultat f�r varulager i webshopen.</title>
<LINK REL=STYLESHEET TYPE="text/css" HREF="../bluemall.css">
<script type="text/javascript" language="JavaScript" 
src="../overlib.js">
</script>
<script type="text/javascript" language="JavaScript">
<!--
 var ol_width=165; //s�tter bredden p� opuprutan
//-->
</script>
<script type="text/javascript" language="JavaScript">
function fonster(URL)
{
//url �r s�kv�gen till filen som �ppnas i f�nstret linkfonster
var oppna = open(URL, 'bildfonster', 'directories=no,location=no,menu=no,status=no,toolbar=no,scrollbars=yes,resizable=yes,width=550,height=450,top=150,left=288')
}
</script>
</head>

<body style="margin-top:10px; margin-bottom:0px; margin-left:10px; margin-right:10px;">
<div style="width:980px; margin-left:auto; margin-right:auto;">
<?php
//   *************************** �NDRA KATEGORIER *************************************
if (isset($_REQUEST['send_K10']) && !empty($_REQUEST['kfalt']))
{
 $katnum=$_REQUEST['katnum'];
 $kat_sv=$_REQUEST['katsv'];
 echo '<p align="center"><b>�ndring av varukategori - nr. '.$katnum.' '.$katsv.'.</b><p>';
 
 foreach ($_REQUEST['kfalt'] AS $id => $kfalt) 
 {$new_value=$_REQUEST['kchange'][$id];
  echo '<p align="left"><b>'.ucfirst($kfalt).' �ndrad till: '.$new_value.'</b></p>';
  $sql_upd="UPDATE sortiment SET $kfalt='$new_value' WHERE katnr='$katnum'";
  mysqli_query($connect, $sql_upd);
 }
 echo '<p align="center">
  <button style="width:300px" OnClick="location.href=\'webshop2.php\'"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka till startsidan</button></p>';
}
elseif (isset($_REQUEST['katval']) && $_REQUEST['act']=='uppdatera')
{
 $kategori=$_REQUEST['katval'];
//TA UT KATEGORIN 
 $sql_kat="SELECT * from sortiment WHERE katnr='$kategori'";
 $query_kat=mysqli_query($connect, $sql_kat) or die (mysqli_error($connect));
 while ($row=mysqli_fetch_assoc($query_kat))
 {
  $katnr=$row['katnr'];
  $kat_s=$row['kat_s'];
  $kat_e=$row['kat_e'];
  $ingr_s=$row['ingr_s'];
  $ingr_e=$row['ingr_e'];
  $bildmap=$row['bildmapp'];
  $kat_bild=$row['kat_bild'];
  $websajt=$row['websajt'];
  $txt_u_bild=$row['txt_u_bild'];
  $txt_u_pict=$row['txt_u_pict'];
 }
 
//formul�r som viar kategorins nuvarande f�ltinneh�ll: 
//INMATNINGSFORMUL�R
 echo'<form name="form_K10" method="POST" action="webshop_andra.php">
 <table width="100%" class="alt_tab_bg" cellspacing="0" cellpadding="10">
 <tr><td colspan="2" valign="top">
 <p align="center">
 <b>�NDRA I VARUKATEGORI: --- Aktuell kategori: '.$katnr.' '.$kat_s.'.</b></p>
 <p align="left"><b>Gl�m inte att bocka f�r det f�lt d�r �ndring g�rs!</b></p></td></tr>
 <tr><td colspan="2" valign="top">
 <p><input type="checkbox" style="border:0" name="kfalt[1]" value="kat_s">
 <b>Varukategori&nbsp;</b>(svensk ben�mning, t.ex. Dekaler):<br>
 <input name="kchange[1]" type="text" size="100" value="'.$kat_s.'"></input></p>
 <p><input type="checkbox" style="border:0" name="kfalt[2]" value="kat_e">
 <b>Varukategori&nbsp;</b>(engelsk ben�mning, t.ex. Stickers):<br>
 <input name="kchange[2]" type="text" size="100" value="'.$kat_e.'"></input></p>
 </td></tr>
 <tr><td width="50%" valign="top">
 <p><input type="checkbox" style="border:0" name="kfalt[3]" value="ingr_s">
 <b>Ingress f�r varukategorin&nbsp;</b>(p� svenska):<br>
 <textarea name="kchange[3]" id="spec_sv" cols="60" rows="5" wrap="virtual">'.$ingr_s.'</textarea><br>
 OBS. �ndra inte ev. html-taggar (det som st�r inom < > i texten).</p>
 </td><td width="50%" valign="top">
 <p><input type="checkbox" style="border:0" name="kfalt[4]" value="ingr_e">
 <b>Ingress f�r varukategorin&nbsp;</b>(p� engelska):<br>
 <textarea name="kchange[4]" id="spec_en" cols="60" rows="5" wrap="virtual">'.$ingr_e.'</textarea><br>
 OBS. �ndra inte ev. html-taggar (det som st�r inom < > i texten).</p>
 </td></tr>
 <tr><td width="50%" valign="top">
 <p><input type="checkbox" style="border:0" name="kfalt[5]" value="bildmapp">
 <b>Bildmapp</b>&nbsp;(ofta samma som kategorinamnet<br>men utan �, � och �):
 <input name="kchange[5]" type="text" size="12" value="'.$bildmap.'"></input></p>
 <p><input type="checkbox" style="border:0" name="kfalt[6]" value="kat_bild">
 <b>Bildnamn&nbsp;</b>(f�r vinjettbild som illustrerar kategorin inkl. filtyp,<br>
 ej �, � och �. <b>Kom ih�g att ladda upp!</b>):  
 <input name="kchange[6]" type="text" size="25" value="'.$kat_bild.'"></input></p>
 </td>
 <td width="50%" valign="top">
 <p><input type="checkbox" style="border:0" name="kfalt[7]" value="txt_u_bild">
 <b>Bildtext&nbsp;</b>(p� svenska):<br>
 <input name="kchange[7]" type="text" size="50" value="'.$txt_u_bild.'"></input></p>
 <p><input type="checkbox" style="border:0" name="kfalt[8]" value="txt_u_pict">
 <b>Bildtext&nbsp;</b>(p� engelska):<br>
 <input name="kchange[8]" type="text" size="50" value="'.$txt_u_pict.'"></input></p>
 </td></tr>
 <tr><td colspan="2" valign="top">
 <input type="hidden" name="katnum" value="'.$katnr.'"></input> 
 <input type="hidden" name="katsv" value="'.$kat_s.'"></input>
 <p align="center">
 <input name="send_K10" style="margin-top: 0; margin-bottom: 0" type="submit" value="�ndra" class="submit"
 onMouseOver="this.style.color=\'blue\'; overlib(\'<b>OBS. Skicka f�rst. Ladda upp ev. ny bild d�refter</b> Saknas bild - notera kategorins nummer, se ovan, och namn.\')" 
 onMouseOut="this.style.color=\'#FFFFFF\'; nd()">
 &nbsp;&nbsp;
 <input name="reset_K10" style="margin-top: 0; margin-bottom: 0" type="reset" value="Radera" class="submit"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">
 &nbsp;&nbsp;
 <button style="width:110px" 
 OnClick="javascript:fonster(\'upload.php?bildtyp=shop_kat&mapp='.$bildmap.'&num='.$katnr.'\')">
 <font onMouseOver="this.color=\'blue\'"
 onMouseOut="this.color=\'#FFFFFF\'">Ladda upp bild</font></button>
 &nbsp;&nbsp;
 <button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>
 </td></tr>
 </table>
 </form>';
}

//    ************************* �NDRA VAROR *************************************
elseif (isset($_REQUEST['spara']) && isset($_REQUEST['falt']) && $_REQUEST['act']=='uppdatera')
{
 $vara=$_REQUEST['artnum'];
 $kategori=$_REQUEST['katnum']; //gamla kategorin
 $oldmap=$_REQUEST['bildmap_old'];
 echo '<p align="center"><b>�ndring av varufakta - artikel nr. '.$vara.'.</b></p>';
 foreach ($_REQUEST['falt'] AS $id => $falt) 
 {$new_value=$_REQUEST['change'][$id];
  echo '<p align="left"><b>'.ucfirst($falt).' �ndrad till: '.$new_value.'</b></p>';
  $sql_upd="UPDATE varor SET $falt='$new_value' WHERE artnr='$vara'";
  mysqli_query($connect, $sql_upd);
//FLYTTA BILDER VID KATEGORIBYTE
  $sql_nykat="SELECT varor.katnr, kat_s, bildmapp from varor, sortiment 
  WHERE artnr='$vara' AND varor.katnr=sortiment.katnr";
  $query_nykat=mysqli_query($connect, $sql_nykat) or die (mysqli_error($connect));
  if (mysqli_num_rows($query_nykat)>0)
  {while ($row=mysqli_fetch_assoc($query_nykat))
   {
    $newkatnr=$row['katnr'];
    $katnamn=$row['kat_s'];
    $newmap=$row['bildmapp'];
   }
   if ($kategori!=$newkatnr)
   {
    $bigplace='/home/hkghbhzh/sales/bilder/'.$oldmap.'/'.$vara.'_stor.jpg';
    $bigdestination='/home/hkghbhzh/sales/bilder/'.$newmap.'/'.$vara.'_stor.jpg';
    //echo $bigplace.' '.$bigdestination.'<br>';

    $miniplace='/home/hkghbhzh/sales/bilder/'.$oldmap.'/'.$vara.'_mini.jpg';
    $minidestination='/home/hkghbhzh/sales/bilder/'.$newmap.'/'.$vara.'_mini.jpg';
    //echo $miniplace.' '.$minidestination.'<br>';

    rename ($bigplace, $bigdestination);
    rename ($miniplace, $minidestination);
    echo '<b>Bilder har flyttats till mappen f�r '.$katnamn.'.</b>';
   }
  }
 }
 echo '<p align="center">
 <button style="width:300px" OnClick="location.href=\'webshop2.php?WS1=V2&katlistaV='.$kategori.'\'"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">�ndra fler varor inom samma kategori</button></p>
 <p align="center">
 <button style="width:300px" OnClick="location.href=\'webshop2.php\'"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka till startsidan</button></p>';
}
elseif (isset($_REQUEST['send_V2']))
{
 $vara=$_REQUEST['andrlista'];
 $sql_andrvara="SELECT *, bildmapp from varor, sortiment WHERE artnr='$vara' AND varor.katnr=sortiment.katnr";
 $query_andrvara=mysqli_query($connect, $sql_andrvara) or die (mysqli_error($connect));
 while ($row=mysqli_fetch_assoc($query_andrvara))
 {$katg=$row['katnr'];
  $utgiven=$row['utg_ar'];
  $sak=$row['artikel'];
  $thing=$row['item'];
  $svespec=$row['spectext_s'];
  $engspec=$row['spectext_e'];
  $kostar=$row['pris'];
  $sveextra=$row['extra_s'];
  $engextra=$row['extra_e'];
  $bildmap=$row['bildmapp'];
 }

 echo '<table width="100%" class="alt_tab_bg" cellspacing="0" cellpadding="10">
 <tr><td colspan="2" valign="top"><p align="center"><b>�ndring av varufakta - artikel nr. '.$vara.'.</b></p>
 <p align="left"><b>Gl�m inte att bocka f�r det f�lt d�r �ndring g�rs!</b></p></td></tr>
 <form name="andra_vara" method="post" action="'.$_SERVER['PHP_SELF'].'">
 <tr><td><input type="checkbox" style="border:0" name="falt[1]" value="katnr"> <b>Flytta till kategori 10 (�ldre publ.)</b></input></td>
 <td><input name="change[1]" type="text" size="4" value="'.$katg.'"></input></td></tr>
 <tr><td><input type="checkbox" style="border:0" name="falt[2]" value="utg_ar"> <b>Utgivnings�r</b></input></td>
 <td><input name="change[2]" type="text" size="4" value="'.$utgiven.'"></input></td></tr>
 <tr><td><input type="checkbox" style="border:0" name="falt[3]" value="artikel"> <b>Ben�mning - sve</b></input></td>
 <td><input name="change[3]" type="text" size="95" value="'.$sak.'"></input></td></tr>
 <tr><td><input type="checkbox" style="border:0" name="falt[4]" value="item"> <b>Ben�mning - eng</b></input></td>
 <td><input name="change[4]" type="text" size="95" value="'.$thing.'"></td></tr>
 <tr><td><input type="checkbox" style="border:0" name="falt[5]" value="spectext_s"> <b>Specifikation sve</b></input><br>
 OBS. �ndra inte html-taggarna<br>(det som st�r inom < > i texten).</td>
 <td><textarea  name="change[5]" id="spec_s" cols="95" rows="5" wrap="virtual">'.$svespec.'</textarea></td></tr>
 <tr><td><input type="checkbox" style="border:0" name="falt[6]" value="spectext_e"> <b>Specifikation eng</b></input><br>
 OBS. �ndra inte html-taggarna<br>(det som st�r inom < > i texten).</td>
 <td><textarea name="change[6]" id="spec_s" cols="95" rows="5" wrap="virtual">'.$engspec.'</textarea></td></tr>
 <tr><td><input type="checkbox" style="border:0" name="falt[7]" value="pris"> <b>Pris</b> (decimalpunkt-ej komma!)</input></td>
 <td><input name="change[7]" type="text" size="8" value="'.$kostar.'"></input></td></tr>
 <tr><td><input type="checkbox" style="border:0" name="falt[8]" value="extra_s"> <b>Extra info sve</b></input></td>
 <td><input name="change[8]" type="text" size="95" value="'.$sveextra.'"></td></tr>
 <tr><td><input type="checkbox" style="border:0" name="falt[9]" value="extra_e"> <b>Extra info eng</b></input></td>
 <td><input name="change[9]" type="text" size="95" value="'.$engextra.'"></td></tr>
 <tr><td colspan="2">
 <p align="center">
 <input type="hidden" name="act" value="uppdatera"></input> 
 <input type="hidden" name="artnum" value="'.$vara.'"></input>
 <input type="hidden" name="katnum" value="'.$katg.'"></input>
 <input type="hidden" name="bildmap_old" value="'.$bildmap.'"></input>
 <input name="spara" type="submit" value="Uppdatera" class="submit"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"></input>
 <input name="Reset" type="reset" value="Avbryt" class="submit"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color;\'#FFFFFF\'"></input>&nbsp;
 <button style="width:130px" 
 OnClick="javascript:fonster(\'upload.php?bildtyp=shop_varor&mapp='.$bildmap.'&num='.$vara.'\')">
 <font onMouseOver="this.color=\'blue\'"
 onMouseOut="this.color=\'#FFFFFF\'">Ladda upp ny bild</font></button>&nbsp;
 <button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>
 </form></td></tr>
 </table>'; 
}
else
{
echo '<p align="center"><b>Nu blev det n�t fel n�nstans - g� tillbaka och r�tta!</b></p> 
<p align="center"><button style="width: 65px" OnClick="javascript:history.back()"
onMouseOver="this.style.color=\'blue\'" 
onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>';
}
?>
</div>
</body>
</html>
