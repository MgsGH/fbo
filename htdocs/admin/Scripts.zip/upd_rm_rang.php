<?php 
include "../incl_filer/db_connect.php"; //databasanslutning 

//OBS. MAN M�STE �NDRA �RTAL MANUELLT TILL DET �R SOM SKALL UPPDATERAS (TV� ST�LLEN)
//RESP. DET �R SOM DATA SKALL H�MTAS IFR�N (=�RET F�RE, TV� ST�LLEN)

//Lista med alla arter per platskod:
$sql_artlista="SELECT P, SNR, ART FROM rm_rang_2021 ORDER BY P, SNR";
$query_artlista=mysqli_query($connect, $sql_artlista) or die(mysqli_error($connect));

//uppdatera kommentarf�ltet f�r varje art
while ($row=mysqli_fetch_assoc($query_artlista))
{$pk=$row['P'];
 $art=$row['ART'];
 $sql_upd="UPDATE rm_rang_2021 set sv_com=(select sv_com from rm_rang_2020 where art='$art' and P='$pk' limit 1), 
 eng_com=(select eng_com from rm_rang_2020 where art='$art' and P='$pk' limit 1) where art='$art' and P='$pk'";
 mysqli_query($connect, $sql_upd) or die(mysqli_error($connect));
 echo $pk.' '.$art.' uppdaterad.<br>';
}
echo "KLART!";
?>
