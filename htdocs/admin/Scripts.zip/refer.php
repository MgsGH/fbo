<?php 
include "../incl_filer/db_connect.php"; //databasanslutning
?> 

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="imagetoolbar" content="no">
<title>Referenser</title>
<LINK REL=STYLESHEET TYPE="text/css" HREF="../bluemall.css">
<script language="javascript" type="text/javascript">
function closeWindow() 
{
window.open('','_parent','');
window.close();
}
</script> 
</head>

<body class="alt_tab_bg" style="background-image: url('')">
<p><b>Hittills f�rekommande referenser:</b></p>
<table width="580" cellpadding="0" class="alt_tab_bg" id="table_ref">
<?php
$farg='#FFFFFF';
$sql_ref="Select REF_KORT, REF_TEXT from referenser ORDER BY REF_KORT";
$query_ref=mysqli_query($connect, $sql_ref);
while($row=mysqli_fetch_assoc($query_ref))
{
if ($farg==('#FFFFFF'))
 {$farg='#E1E8F7';}
 else
 {$farg='#FFFFFF';}
echo '<tr bgcolor="'.$farg.'"><td width="80">'.$row['REF_KORT'].'</td><td width="470">'.$row['REF_TEXT'].'</td></tr>';
}
?>
</table>
<p align="center">
<button
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'" 
onclick="closeWindow();">St�ng</button></p>
</p>
</body>
</html>
