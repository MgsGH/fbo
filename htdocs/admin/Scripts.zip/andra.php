<!--DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd" -->
<html lang="sv">

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta http-equiv="content-style-type" content="text/css">
<title>Ändra dagbokstext</title>
<link rel="stylesheet" type="text/css" href="../bluemall.css">
<base target="_self">
</head>

<body>
<p align="center">Här kan du göra ändringar i dagbokstexten. Observera att 
texten även innehåller htmlkod.
</p>
<p align="center">
<?php
if (isset($_REQUEST['spara']))
 {
 file_put_contents($_REQUEST['path'], $_REQUEST['text']);
 echo '<b>Texten är sparad med ändringar.</b> 
 <p align="center">
 <button style="width:120px" onclick=location.href="javascript:window.close();">Stäng fönstret</button></a>';
 }
 else if (isset($_REQUEST['avbryt']))
 {
 echo '<b>Texten är sparad utan ändringar.</b>
 <p align="center">
 <button style="width:120px" onclick=location.href="javascript:window.close();">Stäng fönstret</button></a>';
 }
else
{$andrtext=$_REQUEST['datum'].'.txt';
$txtdir=substr($andrtext,0,4);
echo
'<form name="andform" method="POST" action="'. $_SERVER['PHP_SELF'].'">
<p align="center">
<textarea name="text" cols="75" rows="25">';
      if (isset($_POST['text']))
      {
      $FIL = fopen('../news/dagbok/'.$txtdir.'/'.$andrtext, 'w') or die('kan inte öppna filen');
      fwrite($FIL, $_POST['text']);
      fclose($FIL);
      }
      echo implode('',file('../news/dagbok/'.$txtdir.'/'.$andrtext));
echo '</textarea>
<p align="center">
<input type="hidden" name="path" value="../news/dagbok/'.$txtdir.'/'.$andrtext.'">
<input type="submit" name="spara" value="Spara ändringar" class="submit"> 
<input type="submit" name="avbryt" value="Avbryt" class="submit">
</form>';
 }
 ?>
</body>
</html>