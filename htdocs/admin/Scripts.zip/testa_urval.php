<?php

//$ny_arter='bergfink,bofink';
//$ny_art='art1,art2';
echo $ny_arter;
echo $ny_art;

if ($ny_arter!='' && $ny_art=='')
{
 $input=$ny_arter;
 echo $input;
}
elseif ($ny_arter=='' && $ny_art!='')
{
 $input=$ny_art;
 echo $input;
}
elseif ($ny_arter!='' && $ny_art!='')
{
 $input=$ny_arter.','.$ny_art;
 echo $input;
}
elseif ($ny_arter=='' && $ny_art=='')
{
 echo 'Ingen art har angetts.';
}

?>