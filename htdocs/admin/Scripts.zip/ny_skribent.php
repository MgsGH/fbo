<?php 
include "../incl_filer/db_connect.php"; //databasanslutning 
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Ny skribent</title>
<LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
</head>

<body style="background: #F2F5FF">
<?php
//Detta �r testat och fungerar!
if (isset($_REQUEST['sign']))
{if (!empty($_REQUEST['sign']))
 {//SKAPA VARIABLER
 $in_sig=$_REQUEST['sign'];
 $in_for=$_REQUEST['forn'];
 $in_las=$_REQUEST['last'];
 $in_sql="INSERT INTO signlist (sign, forname, lastname)
 values ('$in_sig', '$in_for', '$in_las')";
 mysqli_query($connect, $in_sql);
 echo '<p>Ny skribent, '.$in_for.' '.$in_las.', sign. '.$in_sig.'  har lagts till i databasen.';}
 else
 {echo 'Det gick inte att l�gga till data!';}
}
else
{
?>
<p style="font-size: 11 px; color: navy">
<form method="POST" name="Add skribent" action="ny_skribent.php">
<b>Signatur</b> (VERSALER, max 3 tecken):<br>
<input type="text" style="font-size: 11 px; color: navy" size="5" name="sign"><br>
<b>F�rnamn</b>:<br>
<input type="text" style="font-size: 11 px; color: navy" size="20" name="forn"><br>
<b>Efternamn</b>:<br>
<input type="text" style="font-size: 11 px; color: navy" size="20" name="last"><br>
<p></p><input type="submit" value="Skicka" name="ny_skr" class="submit"
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'"> &nbsp;
<?php
;}
?>
<p>
<button
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'" 
onclick="javascript: window.close()">St�ng</button></p>
</body>
</html>
