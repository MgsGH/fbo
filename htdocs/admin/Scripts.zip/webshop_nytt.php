<?php 
include "../incl_filer/db_connect_skofsales.php"; //databasanslutning
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="imagetoolbar" content="no">
<title>Formul�rresultat f�r varulager i webshopen.</title>
<LINK REL=STYLESHEET TYPE="text/css" HREF="../bluemall.css">
<script type="text/javascript" language="JavaScript" 
src="../overlib.js">
</script>
<script type="text/javascript" language="JavaScript">
<!--
 var ol_width=165; //s�tter bredden p� opuprutan
//-->
</script>
</head>

<body style="margin-top: 10px; margin-bottom: 0px; margin-left: 10px; margin-right: 10px;">
<div style="width: 980px; margin-left: auto; margin-right: auto">
<table width="100%" class="alt_tab_bg" cellspacing="0" cellpadding="10">
<tr><td colspan="2" valign="top">

<?php
// OM INMATADE DATA �R GENOML�STA OCH OK
if ($_REQUEST['ok']=='OK')
{
 echo '<p align="center">
 <span style="font-size:18px">
 *********** INMATNING TILL DATABASEN SkOF-SALES, TABELL '.$_REQUEST['tabell'].' ***********
 </span></p>'; 
// l�gg till ny post i databasen
 if ($_REQUEST['tabell']=='sortiment')
 {
  $var_k1=$_REQUEST['var_k1'];  //aktuell kategori (nummer)
  $var_k2=$_REQUEST['var_k2'];  //svensk ben�mning
  $var_k3=$_REQUEST['var_k3'];  //engelsk ben�mning 
  $var_k4=$_REQUEST['var_k4']; 	//svensk ingress 
  $var_k5=$_REQUEST['var_k5']; 	//engelsk ingress
  $var_k6=$_REQUEST['var_k6'];	//skapa bildmapp
  $var_k7=$_REQUEST['var_k7'];	//vinjettbildens namn
  $var_k8=$_REQUEST['var_k8'];	//svensk bildtext
  $var_k9=$_REQUEST['var_k9'];	//engelsk bildtext

  $sql_var="INSERT INTO sortiment (katnr, kat_s, kat_e, ingr_s, ingr_e, bildmapp, kat_bild, txt_u_bild, txt_u_pict) 
  VALUES ('$var_k1', '$var_k2', '$var_k3', '$var_k4', '$var_k5', '$var_k6', '$var_k7', '$var_k8', '$var_k9')";
  mysqli_query($connect, $sql_var) or die (mysqli_error($connect));
// skapa ny bildmapp 
  if (is_dir('../sales/bilder/'.$var_k6)==false)
  {
   mkdir ('../sales/bilder/'.$var_k6);
  } 
 }
 elseif ($_REQUEST['tabell']=='varor')
 {$var_vnr=$_REQUEST['var_vnr'];//artikelnummer
  echo $var_vnr;
  $var_v1=$_REQUEST['var_v1']; 	//aktuell kategori (nummer)
  echo $var_v1;
  $var_v2=$_REQUEST['var_v2'];  //utgivnings�r
  echo $var_v2;
  $var_v3=$_REQUEST['var_v3'];	//svensk ben�mning
  echo $var_v3;
  $var_v4=$_REQUEST['var_v4'];	//engelsk ben�mning 
  echo $var_v4;
  $var_v5=$_REQUEST['var_v5'];  //specifikation, sve
  echo $var_v5;
  $var_v6=$_REQUEST['var_v6'];	//specifikation, eng
  echo $var_v6;
  $var_v7=$_REQUEST['var_v7'];	//pris
  echo $var_v7;
  $var_v8=$_REQUEST['var_v8']; 	//extra info sve
  $var_v9=$_REQUEST['var_v9']; 	//extra info eng
  
  $sql_var="INSERT INTO varor (artnr, katnr, utg_ar, artikel, item, spectext_s, spectext_e, pris, extra_s, extra_e) 
  VALUES ('$var_vnr', '$var_v1', '$var_v2', '$var_v3', '$var_v4', '$var_v5', '$var_v6', '$var_v7', '$var_v8', 
  '$var_v9')";
  mysqli_query($connect, $sql_var) or die (mysqli_error($connect));
 }
 echo '<p align="center"><span style="font-size:18px">Inmatningen lyckades!</span></p>
 <p align="center"><button style="width:160px" 
 OnClick="location.href=\'webshop2.php\';">
 <font onMouseOver="this.color=\'blue\'"
 onMouseOut="this.color=\'#FFFFFF\'">Fler inmatningar...</font></button>
 </p>';
}
else
{
// *********** DEFINITION OCH REDIGERING AV VARIABLER ***********
 if (isset($_REQUEST['send_K1'])) // L�GG TILL NY KATEGORI
 {
  $var_x='sortiment';
// definiera variabler f�r varukategorier
  $var_k1='';
  $var_k2='';
  $var_k3='';
  $var_k4='';
  $var_k5='';
  $var_k6='';
  $var_k7='';
  $var_k8='';
  $var_k9='';

//variabler fr�n inmatningsformul�r ny kategori:
  $var_k1=$_REQUEST['kategoriny'];  	//aktuell kategori (nummer)
  $var_k2=$_REQUEST['kat_sv'];  		//svensk ben�mning
  $var_k3=$_REQUEST['kat_en'];  		//engelsk ben�mning 
  $var_k4=$_REQUEST['ingr_sv']; 		//svensk ingress 
  $var_k5=$_REQUEST['ingr_en']; 		//engelsk ingress
  $var_k6=$_REQUEST['bildmap'];		//skapa bildmapp
  $var_k7=$_REQUEST['bilden'];		//vinjettbildens namn
  $var_k8=$_REQUEST['bildtex_sv'];	//svensk bildtext
  $var_k9=$_REQUEST['bildtex_en'];	//engelsk bildtext
  
// visa data
  echo '<p align="center"><b>Ny kategori.</b></p>
  <p align="left">Du har matat in f�jande uppgifter:<br>
  Kategorinummmer: <b>'.$var_k1.'</b><br>
  Svensk ben�mning: <b>'.$var_k2.'</b><br>
  Engelsk ben�mning: <b>'.$var_k3.'</b><br>
  Svensk ingress: <b>'.$var_k4.'</b><br>
  Engelsk ingress: <b>'.$var_k5.'</b><br>
  Bildmapp: <b>'.$var_k6.'</b><br>
  Vinjettbild: <b>'.$var_k7.'</b><br>
  Svensk bildtext: <b>'.$var_k8.'</b><br>
  Engelsk bildtext: <b>'.$var_k9.'</b></p>'; 
 }
 elseif (isset($_REQUEST['send_V1']))  // L�GG TILL NY VARA
 {
  $var_x='varor';
//definiera variabler f�r varor 
  $var_vnr='';
  $var0='';
  $var00='';
  $var1='';
  $var2='';
  $var3='';
  $var33='';
  $var4='';
  $var5='';
  $var6='';
  $var7='';
  $var8='';
  $var9='';
  $var10='';
  $var11='';
  $var11s='';
  $var11e='';
  $var12s='';
  $var12e='';
  $spec_s_txt='';
  $spec_e_txt='';

//variabler fr�n inmatningsformul�r nya varor:
  $var_vnr=$_REQUEST['artikelnr'];
  $var0=$_REQUEST['kategorival'];  //aktuell kategori (nummer)
  $var00=$_REQUEST['kategoritxt']; //aktuell kategori (text)
  $var1=$_REQUEST['stitel'];       //alla artiklar
  $var2=$_REQUEST['etitel'];       //alla artiklar
  $var3=$_REQUEST['rel_year'];     //b�cker, DVD, litografier
  $var33=$_REQUEST['filmlength'];  //filmer
  $var4=$_REQUEST['spec_s'];       //alla artiklar
  $var5=$_REQUEST['spec_e'];	     //alla artiklar
  $var6=$_REQUEST['forf'];	     //b�cker
  $var6s=$_REQUEST['forf_red'];    //b�cker, litografier, vykort.
  $var7=$_REQUEST['bredd'];	     //alla utom t-tr�jor, DVD
  $var8=$_REQUEST['hojd'];         //alla utom t-tr�jor, DVD
  $var9=$_REQUEST['sidantal'];     //b�cker
  $var9s=$var9.' sidor.';
  $var9e=$var9.' pages.';
  $var10=$_REQUEST['pris'];        //alla artiklar
//specialfall 1
  $var11=$_REQUEST['inb'];         //inbundna b�cker
  if ($var11=='J')
  {
   $var11s=' Inbunden. ';
   $var11e=' Hardback. ';
  }
//extra info
  if (!empty($_REQUEST['extra_s']))
  {
//extra info finns
   $var12s='<br>'.$_REQUEST['extra_s'];    
  }
  if (!empty($_REQUEST['extra_e']))
  {
//extra info finns
   $var12e='<br>'.$_REQUEST['extra_e'];
  }

//specialfall 3
//$var14=$_Request Kikarfakta   //kikare s�rskild tabell kikarfakta

// �vers�ttning av $var6s:
  switch ($var6s)
  {
   case 'fotograf':
   $var6e='photo by'; break;
   case 'en f�rf':
   $var6s='f�rfattare';
   $var6e='author'; break;
   case 'flera f�rf':
   $var6s='f�rfattare';
   $var6e='authors'; break;
   case 'konstn�r':
   $var6e='artist'; break;
   case 'redakt�r':
   $var6e='editor'; break;
   case 'redakt�rer':
   $var6e='editors'; break;
  }
//ers�tter och med and i engelska texten
  $var6ee=str_replace('och', 'and', $var6);

// *********** SAMMANST�LLNING AV INPUT TILL DATABASEN ***********

// f�r litografier, b�cker, gamla b�cker (1,2,10) ***********************
  if ($var0==1 || $var0==2 || $var0==10)
  {
   $spec_s_txt=$var4.'<br>'.ucfirst($var6s).': '.$var6.'.<br>Utgiven: '.$var3.'. Format bxh: '.$var7.'x'.$var8.' cm. '.$var11s.$var9s;
   if ($var2<>'') //om engelsk titel finns
   {
    $var7e=str_replace(',', '.', $var7);
    $var8e=str_replace(',', '.', $var8);
    $spec_e_txt=$var5.'<br>'.ucfirst($var6e).': '.$var6ee.'.<br>Released: '.$var3.'. Size wxh: '.$var7e.'x'.$var8e.' cm. '.$var11e.$var9e;
   }
  }

// f�r dekaler, muggar, musmattor (3,4,5) ************************* 
  if ($var0==3 || $var0==4 || $var0==5)
  {
   $spec_s_txt=$var4.'<br>
   Format bxh: '.$var7.'x'.$var8.' cm.';
   if ($var2<>'') //om engelsk titel finns
   {
    $var7e=str_replace(',', '.', $var7);
    $var8e=str_replace(',', '.', $var8);
    $spec_e_txt=$var5.'<br>Size wxh: '.$var7e.'x'.$var8e.' cm.';
   }
  }

//f�r T-tr�jor (6) *************************
  if ($var0==6)
  {
   $spec_s_txt=$var4;
   if ($var2<>'') //om engelsk titel finns
   {
    $spec_e_txt=$var5;
   }
  }

//f�r vykort (7) *************************
  if ($var0==7)
  {
   $spec_s_txt=$var4.'<br>'.ucfirst($var6s).': '.$var6.'.<br>
   Format bxh: '.$var7.'x'.$var8.' cm.';
   if ($var2<>'') //om engelsk titel finns
   {
    $var7e=str_replace(',', '.', $var7);
    $var8e=str_replace(',', '.', $var8);
	$spec_e_txt=$var5.'<br>'.ucfirst($var6e).': '.$var6ee.'.<br>Size wxh: '.$var7e.'x'.$var8e.' cm.';
   }
  }
//f�r kikare (8) *************************
//************************** EJ KLART *************************

//f�r DVD-filmer (9) *************************
  if ($var0==9)
  {
   $spec_s_txt=$var4.'<br>
   Utgiven: '.$var3.'. L�ngd: '.$var33.' minuter.';
   if ($var2<>'') //om engelsk titel finns
   {
    $spec_e_txt=$var5.'<br>
    Released: '.$var3.'. Length: '.$var33.' minutes.';
   }
  }

 // visa inmatade data *************************
  echo '<p align="center"><b>Kategori '.$var0.', '.$var00.'</b></p>
  </td></tr>
  <tr><td width="50%" valign="top">
  <p>Du har matat in f�jande uppgifter:<br>
  Artikelnummer: <b>'.$var_vnr.'</b><br>
  Svensk titel: <b>'.$var1.'</b><br>
  Engelsk titel: <b>'.$var2.'</b><br>
  Utgivnings�r: <b>'.$var3.'</b><br>
  L�ngd i minuter: <b>'.$var33.'</b><br>
  Svensk spec: <b>'.$var4.'</b><br>
  Engelsk spec: <b>'.$var5.'</b><br>
  F�rfattare/konstn�r/fotograf: <b>'.$var6s.'</b><br>
  F�rfattarnamn: <b>'.$var6.'</b><br>
  Bredd: <b>'.$var7.'</b><br>
  H�jd: <b>'.$var8.'</b><br>
  Antal sidor: <b>'.$var9.'</b><br>
  Inbunden: <b>'.$var11.'</b><br>
  Pris: <b>'.$var10.'</b><br>
  Extra_sve: <b>'.$var12s.'</b><br>
  Extra_eng: <b>'.$var12e.'</b><br></p>
  </td><td width="50%" valign="top">
  <p>Texten i f�nstret som presenterar varan kommer att se ut s� h�r (under bilden);<br>
  Svensk:<br><b>
  '.$spec_s_txt.'</b></p>
  <p>'.$var12s.'</p>
  <p>Engelsk:<br><b>
  '.$spec_e_txt.'</b></p>
  <p>'.$var12e.'</p>';
 }
 echo '</td></tr>
 <tr><td colspan="2" valign="top">
 <p align="center">Om uppgifterna �r korrekta och bilder �r uppladdade alt. artikelnummer noterat, tryck OK. 
 Annars, tryck Tillbaka f�r att �ndra.&nbsp;&nbsp;';

//formul�r som �verf�r till INMATNING av kategoridata i DATABASEN
 if ($var_x=='sortiment')
 {
  echo '<form name="kat_data" method="post" action="webshop_nytt.php">
  <input name="tabell" type="hidden" value="'.$var_x.'"></input> 
  <input name="var_k1" type="hidden" value="'.$var_k1.'"></input> 
  <input name="var_k2" type="hidden" value="'.$var_k2.'"></input> 
  <input name="var_k3" type="hidden" value="'.$var_k3.'"></input> 
  <input name="var_k4" type="hidden" value="'.$var_k4.'"></input> 
  <input name="var_k5" type="hidden" value="'.$var_k5.'"></input> 
  <input name="var_k6" type="hidden" value="'.$var_k6.'"></input> 
  <input name="var_k7" type="hidden" value="'.$var_k7.'"></input> 
  <input name="var_k8" type="hidden" value="'.$var_k8.'"></input> 
  <input name="var_k9" type="hidden" value="'.$var_k9.'"></input> 
  <input name="ok" type="hidden" value="OK"></input>
  <p align="center">
  <input name="kat_data" style="margin-top: 0; margin-bottom: 0; width:80px" type="submit" value="OK" class="submit"
  onMouseOver="this.style.color=\'blue\'; overlib(\'�verf�r till databas.\');"
  onMouseOut="this.style.color=\'#FFFFFF\'; nd()"></input>
  &nbsp;&nbsp;
  ';
 } 
 elseif ($var_x=='varor')
 {
  echo '<form name="varu_data" method="post" action="webshop_nytt.php">
  <input name="tabell" type="hidden" value="'.$var_x.'"></input> 
  <input name="var_vnr" type="hidden" value="'.$var_vnr.'"></input>
  <input name="var_v1" type="hidden" value="'.$var0.'"></input> 
  <input name="var_v2" type="hidden" value="'.$var3.'"></input> 
  <input name="var_v3" type="hidden" value="'.$var1.'"></input> 
  <input name="var_v4" type="hidden" value="'.$var2.'"></input> 
  <input name="var_v5" type="hidden" value="'.$spec_s_txt.'"></input> 
  <input name="var_v6" type="hidden" value="'.$spec_e_txt.'"></input> 
  <input name="var_v7" type="hidden" value="'.$var10.'"></input> 
  <input name="var_v8" type="hidden" value="'.$var12s.'"></input> 
  <input name="var_v9" type="hidden" value="'.$var12e.'"></input> 
  <input name="ok" type="hidden" value="OK"></input>
  <p align="center">
  <input name="varu_data" style="margin-top: 0; margin-bottom: 0, width:80px" type="submit" value="OK" class="submit"
  onMouseOver="this.style.color=\'blue\'; overlib(\'�verf�r till databas.\');"
  onMouseOut="this.style.color=\'#FFFFFF\'; nd()"></input>
  &nbsp;&nbsp;
  ';
 }
 echo '<button style="width:80px" 
 OnClick="javascript:history.back()">
 <font onMouseOver="this.color=\'blue\'"
 onMouseOut="this.color=\'#FFFFFF\'">Tillbaka</font></button> 
 </p>';
}
?>
</td></tr>
</table></div>
</body>
</html>
