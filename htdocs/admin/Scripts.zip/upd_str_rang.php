<?php 
include "../incl_filer/db_connect.php"; //databasanslutning 

//OBS. MAN M�STE �NDRA �RTAL MANUELLT TILL DET �R SOM SKALL UPPDATERAS (TV� ST�LLEN)
//RESP. DET �R SOM DATA SKALL H�MTAS IFR�N (=�RET F�RE, TV� ST�LLEN)
 
//Lista med alla arter:
$sql_artlista="SELECT SNR, ART FROM str_rang_2020 ORDER BY SNR";
$query_artlista=mysqli_query($connect, $sql_artlista) or die(mysqli_error($connect));

//uppdatera kommentarf�ltet f�r varje art
while ($row=mysqli_fetch_assoc($query_artlista))
{$art=$row['ART'];
 $sql_upd="UPDATE str_rang_2020 set sv_com=(select sv_com from str_rang_2019 where art='$art' limit 1), 
 eng_com=(select eng_com from str_rang_2019 where art='$art'limit 1) where art='$art'";
 mysqli_query($connect, $sql_upd) or die(mysqli_error($connect));
 echo $art.' uppdaterad.<br>';
}
echo 'KLART!';
?>
