<?php
include "../incl_filer/db_connect.php"; //databasanslutning
$helaar=$_REQUEST['ar'];
$halvaar=$_REQUEST['sasong'];
if ($halvaar=='1')
 {$arstid='v�ren';
  $sql_tot="SELECT *, guidebokning.grupp, guidebokning.G_ort, guidebokning.Best_namn, 
  guidebokning.Best_tel1 
  from besokstider, guidebokning
  WHERE besokstider.G_ID=guidebokning.G_ID AND besokstider.G_klar='J'
  AND substring(besokstider.Datum,1,4)='$helaar'
  AND substring(besokstider.Datum,6,5)>='01-01' and substring(besokstider.Datum,6,5)<='06-30'
  ORDER BY besokstider.Datum, besokstider.Tid";
  //antal guidade
  $sql_booked="SELECT G_klar, SUM(G_antal) AS booked from besokstider  
  WHERE substring(besokstider.Datum,1,4)='$helaar' AND besokstider.G_klar='J'
  AND substr(besokstider.Datum,6,5)>='01-01' AND substr(besokstider.Datum,6,5)<='06-30'
  GROUP BY G_klar ORDER BY G_klar";
 }
 else
 {$arstid='h�sten';
  $sql_tot="SELECT *, guidebokning.grupp, guidebokning.G_ort, guidebokning.Best_namn, 
  guidebokning.Best_tel1  
  from besokstider, guidebokning
  WHERE besokstider.G_ID=guidebokning.G_ID AND besokstider.G_klar='J'
  AND substring(besokstider.Datum,1,4)='$helaar'
  AND substring(besokstider.Datum,6,5)>='07-01' and substring(besokstider.Datum,6,5)<='12-31'
  ORDER BY besokstider.Datum, besokstider.Tid";
//antal guidade
  $sql_booked="SELECT G_klar, SUM(G_antal) AS booked from besokstider  
  WHERE substring(besokstider.Datum,1,4)='$helaar' AND besokstider.G_klar='J'
  AND substr(besokstider.Datum,6,5)>='07-01' AND substr(besokstider.Datum,6,5)<='12-31'
  GROUP BY G_klar ORDER BY G_klar";
 }

 $query_tot=mysqli_query($connect, $sql_tot) or die(mysqli_error($connect));
 $numro=mysqli_num_rows($query_tot);
 $sidnr=1; //sidnumrering
 $ant_sidor=ceil(($numro+1)/43);
 //$ant_sidor SIDVISA UTTAG BEH�VS
  
 $query_booked=mysqli_query($connect, $sql_booked) or die(mysqli_error($connect));
  while ($row=mysqli_fetch_assoc($query_booked))
  {$guidade=$row['booked'];}
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="stylesheet" type="text/css" href="printmall_guid.css" media="print"> 
<title>Lista �ver guidade</title>
<style type="text/css">
body, table
{
font-family: Arial;
font-size: 13px;
}
P.breakhere 
{page-break-after: always
}
button 
{width: 90px;
 font-family: Verdana, sans-serif; 
 font-size: 11px; font-weight: bold; 
 background-color: #5981D2; color: #FFFFFF; 
 border-left: 2 solid #BECCEE; 
 border-right: 2 solid #315EBB; 
 border-top: 2 solid #BECCEE; 
 border-bottom: 2 solid #315EBB;
}
input.submit
{font-family: Verdana, sans-serif; 
 font-size: 11px; font-weight: bold; 
 background-color: #5981D2; color: #FFFFFF; 
 border-left: 2 solid #BECCEE; 
 border-right: 2 solid #315EBB; 
 border-top: 2 solid #BECCEE; 
 border-bottom: 2 solid #315EBB;
}
</style>
</head>

<body>
<div align="center" id="knapp" name="knapp"> 
<table width="590" style="cell-padding: 15px; border: 1 solid #666666; border-collapse: collapse" cellpadding="10">
<tr><td align="left">
<p align="center"><b><font size="3">Utskrift av guidelistor.<br>
</font></b><font size="2">F�r att f� en lista <b>med</b> formateringen nedan: St�ll in webl�saren p� <b>Utskrift av bakgrund</b>.<br>
I IE g�r man det under Verktyg-Internetalternativ-Avancerat-(ganska l�ngt ner i listan). <br>
Annars f�r man en helt oformaterad lista.<br> 
Skriv ut p� papper eller till pdf (v�lj Adobe PDF som skrivare).<br>
<b>Tips:</b> Skriv ut och spara en formaterad pdf. Den kan sen anv�ndas f�r pappersutskrifter.
</font></p>
<form name="skriv ut" style="margin-top:6; margin-bottom:0">
<p align="center">
<input type="button" value="Skriv ut" onClick="window.print();" class="submit"
 onMouseOver="this.style.color='blue'"   
 onMouseOut="this.style.color='#FFFFFF'">
&nbsp;
<button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color='blue'" 
 onMouseOut="this.style.color='#FFFFFF'">Tillbaka</button>
</p>
</form>
</td></tr></table>
</div>
<div align="center">
<?php
//skriv rubrik p� f�rsta sidan
echo ' <p align="center" style="font-size: 16px">
 <b>Guidningar vid Falsterbo F�gelstation '.$arstid.' '.$helaar.'.</b></p>';
//Tabellhuvud
  $tabrubr='<tr height="21" bgcolor="#666666">
  <td width="100"><font color="#FFFFFF"><b>&nbsp;Datum</b></font></td>
  <td width="250"><font color="#FFFFFF"><b>Grupp</b></font></td>
  <td width="100"><font color="#FFFFFF"><b>Ort</b></font></td>
  <td width="30" align="right"><font color="#FFFFFF"><b>Antal</b></font></td>
  </tr>';
// variabler f�r antal rader per sida
// $numro: antal poster under s�songen enl uttag ovan
  $limit_start=0; //postnr f�r f�rsta posten i utskriften p� f�rsta sidan
  $limit_antal=42; //antal poster i utskriften p� f�rsta sidan

// for-slinga som reglerar sidbyte
for ($sidnr=1; $sidnr<=$ant_sidor; $sidnr++)  
{
//f�rsta utskriftssidan ska ha 42 rader uttag LIMIT 0, 42 
//v�ren:
  if ($halvaar=='1')
  {$sql_klar="SELECT *, guidebokning.grupp, guidebokning.G_ort, guidebokning.Best_namn, 
   guidebokning.Best_tel1 
   from besokstider, guidebokning
   WHERE besokstider.G_ID=guidebokning.G_ID AND besokstider.G_klar='J'
   AND substring(besokstider.Datum,1,4)='$helaar' 
   AND substring(besokstider.Datum,6,5)>='01-01' and substring(besokstider.Datum,6,5)<='06-30'
   ORDER BY besokstider.Datum, besokstider.Tid LIMIT $limit_start, $limit_antal";
  }
  else
//h�sten
  {$sql_klar="SELECT *, guidebokning.grupp, guidebokning.G_ort, guidebokning.Best_namn, 
   guidebokning.Best_tel1  
   from besokstider, guidebokning
   WHERE besokstider.G_ID=guidebokning.G_ID AND besokstider.G_klar='J'
   AND substring(besokstider.Datum,1,4)='$helaar'
   AND substring(besokstider.Datum,6,5)>='07-01' and substring(besokstider.Datum,6,5)<='12-31'
   ORDER BY besokstider.Datum, besokstider.Tid LIMIT $limit_start, $limit_antal";
  }
  $query_klar=mysqli_query($connect, $sql_klar) or die(mysqli_error($connect));
  echo '<table width="590" style="cell-padding:5px; border-collapse: collapse">';
  echo $tabrubr;
  $farg='#FFFFFF';
  while ($row=mysqli_fetch_assoc($query_klar))
  {if ($farg==('#FFFFFF'))
    {$farg='#E5E5E5';}
   else
    {$farg='#FFFFFF';}
   echo '<tr height="21" bgcolor="'.$farg.'"> 
   <td width="100">&nbsp;'.($row['Datum']).'</td>
   <td width="250">'.$row['Grupp'].'</td>
   <td width="100">'.$row['G_ort'].'</td>
   <td width="30" align="right">'.$row['G_antal'].'</td>
   </tr>';
  }
//om det �r sista sidan
  if($sidnr==$ant_sidor)
  {if ($farg==('#FFFFFF'))
   {$farg='#E5E5E5';}
    else
   {$farg='#FFFFFF';}
   echo '<tr height="21" bgcolor='.$farg.'>
   <td><b>&nbsp;Summa</b></td><td><b>Grupper: '.$numro.'</b></td><td width="100"><b>Personer:</b></td>
   <td width="30" align="right"><b>'.$guidade.'</b></td></tr></table>';
//skriv ut sidnummer
   echo '<p align="center" style="margin-bottom: 0">'.$sidnr.' ('.$ant_sidor.')</p>';
  }
  else
  {echo '</table>';
//skriv ut sidnummer
  echo '<p align="center" style="margin-bottom: 0">'.$sidnr.' ('.$ant_sidor.')</p>';
//sidbrytning
  echo '<br class="breakhere">';
//nya variabler f�r uttag till n�sta sida
   $limit_start=$limit_start+$limit_antal; //postnr f�r f�rsta posten i utskriften p� n�sta sida
   $limit_antal=43; //(max) antal poster i utskriften p� n�sta sida
  }
}
?>
</div>
</body>

</html>