<?php
include "../incl_filer/db_connect.php"; //databasanslutning 

if (isset ($_REQUEST['tidknapp']))  //om ändring är begärd
{
    $nykod = $_REQUEST['nykod'];
    $nytext = $_REQUEST['nytext'];
    $sql_nytyp = "UPDATE urtid SET tidkod='$nykod', tidtxt='$nytext'";
    $query_nytyp = mysqli_query($connect, $sql_nytyp) or die (mysqli_error($connect));
}
$sql_ttyp = "SELECT tidkod, tidtxt FROM urtid";
$query_ttyp = mysqli_query($connect, $sql_ttyp) or die (mysqli_error($connect));
while ($row = mysqli_fetch_assoc($query_ttyp)) {
    $tidskod = $row['tidkod'];
    $tidstext = $row['tidtxt'];
}
if ($tidskod == 'CET') {
    $knapptxt = 'Ändra till SOMMARTID';
    $sql_tlista = "SELECT CET from tidur";
    $query_tlista = mysqli_query($connect, $sql_tlista) or die (mysqli_error($connect));
} else {
    $knapptxt = 'Ändra till NORMALTID';
    $sql_tlista = "SELECT CEST from tidur";
    $query_tlista = mysqli_query($connect, $sql_tlista) or die (mysqli_error($connect));
}
?>

<! DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd" >
<html>

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="Content-Language" content="sv">
    <title>Skicka väderdata till hemsidan</title>
    <link rel="stylesheet" type="text/css" href="../bluemall.css">
</head>

<body>
<div align="center">
    <p style="margin-bottom:0"><b>Formuläret är f.n. inställt på <?php echo $tidstext; ?></b></p>
    <?php
    if ($tidstext == 'SOMMARTID (UTC+2h)') {
        $nytidskod = 'CET';
        $nytidstext = 'NORMALTID (UTC+1h)';
    } else {
        $nytidskod = 'CEST';
        $nytidstext = 'SOMMARTID (UTC+2h)';
    }
    ?>
    <form style="margin-top: 3px" name="tidform" method="POST" action="present_weather.php">
        <input type="hidden" name="nykod" value="<?php echo $nytidskod; ?>">
        <input type="hidden" name="nytext" value="<?php echo $nytidstext; ?>">
        <input type="submit" name="tidknapp" class="submit" value="<?php echo $knapptxt; ?>"
               onMouseOver="this.style.color='blue'"
               onMouseOut="this.style.color='#FFFFFF'">
    </form>

    <form method="POST" action="handleWeatherData.php">
        <p>Vädret <b>kl</b>:
            <select name="obstid" style="font-family: Verdana; font-size: 11px; color: #000080">
                <?php
                if ($tidskod == 'CEST') {
                    while ($row = mysqli_fetch_assoc($query_tlista)) {
                        echo '<option value="' . $row['CEST'] . '">' . $row['CEST'] . '</option>';
                    }
                } else {
                    while ($row = mysqli_fetch_assoc($query_tlista)) {
                        echo '<option value="' . $row['CET'] . '">' . $row['CET'] . '</option>';
                    }
                }
                ?>
            </select>
            <?php echo $tidstext; ?></p>

        <p><b>Sikt</b>:
            <input type="text" size="4" name="sikt"> km
        <p>
        <table align="center">
            <tr align="center">
                <td><b>Molnighet</b>:</td>
                <td>0/8</td>
                <td>1/8</td>
                <td>2/8</td>
                <td>3/8</td>
                <td>4/8</td>
                <td>5/8</td>
                <td>6/8</td>
                <td>7/8</td>
                <td>8/8</td>
                <td>9/8</td>
                <td>X (auto)</td>
            </tr>
            <tr align="center">
                <td> &nbsp;</td>
                <td><input type="radio" style="border:0" name="moln" value="0"></td>
                <td><input type="radio" style="border:0" name="moln" value="1"></td>
                <td><input type="radio" style="border:0" name="moln" value="2"></td>
                <td><input type="radio" style="border:0" name="moln" value="3"></td>
                <td><input type="radio" style="border:0" name="moln" value="4"></td>
                <td><input type="radio" style="border:0" name="moln" value="5"></td>
                <td><input type="radio" style="border:0" name="moln" value="6"></td>
                <td><input type="radio" style="border:0" name="moln" value="7"></td>
                <td><input type="radio" style="border:0" name="moln" value="8"></td>
                <td><input type="radio" style="border:0" name="moln" value="9"></td>
                <td align="left"><input type="radio" style="border:0" name="moln" value="X"></td>
            </tr>
        </table>
        <br>
        <table align="center">
            <tr align="center">
                <td><b>Vindriktn</b>.:</td>
                <td>--</td>
                <td>N</td>
                <td>NNE</td>
                <td>NE</td>
                <td>ENE</td>
                <td>E</td>
                <td>ESE</td>
                <td>SE</td>
                <td>SSE</td>
                <td>S</td>
                <td>SSW</td>
                <td>SW</td>
                <td>WSW</td>
                <td>W</td>
                <td>WNW</td>
                <td>NW</td>
                <td>NNW</td>
            </tr>
            <tr align="center">
                <td> &nbsp</td>
                <td><input type="radio" style="border:0" name="vrikt" value="---"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="N"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="NNE"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="NE"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="ENE"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="E"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="ESE"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="SE"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="SSE"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="S"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="SSW"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="SW"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="WSW"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="W"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="WNW"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="NW"></td>
                <td><input type="radio" style="border:0" name="vrikt" value="NNW"></td>
            </tr>
        </table>
        <br>
        <p><b>Vindstyrka</b>:
            <input type="text" size="2" name="vsty" style="font-family: Verdana; font-size: 11px; color: #000080"> m/s&nbsp;&nbsp;&nbsp;
            <b>Temp</b>:
            <input type="text" size="5" name="temp" style="font-family: Verdana; font-size: 11px; color: #000080">&nbsp;&nbsp;&nbsp;
            <b>Lufttryck</b>:
            <input type="text" size="6" name="tryck"> hPa</p>

        <p><b>Väder</b> <br>
            (för att markera mer än ett alternativ: håll ned CTRL och klicka):<br>
            <select name="vader[]" size="16" multiple>
                <option value="XX">inget sign. (auto)</option>
                <option value="00">inget sign.</option>
                <option value="01">klart</option>
                <option value="02">nästan klart</option>
                <option value="03">delvis molnigt</option>
                <option value="04">nästan mulet</option>
                <option value="05">mulet</option>
                <option value="10">fuktdis</option>
                <option value="11">markdimma</option>
                <option value="13">kornblixt</option>
                <option value="15">nederbörd inom synhåll</option>
                <option value="17">åska på avstånd</option>
                <option value="19">tromb</option>
                <option value="30">snödrev</option>
                <option value="40">dimma på avstånd</option>
                <option value="44">dimma</option>
                <option value="46">underkyld dimma</option>
                <option value="50">duggregn</option>
                <option value="56">underkylt duggregn</option>
                <option value="60">regn</option>
                <option value="66">underkylt regn</option>
                <option value="69">snöblandat regn</option>
                <option value="70">snöfall</option>
                <option value="77">kornsnö</option>
                <option value="80">regnskurar</option>
                <option value="83">byar av snöblandat regn</option>
                <option value="85">snöbyar</option>
                <option value="87">snöhagel</option>
                <option value="89">småhagel</option>
                <option value="95">åska</option>
            </select>
            <input type="hidden" name="tkoden" value="<?php echo $tidskod; ?>">
        <p>
            <input type="submit" class="submit" value="Skicka"
                   onMouseOver="this.style.color='blue'"
                   onMouseOut="this.style.color='#FFFFFF'">
            <input type="reset" class="submit" value="Ångra"
                   onMouseOver="this.style.color='blue'"
                   onMouseOut="this.style.color='#FFFFFF'">
        </p>
    </form>
</div>
</body>
</html>  