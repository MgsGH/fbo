<?php 
include "../incl_filer/db_connect.php"; //databasanslutning 
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Ny fotograf</title>
<LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
</head>

<body style="background: #F2F5FF">
<?php
//Detta �r testat och fungerar!
if (isset($_REQUEST['fotoman']))
{if (!empty($_REQUEST['fotoman']))
 {//SKAPA VARIABLER
 $in_fot=$_REQUEST['fotoman'];
 $in_hem=$_REQUEST['hemsida'];
 $in_web=$_REQUEST['webtext'];
 $insql="INSERT INTO fotografer (Fotograf, Hemsida, Webtext)
 values ('$in_fot', '$in_hem', '$in_web')";
 mysqli_query($connect, $insql);
 echo '<p>Ny fotograf, '.$in_fot.' har lagts till i databasen.';}
 else
 {echo 'Fotograf m�ste anges. Det gick inte att l�gga till data!';}
}
else
{
?>
<p style="font-size: 11 px; color: navy">
<form method="POST" name="Add fotograf" action="ny_fotograf.php">
<b>Fotograf</b> (m�ste fyllas i):<br>
<input type="text" style="font-size: 11 px; color: navy" width="50" name="fotoman"><br>
<b>Hemsida</b> (om man k�nner till fotografens hemsida t.ex. www.sturnus.se):<br>
<input type="text" style="font-size: 11 px; color: navy" width="50" name="hemsida"><br>
<b>Webtext</b> (den text som visas f�r l�nken p� v�ra sidor - b�r vara kort, t.ex. Sturnus):<br>
<input type="text" style="font-size: 11 px; color: navy" width="50" name="webtext"><br>
<p></p><input type="submit" value="Skicka" name="nyfot" class="submit"
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'"> &nbsp;
<?php
;}
?>
<p>
<button
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'" 
onclick="javascript: window.close()">St�ng</button></p>
</body>
</html>
