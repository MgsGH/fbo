<?php
include "../incl_filer/db_connect.php"; //databasanslutning
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Guidetider, tillägg</title>
<LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
<script language="JavaScript" src="../overlib.js">
</script>
<script type="text/javascript">
<!--
  var ol_width=140; //sätter bredden på popuprutan
//-->
</script>
<style>
p
{
 margin-top: 6px;
 margin-bottom: 6px;
}
</style>
</head>

<body class="alt_tab_bg" style="background-image: url('guideadd.php')">
<?php
 //Visa grupp och tidigare bokning. Hämta ID.
 $gruppo=$_REQUEST['gruppen'];
 $bokning=$_REQUEST['id'];
 $sql_tid="Select * from besokstider WHERE G_ID='$bokning' order by Datum";
 $query_tid=mysqli_query($connect, $sql_tid) or die (mysqli_error($connect));
 echo 'Inbokning av flera tider från samma beställare.<br>';
 echo 'Aktuell beställning från <b>'.$gruppo.'</b><br>';
 echo 'Redan inbokad tid:<br>';
 while ($row=mysqli_fetch_assoc($query_tid))
 {echo $row['Datum'].' '.$row['Tid'].'<br>';}
 
 //boka fler tider
 if (isset($_REQUEST['boka']))
 {$plusdag=$_REQUEST['plusdag'];
  $plustid=$_REQUEST['plustid'];
  $deltant=$_REQUEST['deltant'];
  $alder=$_REQUEST['alder'];
//mata in i dbn
  echo $bokning.' '.$plusdag.' '.$plustid.' '.$deltant.' '.$alder.'N';
  $sql_add="INSERT into besokstider (G_ID, Datum, Tid, G_antal, G_alder, G_klar)
  values ('$bokning', '$plusdag', '$plustid', '$deltant', '$alder', 'N')";
  mysqli_query($connect, $sql_add) or die (mysqli_error($connect));
  echo '<p> Inmatade uppgifter har lagts till i databasen.<br>
  <a href="guideadd.php?gruppen='.$gruppo.'&id='.$bokning.'"><b>Visa/Lägg till fler tider.</b></a>';
 }
 else
 {//fyll i formuläret
 echo '<p>Lägg till fler tider:<br>
 Fält markerade med * måste alltid fyllas i.
 <form style="margin-top:6" name="mertid" method="POST" action="guideadd.php"> 
 Besöksdatum (åååå-mm-dd): *<input type="text" size="10" name="plusdag">*<br>
 Klockslag (tt:mm): *<input type="text" size="5" name="plustid">*<br>
 Uppskattat antal deltagare: *<input type="text" size="3" name="deltant">*<br>
 Åldersgrupp (t.ex. åk 5): <input type="text" size="10" name="alder"><br>
 <input type="hidden" value="'.$bokning.'" name="id">
 <input type="hidden" value="'.$gruppo.'" name="gruppen">
 <p>
 <input name="boka" type="submit" value="Lägg till" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
<input type="reset" value="Radera" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">
</form>';
 }
?>
<p>
<button
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'" 
onclick="javascript: window.close()">Stäng</button></p>
</body>
</html>
