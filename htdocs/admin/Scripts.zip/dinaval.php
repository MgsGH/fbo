<?php 
include "../incl_filer/db_connect.php"; //databasanslutning

//data levererade fr�n inmatningsformul�r
if ((isset($_REQUEST['ny_inm']) && isset($_REQUEST['mno']) && isset($_REQUEST['pubaar']) && isset($_REQUEST['pdf']) 
&& isset($_REQUEST['forf']) && isset($_REQUEST['sve_tit']) && isset($_REQUEST['journal']) && isset($_REQUEST['forf_enamn'])) 
&& (isset($_REQUEST['sokord']) || (isset($_REQUEST['sve_sok']) && isset($_REQUEST['eng_sok']))))
{
 //DIREKT INMATNING TILL HUVUDLISTAN
 $ny_num=$_REQUEST['mno'];
 $ny_aar=$_REQUEST['pubaar'];
 $ny_pdf=$_REQUEST['pdf']; //m�ste justeras f�r J eller N
 $ny_forf=$_REQUEST['forf'];
 $ny_sve_tit=$_REQUEST['sve_tit'];
 $ny_eng_tit=$_REQUEST['eng_tit'];
 $ny_journal=$_REQUEST['journal'];
 //S�KORD M.M.
 $ny_forf_enamn=$_REQUEST['forf_enamn']; //TEXT
 //$_REQUEST['arter'] arter som finns, ARRAY 
 $ny_art=$_REQUEST['artnamn']; //arter som ska l�ggas till TEXT
 //$_REQUEST['rapport'] Kan vara tom ARRAY
 //$_REQUEST['sokord'] s�kord som finns ARRAY
 $ny_sve_sok=$_REQUEST['sve_sok']; //s�kord som ska l�ggas till TEXT
 $ny_eng_sok=$_REQUEST['eng_sok']; //s�kord som ska l�ggas till TEXT

 
 //pdf finns-finns ej
 if($ny_pdf!='J')
 {$ny_pdf='N';}

 //***************************** F�RFATTARE - INMATAT SOM TEXT **************************
 $array_forf=explode(',', $ny_forf_enamn);
 foreach($array_forf as $forf)
 {//kolla om f�rfattaren finns
  //ta ut lista med f�rfattare
  $sqlval_1="Select * from fbomedd_authors where Author='$forf'";
  $query_1=mysqli_query($connect, $sqlval_1) or die (mysqli_error($connect));
  $match_1=mysqli_num_rows($query_1);
  if ($match_1==0)
  {
   echo $forf.' finns inte i listan.<br>';
   $sql_laggtill_forf="insert into fbomedd_authors (Author) values ('$forf')";
   mysqli_query($connect, $sql_laggtill_forf) or die (mysqli_error($connect));
   echo $forf.' har lagts till i listan med f�rfattare.<br>';
  }
  else
  {
   while($row=mysqli_fetch_assoc($query_1))
   {echo $row['Author'].' finns redan i listan med f�rfattare.<br>';}
  }
 }
 //**********************************SLUT F�RFATTARE FUNKAR *******************************

 //***************************************** ARTER *****************************************
 //$_REQUEST['arter'] finns i listan ARRAY
 //$ny_art arter som skrivits in och ska l�ggas till TEXT

 if ($_REQUEST['arter']!='' && $ny_art=='') //bara befintliga arter FUNKAR
 {
  //TA UT ENGELSKA ARTNAMN OCH L�GG TILL I INPUT_ART
  $new_sp='';
  foreach($_REQUEST['arter'] as $bef)
  {
   $VERSALART=strtoupper($bef);
   $sql_findname="select SVNAMN, ENGNAMN, LATNAMN from artnamn where SVNAMN='$VERSALART' order by SVNAMN";
   $query_findname=mysqli_query($connect, $sql_findname) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_findname))
   {
    $svnamn=strtolower($row['SVNAMN']);
    $engnamn=$row['ENGNAMN'];
    $latnamn=$row['LATNAMN']; //l�ggs t.v. inte i s�korden
    if ($new_sp=='')
    {
     $new_sp=$engnamn;
    }
    else
    {
     $new_sp=$new_sp.','.$engnamn;
    }
   }
  }
  $input_art_s=implode(',', $_REQUEST['arter']);
  $input_art_e=$new_sp; 
  echo $input_art_s.'<br>'.$input_art_e;    //TESTRAD - SKA TAS BORT
 }
 elseif ($_REQUEST['arter']=='' && $ny_art!='') //bara nya arter INSKRIVNA SOM TEXT
 {
  //l�gg till de nya arterna i artlistan
  $array_art=explode(',', $ny_art);
  $new_sp='';
  foreach($array_art as $art)
  {
   $VERSALART=strtoupper($art);
   $sql_findname="select SVNAMN, ENGNAMN, LATNAMN from artnamn where SVNAMN='$VERSALART' order by SVNAMN";
   $query_findname=mysqli_query($connect, $sql_findname) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_findname))
   {
    $svnamn=strtolower($row['SVNAMN']);
    $engnamn=$row['ENGNAMN'];
    $latnamn=$row['LATNAMN'];
    $sql_laggtill_art="insert into fbomedd_arter (Sve_art, Eng_art, Lat_art) values ('$svnamn', '$engnamn', '$latnamn')";
    mysqli_query($connect, $sql_laggtill_art) or die (mysqli_error($connect));
    echo $svnamn.' '.$engnamn.' '.$latnamn.' har lagts till i artlistan.<br>'; //TESTRAD - SKA TAS BORT

    if ($new_sp=='')
    {
     $new_sp=$engnamn;
    }
    else
    {
     $new_sp=$new_sp.','.$engnamn;
    }
   }
  }
  $input_art_s=$ny_art;
  $input_art_e=$new_sp;
  echo $input_art_s.'<br>'.$input_art_e;    //TESTRAD - SKA TAS BORT
 }
 elseif ($_REQUEST['arter']!='' && $ny_art!='')  //b�de befintliga ARRAY och nya TEXT arter
 {
  //TA UT ENGELSKA ARTNAMN OCH L�GG TILL I INPUT_ART
  $new_sp1='';
  foreach($_REQUEST['arter'] as $bef)
  {
   $VERSALART=strtoupper($bef);
   $sql_findname="select SVNAMN, ENGNAMN, LATNAMN from artnamn where SVNAMN='$VERSALART' order by SVNAMN";
   $query_findname=mysqli_query($connect, $sql_findname) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_findname))
   {
    $svnamn=strtolower($row['SVNAMN']);
    $engnamn=$row['ENGNAMN'];
    $latnamn=$row['LATNAMN']; //l�ggs t.v. inte i s�korden
    if ($new_sp1=='')
    {
     $new_sp1=$engnamn;
    }
    else
    {
     $new_sp1=$new_sp1.','.$engnamn;
    }
   }
  }
  //l�gg till de nya arterna i artlistan
  $array_art=explode(',', $ny_art);
  $new_sp2='';
  foreach($array_art as $art)
  {
   $VERSALART=strtoupper($art);
   $sql_findname2="select SVNAMN, ENGNAMN, LATNAMN from artnamn where SVNAMN='$VERSALART' order by SVNAMN";
   $query_findname2=mysqli_query($connect, $sql_findname2) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_findname2))
   {
    $svnamn=strtolower($row['SVNAMN']);
    $engnamn=$row['ENGNAMN'];
    $latnamn=$row['LATNAMN'];
    $sql_laggtill_art="insert into fbomedd_arter (Sve_art, Eng_art, Lat_art) values ('$svnamn', '$engnamn', '$latnamn')";
    mysqli_query($connect, $sql_laggtill_art) or die (mysqli_error($connect));
    echo $svnamn.' '.$engnamn.' '.$latnamn.' har lagts till i artlistan.<br>'; //TESTRAD - SKA TAS BORT
    if ($new_sp2=='')
    {
     $new_sp2=$engnamn;
    }
    else
    {
     $new_sp2=$new_sp2.','.$engnamn;
    }
   }
  }
  $input_art_s=implode(',', $_REQUEST['arter']).','.$ny_art;
  $input_art_e=$new_sp1.','.$new_sp2;
  echo $input_art_s.'<br>'.$input_art_e;    //TESTRAD - SKA TAS BORT 
 }
 elseif ($_REQUEST['arter']=='' && $ny_art=='')
 {
  echo 'Ingen art har angetts.';
  $input_art_s='';
  $input_art_e='';
 }
 //***************************************** SLUT ARTER FUNKAR *********************************************

 //********************************************** S�KORD ***************************************************
 //$_REQUEST['sokord']=s�kord som finns i listan ARRAY
 //$ny_sve_sok=s�kord som ska l�ggas till TEXT
 //$ny_eng_sok=s�kord som ska l�ggas till TEXT
 if ($_REQUEST['sokord']!='' && $ny_sve_sok=='' && $ny_eng_sok=='') //inga nya s�kord
 {
  //ta ut motsv s�kord ur den engelska listan
  $bef_word='';
  foreach($_REQUEST['sokord'] as $sok)
  {
   $sql_motsv="select * from fbomedd_svsearch, fbomedd_ensearch where Svesearch='$sok' and s_id=e_id";
   $query_motsv=mysqli_query($connect, $sql_motsv) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_motsv))
   {
    $sokw=$row['Engsearch'];
    if ($bef_word=='')
    {
     $bef_word=$sokw;
    }
    else
    {
     $bef_word=$bef_word.','.$sokw;
    } 
   }
  }
  $input_sok_s=implode(',', $_REQUEST['sokord']); //inmatning till fbomeddelanden sve_search
  $input_sok_e=$bef_word; //inmatning till fbomeddelanden eng_search
  echo $input_sok_s.'<br>'.$input_sok_e;    //TESTRAD - SKA TAS BORT      
 }
 elseif ($_REQUEST['sokord']=='' && $ny_sve_sok!='' && $ny_eng_sok!='') //enbart nya s�kord
 {
  //l�gg till i den SVENSKA s�klistan
  $array_ny_sve=explode(',', $ny_sve_sok);
  foreach($array_ny_sve as $sve)
  { 
   $sql_laggtill_soks="insert into fbomedd_svsearch (Svesearch) values ('$sve')";
   mysqli_query($connect, $sql_laggtill_soks) or die (mysqli_error($connect));
   echo $sve.' har lagts till i listan med svenska s�kord.<br>';
  }
  //l�gg till i den ENGELSKA s�klistan
  $array_ny_eng=explode(',', $ny_eng_sok);
  foreach($array_ny_eng as $eng)
  { 
   $sql_laggtill_soke="insert into fbomedd_ensearch (Engsearch) values ('$eng')";
   mysqli_query($connect, $sql_laggtill_soke) or die (mysqli_error($connect));
   echo $eng.' har lagts till i listan med engelska s�kord.<br>'; 
  }
  $input_sok_s=$ny_sve_sok; //=de som skrivits in 
  $input_sok_e=$ny_eng_sok; //=de som skrivits in 
  echo $input_sok_s.'<br>'.$input_sok_e;    //TESTRAD - SKA TAS BORT
 }
 elseif ($ny_sokord!='' && $ny_sve_sok!='' && $ny_eng_sok!='') //b�de befintliga och nya s�kord
 {
  //befintliga s�kord
  //ta ut motsv s�kord ur den engelska listan
  $bef_word='';
  foreach($_REQUEST['sokord'] as $sok)
  {
   $sql_motsv="select * from fbomedd_svsearch, fbomedd_ensearch where Svesearch='$sok' and s_id=e_id";
   $query_motsv=mysqli_query($connect, $sql_motsv) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_motsv))
   {
    $sokw=$row['Engsearch'];
    if ($bef_word=='')
    {
     $bef_word=$sokw;
    }
    else
    {
     $bef_word=$bef_word.','.$sokw;
    } 
   }
  }
  $input_sok_s1=implode(',', $_REQUEST['sokord']); //inmatning till fbomeddelanden sve_search
  $input_sok_e1=$bef_word; //inmatning till fbomeddelanden eng_search
  echo $input_sok_s1.'<br>'.$input_sok_e1;    //TESTRAD - SKA TAS BORT 

  //nya s�kord
  //l�gg till i den SVENSKA s�klistan
  $array_ny_sve=explode(',', $ny_sve_sok);
  foreach($array_ny_sve as $sve)
  { 
   $sql_laggtill_soks="insert into fbomedd_svsearch (Svesearch) values ('$sve')";
   mysqli_query($connect, $sql_laggtill_soks) or die (mysqli_error($connect));
   echo $sve.' har lagts till i listan med svenska s�kord.<br>';
  }
  //l�gg till i den ENGELSKA s�klistan
  $array_ny_eng=explode(',', $ny_eng_sok);
  foreach($array_ny_eng as $eng)
  { 
   $sql_laggtill_soke="insert into fbomedd_ensearch (Engsearch) values ('$eng')";
   mysqli_query($connect, $sql_laggtill_soke) or die (mysqli_error($connect));
   echo $eng.' har lagts till i listan med engelska s�kord.<br>'; 
  }
  $input_sok_s=$input_sok_s1.','.$ny_sve_sok; //=befintliga + de som skrivits in 
  $input_sok_e=$input_sok_e1.','.$ny_eng_sok; //=befintliga + de som skrivits in 
  echo $input_sok_s.'<br>'.$input_sok_e;    //TESTRAD - SKA TAS BORT
 }
 //***************************************************SLUT S�KORD*****************************************
 if ($input_art_s=='') //inga arter angivna, s�kord m�ste alltid finnas
 {
  $input_sve=$input_sok_s; //inmatning till fbomeddelanden sve_search
  $input_eng=$input_sok_e; //inmatning till fbomeddelanden eng_search
 }
 else  //b�de arter och s�kord angivna
 {
  $input_sve=$input_art_s.','.$input_sok_s; //inmatning till fbomeddelanden sve_search
  $input_eng=$input_art_e.','.$input_sok_e; //inmatning till fbomeddelanden eng_search
 }
 //*********************************************UPPDATERA  HUVUDTABELLEN**********************************
 $sql_final="insert into fbomeddelanden (no, author, year, title, summary, journal, pdf, sve_search, eng_search) 
 values ('$ny_num', '$ny_forf', '$ny_aar', '$ny_sve_tit', '$ny_eng_tit', '$ny_journal', '$ny_pdf', '$input_sve', '$input_eng')";
 mysqli_query($connect, $sql_final) or die (mysqli_error($connect));
 echo 'KLART! Nya data �r inmatade utan fel.';
}
else
{
 die ('N�got gick �t helvete - f�rs�k igen!');
} 
?>

