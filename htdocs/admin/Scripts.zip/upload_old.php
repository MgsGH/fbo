<?php
include "../incl_filer/db_connect_skofsales.php"; //databasanslutning
/*
Mycket enkelt upload-script av jostor.
F�r anv�ndas fritt.
Ska fungera p� alla PHP-versioner �ver 4.1.0,
och p� de flesta system.
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Language" content="sv">
<title>Ladda upp en fil</title>
<link rel="stylesheet" type="text/css" href="../bluemall.css">
</head>

<body style="background: #F2F5FF">
Goddag
<?php
echo $_REQUEST['bildtyp']; 
$arsmapp=date('Y');
if (isset($_FILES['uplfile'])) 
{	// Mappen d�r filerna ska hamna 
	// if (isset($_REQUEST['bildtyp']))
	$bildtyp=$_REQUEST['bildtyp'];
	if ($bildtyp=='galleri')
	  {$upload_dir = '../Galleri/Maxipix/';}
	elseif ($bildtyp=='startsida')
	  {$upload_dir = '../Galleri/Midipix/';}
	elseif ($bildtyp=='thumbs')
	  {$upload_dir = '../Galleri/Minipix/';}
	elseif ($bildtyp=='shop_varor' || $bildtyp=='shop_kat')
	  {$upload_dir = '../sales/Bilder/'.$bildmap.'/';} 
	elseif ($bildtyp=='schinzii')
	  {$upload_dir = '../research/schinzii/'.$arsmapp.'/upl_bilder/';}
	elseif ($bildtyp=='dagbok')
	  {$upload_dir = '../news/Dagbok/'.$arsmapp.'/upl_bilder/';}
	
	// De till�tna filtyperna, separerade med komman, utan mellanrum
	$filetypes = 'jpg,gif,png';
	// Den st�rsta till�tna storleken (350 kB)
	$maxsize = (1024*350);

	// Kontrollera att det angavs en fil
	if(empty($_FILES['uplfile']['name']))
		die('Ingen fil har valts');

	// Kontrollera storleken
	if($_FILES['uplfile']['size'] > $maxsize)
		die('Filen du valde �r f�r stor. Maxstorleken �r '.(string)($maxsize/1024).' KB.');

	// Kontrollera filtypen
	$types = explode(',', $filetypes);
	$file = explode('.', $_FILES['uplfile']['name']);
	$extension = $file[sizeof($file)-1];
	if(!in_array(strtolower($extension), $types))
		die('Du har en felaktig filtyp. Endast .jpg, .gif och .png �r till�tna!');

	$thefile = $_FILES['uplfile']['name'];
	
	// Flytta filen r�tt
	if (is_uploaded_file($_FILES['uplfile']['tmp_name']) && move_uploaded_file($_FILES['uplfile']['tmp_name'],$upload_dir.$thefile))
	 {echo 'Filen laddades upp! St�ng f�nstret.<br>';

		/*
		Uppladdningen lyckades.
		H�r kan man �ven l�gga eventuell kod  f�r t.ex. databashantering.
		Filnamnet ligger i $thefile.
		Ytterligare f�lt i formul�ret f�r du som vanligt med $_POST
		*/
	} 
	else 
	{
	 echo 'Ett fel uppstod och filen kunde inte laddas upp.<br>';
	}
}
else
{  
echo '<b>Ladda upp bilder till ';
if (isset($_REQUEST['typ']))
{$bildtyp=$_REQUEST['typ'];
 if ($bildtyp=='galleri')
 {echo 'GALLERIET';
 $bildstorlek='att bildstorleken b�r vara 800x438 px. Viss avvikelse (�10%) kan tolereras.';}
 else if ($bildtyp=='startsida')
 {echo 'STARTSIDAN';
 $bildstorlek='att bildstorleken <b>m�ste</b> vara 500x300 px.';}
 else if ($bildtyp=='thumbs')
 {echo 'THUMBNAILS';
 $bildstorlek='att bildstorleken b�r vara 170x93 px. Viss avvikelse (�10%) kan tolereras.';}
}
else
{if ($_REQUEST['bildtyp']=='shop_varor')
 {echo 'WEBSHOPEN --- Aktuellt artikelnr: '.$_REQUEST['num'];
  $bildtyp=$_REQUEST['bildtyp'];
  $bildmap=$_REQUEST['mapp'];
  $bildstorlek='att minibilderna ska vara 100 px breda. De stora bilderna ska vara 300 px h�ga.';
  $extext='G�r s� h�r:<br> 
  1. Bl�ddra fram filen som ska laddas upp.<br>
  2. H�gerklicka p� filnamnet och v�lj Byt namn. Notera aktuellt artikelnr (ovan).<br>
  3. Nya namn: artikelnr_stor.jpg f�r stora bilder och artikelnr_mini.jpg f�r sm�.<br>
  4. Ladda upp filen.<br>
  5. St�ng f�nstret.';
 }  
 elseif ($_REQUEST['bildtyp']=='shop_kat')
 {$bildtyp=$_REQUEST['bildtyp']
  $K_nr=$_REQUEST['num'];
  echo 'WEBSHOPEN --- Aktuellt kategorinr: '.$K_nr;
 
  $sql_mapp="SELECT katnr, bildmapp from sortiment WHERE katnr=$K_nr";
  $query_mapp=mysqli_query($connect, $sql_mapp) or die (mysqli_error($connect));
  if (mysqli_num_rows($query_mapp)==0)
  {
   $varning='<b><i>Bildmapp saknas. Mata in/�ndra data via formul�ret.</i></b><br>';
  } 
  else
  {
   while ($row = mysqli_fetch_assoc($query_mapp))
   {
    $bildmap=$row['bildmapp'];
    $varning='';
   } 
  } 
  $bildstorlek='bilderna f�r vara h�gst 180 px breda.';
  $extext=$varning.
  'G�r s� h�r:<br> 
  1. Bl�ddra fram filen som ska laddas upp.<br>
  2. Ladda upp filen.<br>
  3. St�ng f�nstret.';
  mysqli_close($connect);
 }  
 elseif ($_REQUEST['bildtyp']=='schinzii')
 {$bildtyp='schinzii';
  echo 'K�RRSN�PPEDAGBOKEN';
  $bildstorlek='att den maximala bildbredden inte �verstiger 700 px.';
 }
 elseif ($_REQUEST['bildtyp']=='dagbok')
 {$bildtyp='dagbok';
  echo 'DAGBOKEN';
  $bildstorlek='att den maximala bildbredden inte �verstiger 700 px.';
 } 
}
?>
    </b></p>
    <p><b>T�nk p�:</b><br>
    att redigera bilderna innan du laddar upp dem.<br> 
    att kontrollera att uppl�sningen �r 72 dpi.<br>
    att minimera filstorleken (anv�nd &quot;Spara f�r webben&quot; i Photoshop).<br>
    <?php echo $bildstorlek; ?><br>
 
	<form action="upload.php" method="post" enctype="multipart/form-data">
	<b>Ange exakt filnamn (inkl. filtyp. t.ex. skatbo.jpg):</b><br>
	<?php echo $extext; ?><br>
	<input type="file" name="uplfile" size="60" style="font-family: Verdana; font-size: 11px"></p>
	<p>
	<input type="hidden" value="<?php echo $bildtyp; ?>" name="bildtyp">
	<input type="hidden" value="<?php echo $bildmap; ?>" name="bildmap">
	<input type="submit" value="Ladda upp filen" class="submit"
	onMouseOver="this.style.color='blue'" 
    onMouseOut="this.style.color='#FFFFFF'">
	</form>

<?php 
}
?>
<p> 
<button
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'" 
onclick="javascript: window.close()">St�ng</button>
</p>
</body>
</html>