<?php 
include "../incl_filer/db_connect.php"; //databasanslutning

$sql_ttyp="SELECT * from urtid";
$query_ttyp=mysqli($connect, $sql_ttyp) or die (mysqli_error($connect));
?>
<html> 
<head><title></title></head> 
<style type="text/css">
<!--
body {
font-family: Verdana, sans serif;
font-size: 11 px;
color: #000080;
}
table{
font-family: Verdana, sans serif;
font-size: 11 px;
color: #000080;
}
-->
</style>

</head>

<body> 
 <div align="center">
  <?php 
  while ($row=mysqli_fetch_assoc($query_ttyp))
  {
  echo $row['tidkod'].' '.$row['tidtext'];
  }
  ?>
    <form method="POST" action="../news/txtobsen.php" style="font-family: Verdana; font-size: 11px; color: #000080"> 
    <p>V�dret <b>kl</b>: 
<!--- denna del �r f�r NORMALTID - markera ut den del som INTE g�ller 
	<select name="obstid" style="font-family: Verdana; font-size: 11px; color: #000080"> 
    <option value="01:00">01:00</option> 
    <option value="04:00">04:00</option> 
    <option value="07:00">07:00</option>
    <option value="10:00">10:00</option> 
    <option value="13:00">13:00</option> 
    <option value="16:00">16:00</option> 	
    <option value="19:00">19:00</option> 
    <option value="22:00">22:00</option> 
  </select> 
  Normaltid (UTC+1h)</p>--->
<!--- denna del �r f�r SOMMARTID - markera ut den del som INTE g�ller--->
  <select name="obstid" style="font-family: Verdana; font-size: 11px; color: #000080">
    <option value="02:00">02:00</option> 
    <option value="05:00">05:00</option> 
    <option value="08:00">08:00</option>
    <option value="11:00">11:00</option> 
    <option value="14:00">14:00</option> 
    <option value="17:00">17:00</option> 	
    <option value="20:00">20:00</option> 
    <option value="23:00">23:00</option> 
  </select> 
  Sommartid (UTC+2h)</p> 
  <p><b>Sikt</b>:
  <input type="text" size="4" name="sikt" style="font-family: Verdana; font-size: 11px; color: #000080"> km 
  <p>
  <table align="center">
  <tr align="center">
  <td><b>Molnighet</b>:</td><td>0/8</td><td>1/8</td><td>2/8</td><td>3/8</td><td>4/8</td><td>5/8</td><td>6/8</td>
  <td>7/8</td><td>8/8</td><td>9/8</td>
  </tr>
  <tr align="center">
	<td> &nbsp </td>
	<td><input type="radio" name="moln" value="0"></td> 
	<td><input type="radio" name="moln" value="1"></td>
	<td><input type="radio" name="moln" value="2"></td> 
	<td><input type="radio" name="moln" value="3"></td>
	<td><input type="radio" name="moln" value="4"></td>
	<td><input type="radio" name="moln" value="5"></td>
	<td><input type="radio" name="moln" value="6"></td>
	<td><input type="radio" name="moln" value="7"></td>
	<td><input type="radio" name="moln" value="8"></td>
	<td><input type="radio" name="moln" value="9"></td>
	</tr>	
  </table>
  <br>
<table align="center">
 <tr align="center">
 <td><b>Vindriktn</b>.:</td><td>--</td><td>N</td><td>NNE</td><td>NE</td><td>ENE</td><td>E</td><td>ESE</td>
 <td>SE</td><td>SSE</td><td>S</td><td>SSW</td><td>SW</td><td>WSW</td><td>W</td><td>WNW</td><td>NW</td><td>NNW</td>
 </tr>
 <tr align="center">
	<td> &nbsp </td>
	<td><input type="radio" name="vrikt" value="---"></td> 
	<td><input type="radio" name="vrikt" value="N"></td>
	<td><input type="radio" name="vrikt" value="NNE"></td> 
	<td><input type="radio" name="vrikt" value="NE"></td>
	<td><input type="radio" name="vrikt" value="ENE"></td>
	<td><input type="radio" name="vrikt" value="E"></td>
	<td><input type="radio" name="vrikt" value="ESE"></td>
	<td><input type="radio" name="vrikt" value="SE"></td>
	<td><input type="radio" name="vrikt" value="SSE"></td>
	<td><input type="radio" name="vrikt" value="S"></td>
	<td><input type="radio" name="vrikt" value="SSW"></td>
	<td><input type="radio" name="vrikt" value="SW"></td>
	<td><input type="radio" name="vrikt" value="WSW"></td>
	<td><input type="radio" name="vrikt" value="W"></td>
	<td><input type="radio" name="vrikt" value="WNW"></td>
	<td><input type="radio" name="vrikt" value="NW"></td>
	<td><input type="radio" name="vrikt" value="NNW"></td>
	</tr>	
  </table>
  <br>
  <p><b>Vindstyrka</b>: 
  <input type="text" size="2" name="vsty" style="font-family: Verdana; font-size: 11px; color: #000080"> m/s&nbsp;&nbsp;&nbsp;     
  <b>Temp</b>: 
  <input type="text" size="5" name="temp" style="font-family: Verdana; font-size: 11px; color: #000080">&nbsp;&nbsp;&nbsp;    
  <b>Lufttryck</b>: 
  <input type="text" size="6" name="tryck" style="font-family: Verdana; font-size: 11px; color: #000080"></p>
  
  <p><b>V�der</b> <br>
	(f�r att markera mer �n ett alternativ: h�ll ned CTRL och klicka):<br> 
    <select name="vader[]" size="16" multiple style="font-family: Verdana; font-size: 11px; color: #000080"> 
	<option value="00">inget sign.</option>
	<option value="01">klart</option>
	<option value="02">n�stan klart</option>
	<option value="03">delvis molnigt</option>
	<option value="04">n�stan mulet</option>
	<option value="05">mulet</option>
	<option value="10">fuktdis</option>
    <option value="11">markdimma</option>
    <option value="13">kornblixt</option>
    <option value="15">nederb�rd inom synh�ll</option>
	<option value="17">�ska p� avst�nd</option>
	<option value="19">tromb</option>
	<option value="30">sn�drev</option>
    <option value="40">dimma p� avst�nd</option>
    <option value="44">dimma</option>
    <option value="46">underkyld dimma</option> 	
    <option value="50">duggregn</option> 
    <option value="56">underkylt duggregn</option>
	<option value="60">regn</option>
    <option value="66">underkylt regn</option>
	<option value="69">sn�blandat regn</option> 
    <option value="70">sn�fall</option> 
    <option value="77">kornsn�</option> 	
    <option value="80">regnskurar</option> 
    <option value="83">byar av sn�blandat regn</option>
    <option value="85">sn�byar</option>
	<option value="87">sn�hagel</option>
 	<option value="89">sm�hagel</option>
	<option value="95">�ska</option>
  </select> 
  <p> 
      <input type="submit" value="Skicka" style="color: #FFFFFF; font-size: 11px; font-weight: bold; font-family: Verdana; border-left: 2px solid #99CCFF; border-right: 2px solid #0066CC; border-top: 2px solid #99CCFF; border-bottom: 2px solid #0066CC; margin-top: 0; margin-bottom: 0; background-color: #0099FF"> 
      <input type="reset" value="�ngra" style="font-size: 11px; font-family: Verdana; font-weight: bold; color: #FFFFFF; border-left: 2px solid #99CCFF; border-right: 2px solid #0066CC; border-top: 2px solid #99CCFF; border-bottom: 2px solid #0066CC; background-color: #0099FF"> 
      </p> 
    </form> 
</div>
  </body> 
</html> 