<?php
//include "../incl_filer/db_connect.php"; //databasanslutning 
//Dold r�knare f�r antalet guidade/grupper innevarande �r
//automatisk uppr�kning av p�g�ende �r till dold tabell guide_count
//automatisk �verf�ring till totallistan efter varje �rsskifte

//innevarande �r
$thisyear=date('Y');

//kolla om �rsskifte har intr�ffat
//�rtalet i uppr�knaren guide_count 
 $sql_y="SELECT year from guide_count";
 $query_y=mysqli_query($connect, $sql_y) or die (mysqli_error($connect));
 while ($row=mysqli_fetch_assoc($query_y))
 {$year_i_db=$row['year'];}

//om �rtalet �r samma r�kna upp/om guide_count
 if ($year_i_db==$thisyear)
 {
//antal guidade v�r
  $guidade_s=0;
  $sql_spring="SELECT G_klar, SUM(G_antal) AS ready_s from besokstider  
  WHERE substring(besokstider.Datum,1,4)='$thisyear'
  AND substr(besokstider.Datum,6,5)>='01-01' AND substr(besokstider.Datum,6,5)<='06-30'
  AND G_klar='J'
  GROUP BY G_klar";
  $query_spring=mysqli_query($connect, $sql_spring) or die(mysqli_error($connect));
  while ($row=mysqli_fetch_assoc($query_spring))
  {$guidade_s=$row['ready_s'];}

//antal grupper v�r
  $sql_spring_grupp="Select * from besokstider  
  WHERE substring(besokstider.Datum,1,4)='$thisyear'
  AND substr(besokstider.Datum,6,5)>='01-01' AND substr(besokstider.Datum,6,5)<='06-30'
  AND G_klar='J'";
  $query_spring_grupp=mysqli_query($connect, $sql_spring_grupp) or die(mysqli_error($connect));
  $numro_s=mysqli_num_rows($query_spring_grupp);
 
//antal guidade h�st
  $guidade_a=0;
  $sql_autumn="SELECT G_klar, SUM(G_antal) AS ready_a from besokstider  
  WHERE substring(besokstider.Datum,1,4)='$thisyear'
  AND substr(besokstider.Datum,6,5)>='07-01' AND  substr(besokstider.Datum,6,5)<='12-31'
  AND G_klar='J'
  GROUP BY G_klar";
  $query_autumn=mysqli_query($connect, $sql_autumn) or die(mysqli_error($connect));
  while ($row=mysqli_fetch_assoc($query_autumn))
  {$guidade_a=$row['ready_a'];}

//antal grupper h�st
  $sql_aut_grupp="Select * from besokstider  
  WHERE substring(besokstider.Datum,1,4)='$thisyear'
  AND substr(besokstider.Datum,6,5)>='07-01' AND substr(besokstider.Datum,6,5)<='12-31'
  AND G_klar='J'";
  $query_aut_grupp=mysqli_query($connect, $sql_aut_grupp) or die(mysqli_error($connect));
  $numro_a=mysqli_num_rows($query_aut_grupp);

//�rssummor 
  $guidade_y=$guidade_s + $guidade_a;
  $numro_y=$numro_s + $numro_a;

//uppdatera guide_count  
  $sql_uppdatera="UPDATE guide_count SET no_spring='$guidade_s', grp_spring='$numro_s', 
  no_autumn='$guidade_a', grp_autumn='$numro_a', no_year='$guidade_y', grp_year='$numro_y'"; 
  mysqli_query($connect, $sql_uppdatera) or die (mysqli_error($connect));
  
  //echo $guidade_s.' '.$numro_s.' '.$guidade_a.' '.$numro_a.' '.$guidade_y.' '.$numro_y;
 } 
 else
//om �rsskifte �gt rum - uppdatera totallistan och nollst�ll guide_count
 {$sql_oldyear="SELECT * from guide_count";
  $query_oldyear=mysqli_query($connect, $sql_oldyear) or die (mysqli_error($connect));
  while ($row=mysqli_fetch_assoc($query_oldyear))
  {$year_o=$row['year'];
   $nospr_o=$row['no_spring'];
   $grspr_o=$row['grp_spring'];
   $noaut_o=$row['no_autumn'];
   $graut_o=$row['grp_autumn'];
   $noyear_o=$row['no_year'];
   $gryear_o=$row['grp_year'];
// echo $year_o.' '.$nospr_o.' '.$grspr_o.' '.$noaut_o.' '.$graut_o.' '.$noyear_o.' '.$gryear_o;
  } 
//�verf�r till totallistan
  $sql_addera="INSERT into guidade (year, no_spring, grp_spring, no_autumn, grp_autumn, no_year, grp_year) 
  VALUES ('$year_o', '$nospr_o', '$grspr_o', '$noaut_o', '$graut_o', '$noyear_o', '$gryear_o')";
  mysqli_query($connect, $sql_addera) or die (mysqli_error($connect));

//rensa guide_count
  $sql_uppdatera="UPDATE guide_count SET year='$thisyear', no_spring=0, grp_spring=0, 
  no_autumn=0, grp_autumn=0, no_year=0, grp_year=0"; 
  mysqli_query($connect, $sql_uppdatera) or die (mysqli_error($connect));
 
  //echo 'Data f�r '.$year_o.' �verf�rda till totallistan - r�knaren nollst�lld.';
 }
?>