<?php
include "../incl_filer/db_connect.php"; //databasanslutning
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Bokningsuppgifter</title>
<LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
<script language="JavaScript" src="../overlib.js">
</script>
<script type="text/javascript">
<!--
  var ol_width=140; //sätter bredden på popuprutan
//-->
</script>
<style>
p
{
 margin-top: 6px;
 margin-bottom: 6px;
}
</style>
</head>

<body>
<p align="center"><font style="font-size:12px"><b>BOKNING AV GUIDNING - ÄNDRING, BORTTAGNING</b></font></p>
<table width="100%" border="0" cell-padding="5" class="alt_tab_bg">
<tr>
<td width="50%" valign="top">
<p><b>Adressuppgifter:</b></p>
<?php
 $idnr=$_REQUEST['id'];
 
//ta ut adressuppgifter 
 $sql_boknuppg="SELECT * from guidebokning WHERE G_ID='$idnr'"; 
 $query_boknuppg=mysqli_query($connect, $sql_boknuppg) or die (mysqli_error($connect));
  
//ta ut tidsuppgifter för vald bokning 
 $sql_tidsuppg="SELECT * from besokstider WHERE G_ID='$idnr' ORDER by Datum,Tid";
 $query_tidsuppg=mysqli_query($connect, $sql_tidsuppg) or die (mysqli_error($connect));

//gör variabler
 while ($row=mysqli_fetch_assoc($query_boknuppg))
 {$grupp=$row['Grupp'];
  $gatuadr=$row['G_gatuadr'];
  $ponr=$row['G_postnr'];
  $town=$row['G_ort'];
  $best=$row['Best_namn'];
  $btel_1=$row['Best_tel1'];
  $btel_2=$row['Best_tel2'];
  $bepost=$row['Best_epost'];
  $faknamn=$row['Fakt_namn'];
  $fakid=$row['Fakt_idnr'];
  $fakgata=$row['Fakt_adr'];
  $fakponr=$row['Fakt_postnr'];
  $faktown=$row['Fakt_ort'];
  $anm1=$row['Anm_1'];
  $anm2=$row['Anm_2'];
 } 

if (isset($_REQUEST['adrbokning']) && !empty($_REQUEST['grupp']) && !empty($_REQUEST['G_gata'])
 && !empty($_REQUEST['G_pnr']) && !empty($_REQUEST['G_stad']) && !empty($_REQUEST['best_av'])
 && !empty($_REQUEST['B_tel1']) && $_REQUEST['ny_uppdat']=='upd') 
{$grupp=$_REQUEST['grupp'];
 $G_gatan=$_REQUEST['G_gata'];
 $G_pnr=$_REQUEST['G_pnr'];
 $G_stad=$_REQUEST['G_stad'];
 $best_av=$_REQUEST['best_av'];
 $B_tel1=$_REQUEST['B_tel1'];
 $B_tel2=$_REQUEST['B_tel2'];
 $B_epost=$_REQUEST['B_epost'];
 $faktura=$_REQUEST['faktura'];
 $F_idnr=$_REQUEST['F_idnr'];
 $F_gata=$_REQUEST['F_gata'];
 $F_pnr=$_REQUEST['F_pnr'];
 $F_stad=$_REQUEST['F_stad'];
 $extra_1=$_REQUEST['extra_1'];
 $extra_2=$_REQUEST['extra_2']; 

//UPPDATERA post i tabell för grupper och beställare
 $idnr=$_REQUEST['id'];
 $sql_bokn="UPDATE guidebokning SET Grupp='$grupp', G_gatuadr='$G_gatan', G_postnr='$G_pnr', 
 G_ort='$G_stad', Best_namn='$best_av', Best_tel1='$B_tel1', Best_tel2='$B_tel2',
 Best_epost='$B_epost', Fakt_namn='$faktura', Fakt_idnr='$F_idnr', Fakt_adr='$F_gata', Fakt_postnr='$F_pnr', 
 Fakt_ort='$F_stad', Anm_1='$extra_1', Anm_2='$extra_2' WHERE G_ID='$idnr'";
 mysqli_query($connect, $sql_bokn) or die (mysqli_error($connect));
  
 echo '</td><td valign="bottom">
 <form style="margin-top: 6px" name="uppdat" method="POST" action="'.$_SERVER['PHP_SELF'].'">
 <input type="hidden" value="'.$idnr.'" name="id">
 <input name="visa_upd" type="submit" value="Uppdatera sidan (visa ändringar)" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">
 </form>';
}
elseif (isset($_REQUEST['adrbort']) && $_REQUEST['post_bort']=='borta')
{$idnr=$_REQUEST['id'];
//TA BORT post i tabell för grupper och beställare
 $sql_adrbort="DELETE from guidebokning WHERE G_ID='$idnr'";
  mysqli_query($connect, $sql_adrbort) or die (mysqli_error($connect));
  
 $sql_tidbort="DELETE from besokstider WHERE G_ID='$idnr'";
  mysqli_query($connect, $sql_tidbort) or die (mysqli_error($connect));

 echo '<b>Posten, inkl tidsbokningar, är borttagen ur databasen!</b>';
}
elseif (isset($_REQUEST['tidbokning']) && !empty($_REQUEST['datum']) && !empty($_REQUEST['tid'])
 && !empty($_REQUEST['G_deltant']) && $_REQUEST['ny_uppdat']=='upd')
{$idnr=$_REQUEST['id'];
 $rec_no=$_REQUEST['tidnr'];
 $datum=$_REQUEST['datum'];
 $kl=$_REQUEST['tid'];
 $antal=$_REQUEST['G_deltant'];
 $alder=$_REQUEST['G_alder'];
 $klar=$_REQUEST['G_klar'];
   
//UPPDATERA post i tabell med tidsbokningar 
  $sql_tidbokn="UPDATE besokstider SET datum='$datum', tid='$kl', G_antal='$antal', G_alder='$alder',
  G_klar='$klar' WHERE G_ID='$idnr' AND T_ID='$rec_no'";
  mysqli_query($connect, $sql_tidbokn) or die (mysqli_error($connect));
  
 //mysqli_close($connect);
  echo '</td><td valign="bottom">
 <form style="margin-top: 6px" name="uppdat" method="POST" action="'.$_SERVER['PHP_SELF'].'">
 <input type="hidden" value="'.$idnr.'" name="id">
 <input name="visa_upd" type="submit" value="Uppdatera sidan (visa ändringar)" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">
 </form>';

}
elseif (isset($_REQUEST['tidbort']) && $_REQUEST['post_bort']=='bort')
{$idnr=$_REQUEST['id'];
 $rec_no=$_REQUEST['tidnr'];

//TA BORT en tidsbokning ur databasen 
  $sql_tidbort="DELETE from besokstider WHERE T_ID='$rec_no'";
  mysqli_query($connect, $sql_tidbort) or die (mysqli_error($connect));
  
 //mysqli_close($connect);
 echo '</td><td valign="bottom">
 <form style="margin-top: 6px" name="uppdat" method="POST" action="'.$_SERVER['PHP_SELF'].'">
 <input type="hidden" value="'.$idnr.'" name="id">
 <input name="visa_upd" type="submit" value="Uppdatera sidan (visa ändringar)" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">
 </form>';}
else
{ 
echo '
<p><b>Ändra/ta bort</b>
<form style="margin-top: 6px; margin-bottom: 0 px" name="bokning" method="POST" action="'.$_SERVER['PHP_SELF'].'">
 <table width="100%" class="alt_tab_bg" style="cell-padding:3px; border: 0px; border-collapse: collapse">
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Finns inget gruppnamn - skriv beställarens namn, t.ex. Kalle Kulas grupp.\');"
 onMouseOut="nd();">
 Grupp (skola, org. etc.):
 </td><td width="60%">
 <input type="text" size="40" value="'.$grupp.'" name="grupp">*
 </td></tr>
 <tr><td width="40%" align="right">
 Gatuadress/box:
 </td><td width="60%">
 <input type="text" size="40" value="'.$gatuadr.'" name="G_gata">*
 </td></tr>
 <tr><td width="40%" align="right">
 Postnummer (000 00):
 </td><td width="60%">
 <input type="text" size="10" value="'.$ponr.'" name="G_pnr">*
 </td></tr>
 <tr><td width="40%" align="right">
 Ort: 
 </td><td width="60%">
 <input type="text" size="30" value="'.$town.'" name="G_stad">*
 </td></tr>
 <tr><td width="40%" align="right">
 Beställare (person):
 </td><td width="60%">
 <input type="text" size="40" value="'.$best.'" name="best_av">*
 </td></tr>
 <tr><td width="40%" align="right">
 Best. telefon 1:
 </td><td width="60%">
 <input type="text" size="15" value="'.$btel_1.'" name="B_tel1">*
 </td></tr>
 <tr><td width="40%" align="right">
 Best. telefon 2:
 </td><td width="60%">
 <input type="text" size="15" value="'.$btel_2.'" name="B_tel2">
 </td></tr>
 <tr><td width="40%" align="right">
 Best. e-postadress:
 </td><td width="60%">
 <input type="text" size="40" value="'.$bepost.'" name="B_epost">
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Om annan än ovan.\');"
 onMouseOut="nd();">
 Fakturamottagare: 
 </td><td width="60%">
 <input type="text" size="40" value="'.$faknamn.'" name="faktura"><br>
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Nummer eller kod som angivits av beställaren.\');"
 onMouseOut="nd();">
 Faktura_idnr: 
 </td><td width="60%">
 <input type="text" size="40" value="'.$fakid.'" name="F_idnr"><br>
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Om annan än ovan.\');"
 onMouseOut="nd();">
 Faktura_gatuadress/box: 
 </td><td width="60%">
 <input type="text" size="40" value="'.$fakgata.'" name="F_gata"><br>
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Om annat än ovan.\');"
 onMouseOut="nd();">
 Faktura postnummer (000 00):
 </td><td width="60%">
 <input type="text" size="10" value="'.$fakponr.'" name="F_pnr"><br>
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Om annan än ovan.\');"
 onMouseOut="nd();">
 Faktura_ort:
 </td><td width="60%">
 <input type="text" size="30" value="'.$faktown.'" name="F_stad"><br>
 </td></tr>
 <tr><td width="40%" align="right">
 Anm. 1:
 </td><td width="60%">
 <input type="text" size="30" value="'.$anm1.'" name="extra_1"><br>
 </td></tr>
 <tr><td width="40%" align="right">
 Anm. 2: 
 </td><td width="60%">
 <input type="text" size="30" value="'.$anm2.'" name="extra_2">
 </td></tr></table>
 <input type="hidden" value="'.$idnr.'" name="id">
 <input type="hidden" value="upd" name="ny_uppdat"> 
<p>
<input style="width:75px" name="adrbokning" type="submit" value="Ändra" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;Ändrar innehåll i ovanstående fält (ej tidsbokningar).
</form>
<form style="margin-top: 6px; margin-bottom: 0 px" name="tabort" method="POST" action="'.$_SERVER['PHP_SELF'].'">
  <input type="hidden" value="'.$idnr.'" name="id">
  <input type="hidden" value="borta" name="post_bort">
  <input style="width:75px" name="adrbort" type="submit" value="Ta bort" class="submit"
  onMouseOver="overlib(\'OBS. Radera INTE klarmarkerade, de behövs för sammanräkningen!\'); this.style.color=\'blue\'" 
  onMouseOut="nd(); this.style.color=\'#FFFFFF\'">&nbsp;Raderar <b>alla</b> uppgifter inkl. tidsbokningar.

  </form>
</td>
<td width="50%" valign="top">
<p><b>Tidsuppgifter:</b>
<p><b>Ändra/ta bort</b></p>
<table width="90%" border="0" cellpadding="5" cellspacing="0" class="alt_tab_bg">
<tr class="tablehead">
<td>Datum</td><td>Kl.</td><td>Antal</td><td>Ålder</td><td>Klar</td>
<td colspan="2" align="center">Åtgärd</td>
</tr>';

//ta ut tidsuppgifter för vald bokning 
 $sql_tidsuppg="SELECT * from besokstider WHERE G_ID='$idnr' ORDER by Datum,Tid";
 $query_tidsuppg=mysqli_query($connect, $sql_tidsuppg) or die (mysqli_error($connect));
 $rader=mysqli_num_rows($query_tidsuppg);
 while ($row=mysqli_fetch_assoc($query_tidsuppg))
 {$idnr=$row['G_ID'];
  $var_tid=$row['T_ID'];
  echo '
  <form style="margin-top: 6px; margin-bottom: 0 px" name="tidsbokn" method="POST" action="'.$_SERVER['PHP_SELF'].'">
  <tr>
  <td><input type="text" size="10" name="datum" value="'.$row['Datum'].'">*</td>
  <td><input type="text" size="5" name="tid" value="'.$row['Tid'].'">*</td>
  <td><input type="text" size="3" name="G_deltant" value="'.$row['G_antal'].'">*</td>
  <td><input type="text" size="10" name="G_alder" value="'.$row['G_alder'].'"></td>
  <td><input type="text" size="3" name="G_klar" value="'.$row['G_klar'].'"></td>
  <input type="hidden" value="'.$var_tid.'" name="tidnr">
  <input type="hidden" value="'.$idnr.'" name="id">
  <input type="hidden" value="upd" name="ny_uppdat"> 
  <td>
  <input name="tidbokning" type="submit" value="Ändra" class="submit"
  onMouseOver="overlib(\'Ändra denna post.\'); this.style.color=\'blue\'" 
  onMouseOut="nd(); this.style.color=\'#FFFFFF\'">
  </form>
  </td>
  <form style="margin-top: 6px; margin-bottom: 0 px" name="tabort" method="POST" action="'.$_SERVER['PHP_SELF'].'">
  <input type="hidden" value="'.$var_tid.'" name="tidnr">
  <input type="hidden" value="'.$idnr.'" name="id">
  <input type="hidden" value="bort" name="post_bort">
  <td>
  <input name="tidbort" type="submit" value="Ta bort" class="submit"
  onMouseOver="overlib(\'Ta bort denna post.\'); this.style.color=\'blue\'" 
  onMouseOut="nd(); this.style.color=\'#FFFFFF\'">
  </form>
  
  </td>
  </tr>';
 } 
 echo '</table>
 OBS.<br>Om det bara finns EN tid inbokad och den skall tas bort - ta bort den här om adressuppgifterna 
  skall sparas.<br>Annars tar du bort <b>alla</b> uppgifter med Ta bort-knappen t.v. '; 
?>
<p>&nbsp;</p>
<p>
<b>Bokningsbekräftelse</b><br>
Om uppgifterna är OK, kan du skriva ut en bokningsbekräftelse här:<p>
<button style="width:250px" onclick="location.href='bokn_bekr.php?id=<?php echo $idnr; ?>'"
 onMouseOver="this.style.color='blue'" 
 onMouseOut="this.style.color='#FFFFFF'">Visa bokningsbekräftelse</button>
</p>
<p>
&nbsp;</p>
<p>
<b>Klarmarkering</b><br>
Efter besöket:<br> Ändra Antal från prel. antal till faktiskt antal och Klar till J.<br>
Detta medför att tidsbokningen överförs från listan på förstasidan<br>
till en lista över säsongens genomförda guidningar (som kan skrivas ut).
</p>
<p>
<button style="width:250px" onclick="location.href='guideklara.php'"
 onMouseOver="this.style.color='blue'" 
 onMouseOut="this.style.color='#FFFFFF'">Visa klarmarkerade</button>
</p>
<p>&nbsp;</p>
<?php 
}
include "guidestats.php";
?>
</p>
</td></tr></table>
<p align="center">
<button style="width:350px" onclick="location.href='guideblock.php'"
 onMouseOver="this.style.color='blue'" 
 onMouseOut="this.style.color='#FFFFFF'">Tillbaka till bokningssidan</button>
</p>
</body>
</html>