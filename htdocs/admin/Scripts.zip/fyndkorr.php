
<!-- DENNA FIL �R EN HOPSAMLING AV FORMUL�R F�R �NDRING I BEFINTLIGA FYND
ObS. ATT HIDDEN INPUT KOMMER F�RST I DET SISTA STEGET D� MAN SATT �NDRINGARNA 
I POSTEN MED VALT FYND_ID!! -->


<title>tempor�r fil med fyndkorr</title>


if(isset($_REQUEST['spara']) && $_REQUEST['korrart']!='--arter som finns i fyndlistan--')
  {$art=$_REQUEST['korrart'];
   echo $art.'<br>';
   echo '<Form style="font-size=11px" name="Fynd_id" method="POST" action="artlistadm.php">
   <p>Nedan visas de fynd av den valda arten som finns i listan.<br>
   Markera det fynd som skall �ndras.</p>
   <p><select name="idlista" 
   style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">';
   //Lista fynd
   $sql_id="SELECT Fynd_ID, ART, FDATUM from fyndlista WHERE ART='$art' ORDER BY FDATUM";
   $query_id=mysqli_query($connect, $sql_id);
   while ($row=mysqli_fetch_assoc($query_id))
   {echo '<option value="'.$row['Fynd_ID'].'">'.$row['Fynd_ID'].'&nbsp;'.$row['ART'].'&nbsp;'.$row['FDATUM'].'</option>';}
   echo '</select>
   <p>
   <input name="idnr" type="submit" value="V�lj fynd" class="submit"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">
   <input name="Reset" type="reset" value="Avbryt" class="submit"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
   <button style="width: 65px" OnClick="javascript:history.back()"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button>
   </form>';
  }
  else
  {die ('Fel i f�ltet ART:<br>Ingen art angiven!
   <p><button style="width: 65px" OnClick="javascript:history.back()"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>');
  }
 }