<?php 
include "../incl_filer/db_connect.php"; //databasanslutning
?> 

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="imagetoolbar" content="no">
<title>�ndra art- och fyndlistor</title>
<LINK REL=STYLESHEET TYPE="text/css" HREF="../bluemall.css">
<SCRIPT LANGUAGE="JavaScript">
<!-- G�m skriptet -->
// This script and many more are available free online at 
// The JavaScript Source!! http://javascript.internet.com 
// John Munn (jrmunn@home.com)
// Begin
function putFocus(formInst, elementInst) {
if (document.forms.length > 0) {
document.forms[formInst].elements[elementInst].focus();
}
}

function fonster(URL)
{
//url �r s�kv�gen till filen som �ppnas i f�nstret lankfonster
var oppna = open(URL, "lankfonster", "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, width=600, height=400, top=150, left=288")
}

function openWindow(form) 
{
//�ppnar ett f�nster fr�n ett formul�r med GET, d�rav fr�getecknet i var url
 var url = "filename.php?";
 url += "name=" + form.typ.value;
 window.open(url,"editwin","left=273, top=157, width=668, height=480, toolbar=no, location=no, scrollbars=yes");
}
// Sluta g�mma -->
</SCRIPT>
<script language="JavaScript" src="../overlib.js">
</script>
<script type="text/javascript">
<!--
  var ol_width=125; //s�tter bredden p� popuprutan
//-->
</script>
</head>

<body class="alt_tab_bg" style="background-image: url('artlistadm.php')">
<?php
if (isset($_REQUEST['spara']) && $_REQUEST['act']=='uppdatera') //namn p� submitknappen + HIDDEN FIELD
{
//
//UPPDATERA F�REKOMST ETC. I ARTLISTAN
//
 echo '<p><b>Artlistan</b></p>';
 $art=$_REQUEST['artval_1'];
 $sql_snr="select SNR, SVNAMN from artnamn WHERE ART='$art'";
 $query_snr=mysqli_query($connect, $sql_snr);
 while($row=mysqli_fetch_assoc($query_snr))
 {
  $snr=$row['SNR'];
  $sve_art=$row['SVNAMN'];
 }
 echo 'Valda �ndringar utf�rs nu f�r '.$sve_art.':';
 foreach ($_POST['falt'] AS $id => $falt) 
 {$new_value=$_POST['change'][$id];
  echo '<p>'.$falt.' �ndras till '.$new_value.'</p>';
  $sql_upd="UPDATE artlista SET $falt='$new_value' WHERE ART='$art'";
  mysqli_query($connect, $sql_upd); 
 }
 echo '<p><b>Artlistan har uppdaterats.</b></p>';
//visa den nya posten 
 $sql_visa="SELECT * from artlista WHERE ART='$art'";
 $query_visa=mysqli_query($connect, $sql_visa);
 echo '<table width="797" cellspacing="0">
 <tr class="tablehead">
   <td align="left" width="240">ART </td>
   <td align="center" width="40">JAN</td>
   <td align="center" width="40">FEB</td>
   <td align="center" width="40">MAR</td>
   <td align="center" width="40">APR</td>
   <td align="center" width="40">MAJ</td>
   <td align="center" width="40">JUN</td>
   <td align="center" width="40">JUL</td>
   <td align="center" width="40">AUG</td>
   <td align="center" width="40">SEP</td>
   <td align="center" width="40">OKT</td>
   <td align="center" width="40">NOV</td>
   <td align="center" width="40">DEC</td>
   <td align="center" width="40">HAC</td>
   <td align="center" width="40">FYN</td>
 </tr>
 <tr><td width="240">'.$sve_art.'</td>';
 while($row=mysqli_fetch_assoc($query_visa))
 {echo '
  <td align="center" width="40">'.$row['JAN'].'</td>
  <td align="center" width="40">'.$row['FEB'].'</td>
  <td align="center" width="40">'.$row['MAR'].'</td>
  <td align="center" width="40">'.$row['APR'].'</td>
  <td align="center" width="40">'.$row['MAJ'].'</td>
  <td align="center" width="40">'.$row['JUN'].'</td>
  <td align="center" width="40">'.$row['JUL'].'</td>
  <td align="center" width="40">'.$row['AUG'].'</td>
  <td align="center" width="40">'.$row['SEP'].'</td>
  <td align="center" width="40">'.$row['OKT'].'</td>
  <td align="center" width="40">'.$row['NOV'].'</td>
  <td align="center" width="40">'.$row['DCE'].'</td>
  <td align="center" width="40">'.$row['HAC'].'</td>
  <td align="center" width="40">'.$row['FYN'].'</td>
  </tr>';
 }
 echo '</table>';
 echo '<p>�r det n�got som inte st�mmer f�r du g�ra en ny �ndring...';
 echo '<form name="tillbaka" method="POST" action="artlistadm.php">
 <input type="hidden" name="R1" value="start">
 </p>
 <input type="submit" value="Tillbaka" class="submit" name="B1"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"> 
 </form>';
}
elseif (isset($_REQUEST['spara']) && $_REQUEST['act']=='nyart')
{
//
//L�GG TILL NY ART I ARTLISTAN
//
 echo '<p><b>Artlistan</b></p>';
 $nyart=$_REQUEST['ny_art'];
 $jan=$_REQUEST['JAN'];
 $feb=$_REQUEST['FEB'];
 $mar=$_REQUEST['MAR'];
 $apr=$_REQUEST['APR'];
 $maj=$_REQUEST['MAJ'];
 $jun=$_REQUEST['JUN'];
 $jul=$_REQUEST['JUL'];
 $aug=$_REQUEST['AUG'];
 $sep=$_REQUEST['SEP'];
 $okt=$_REQUEST['OKT'];
 $nov=$_REQUEST['NOV'];
 $dce=$_REQUEST['DCE'];
 $hac=$_REQUEST['HAC'];
 $fyn=$_REQUEST['FYN'];
 $sql_snr="select SNR, SVNAMN from artnamn WHERE ART='$nyart'";
 $query_snr=mysqli_query($connect, $sql_snr);
 while($row=mysqli_fetch_assoc($query_snr))
 {
  $snr=$row['SNR'];
  $sve_art=$row['SVNAMN'];
 }
 $sql_upd="INSERT INTO artlista () 
 VALUES ($snr, '$nyart', '$jan', '$feb', '$mar', '$apr', '$maj', '$jun', '$jul', '$aug', '$sep', '$okt', '$nov', '$dce', '$hac', '$fyn')";
 mysqli_query($connect, $sql_upd);
 echo $sve_art.' har lagts till i artlistan.</p>';
//visa den �ndrade posten
 $sql_visa="SELECT * from artlista WHERE ART='$nyart'";
 $query_visa=mysqli_query($connect, $sql_visa);
 echo '<table width="797" cellspacing="0">
 <tr class="tablehead">
   <td align="left" width="240">ART </td>
   <td align="center" width="40">JAN</td>
   <td align="center" width="40">FEB</td>
   <td align="center" width="40">MAR</td>
   <td align="center" width="40">APR</td>
   <td align="center" width="40">MAJ</td>
   <td align="center" width="40">JUN</td>
   <td align="center" width="40">JUL</td>
   <td align="center" width="40">AUG</td>
   <td align="center" width="40">SEP</td>
   <td align="center" width="40">OKT</td>
   <td align="center" width="40">NOV</td>
   <td align="center" width="40">DEC</td>
   <td align="center" width="40">HAC</td>
   <td align="center" width="40">FYN</td>
 </tr>
 <tr><td width="240">'.$sve_art.'</td>';
 while($row=mysqli_fetch_assoc($query_visa))
 {echo '
  <td align="center" width="40">'.$row['JAN'].'</td>
  <td align="center" width="40">'.$row['FEB'].'</td>
  <td align="center" width="40">'.$row['MAR'].'</td>
  <td align="center" width="40">'.$row['APR'].'</td>
  <td align="center" width="40">'.$row['MAJ'].'</td>
  <td align="center" width="40">'.$row['JUN'].'</td>
  <td align="center" width="40">'.$row['JUL'].'</td>
  <td align="center" width="40">'.$row['AUG'].'</td>
  <td align="center" width="40">'.$row['SEP'].'</td>
  <td align="center" width="40">'.$row['OKT'].'</td>
  <td align="center" width="40">'.$row['NOV'].'</td>
  <td align="center" width="40">'.$row['DCE'].'</td>
  <td align="center" width="40">'.$row['HAC'].'</td>
  <td align="center" width="40">'.$row['FYN'].'</td>
  </tr>';
 }
 echo '</table>'; 
 echo '<p>�r det n�got som inte st�mmer f�r du g�ra en �ndring...';
 echo '<form name="tillbaka" method="POST" action="artlistadm.php">
 <input type="hidden" name="R1" value="start">
 </p>
 <input type="submit" value="Tillbaka" class="submit" name="B1"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"> 
 </form>';
}
elseif (isset($_REQUEST['spara']) && $_REQUEST['act']=='radera_art')
{
//
//TA BORT EN BEFINTLIG ART FR�N ARTLISTAN 
//
 echo '<p><b>Artlistan</b></p>';
 if ($_REQUEST['bekrafta']=='J' || $_REQUEST['bekrafta']=='j')
 { 
 $delart=$_REQUEST['arten'];
 $sve_art=$_REQUEST['svart'];
 //TA BORT ARTEN
 $sql_del="DELETE from artlista WHERE ART='$delart'";
 mysqli_query($connect, $sql_del);
 
 echo '<p>'.$sve_art.' har tagits bort fr�n artlistan.';
 }
 else
 {echo 'Processen har avbrutits.';}  
 
 echo '<form name="tillbaka" method="POST" action="artlistadm.php">
 <input type="hidden" name="R1" value="start">
 </p>
 <input type="submit" value="Tillbaka" class="submit" name="B1"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"> 
 </form>';
}
elseif (isset($_REQUEST['spara']) && $_REQUEST['act']=='fynd_korr')
{
//
//UPPDATERA BEFINTLIGA FYND I FYNDLISTAN 
//
 echo '<p><b>Fyndlistan</b></p>';
 
 if (isset($_REQUEST['falt']))
 {$sve_art=$_REQUEST['SV1'];
  $IDNR=$_REQUEST['F_id'];
  echo 'F�ljande �ndringar g�rs nu f�r fynd nr. '.$IDNR.', '.$sve_art.':';
  foreach ($_POST['falt'] AS $id => $falt) 
  {$new_value=$_POST['change'][$id];
   echo '<p>'.$falt.' �ndras till '.$new_value.'</p>';
  
   $sql_upd="UPDATE fyndlista SET $falt='$new_value' WHERE Fynd_ID='$IDNR'";
   mysqli_query($connect, $sql_upd); 
  }
  echo '<p><b>Fyndlistan har uppdaterats.</b><br>
  �r det n�got som inte st�mmer f�r du g�ra en ny �ndring...';
  }
  else
  {echo 'Ett fel uppstod.<br>Kolla att valda f�lt �r f�rbockade i �ndringsformul�ret!';}
 echo '<form name="tillbaka" method="POST" action="artlistadm.php">
 <input type="hidden" name="R1" value="start">
 </p>
 <input type="submit" value="Tillbaka" class="submit" name="B1"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"> 
 </form>';
}
elseif (isset($_REQUEST['spara']) && $_REQUEST['act']=='fynd_add')
{
//
//UPPDATERA FYNDLISTAN (l�gg till NYA FYND f�r bef. eller NYA ARTER)
//
echo '<p><b>Fyndlistan</b></p>';
//kontrollera data som skickas med formul�ret
if ($_REQUEST['F1']=='bef_art' && $_REQUEST['fyndart']!='--arter som finns i fyndlistan--')
{$art=$_REQUEST['fyndart'];} //RCKOD
elseif ($_REQUEST['F1']=='ny_art' && $_REQUEST['fyndart']!='--------  arter som finns i namnlistan  --------')
{$art=$_REQUEST['ny_fyndart'];} //RCKOD
else
{die ('Fel i f�ltet ART:<br>Ingen art angiven!
 <p><button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>');}
//h�mta snr
$sql_snr="SELECT SNR, SVNAMN from artnamn WHERE art='$art'";
$query_snr=mysqli_query($connect, $sql_snr);
while ($row=mysqli_fetch_assoc($query_snr))
{$snr=$row['SNR'];
 $sve_art=$row['SVNAMN'];}
$faltlista='(SNR'; 
$valuelist='('.$snr;
$faltlista=$faltlista.', ART';
$valuelist=$valuelist.', "'.$art.'"';
//kontroll av datum
$year=substr($_REQUEST['FDAT'],0,4);
$monad=substr($_REQUEST['FDAT'],5,2);
$dag=substr($_REQUEST['FDAT'],8,2);
if (checkdate($monad, $dag, $year)==true)
{$fdat=$_REQUEST['FDAT'];
 $faltlista=$faltlista.', FDATUM';
 $valuelist=$valuelist.', "'.$fdat.'"';} 
else
{die ('Fel i F�ltet FDAT:<br>Felaktig datumangivelse eller datum saknas - m�ste anges.
 <p><button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>');}
if (!empty($_REQUEST['SDAT']))
{$year=substr($_REQUEST['SDAT'],0,4);
 $monad=substr($_REQUEST['SDAT'],5,2);
 $dag=substr($_REQUEST['SDAT'],8,2);
 if (checkdate($monad, $dag, $year)==true)
 {$sdat=$_REQUEST['SDAT'];
  $faltlista=$faltlista.', SDATUM';
  $valuelist=$valuelist.', "'.$sdat.'"';}
 else
 {die ('Fel i f�ltet SDAT:<br>Felaktig datumangivelse.
  <p><button style="width: 65px" OnClick="javascript:history.back()"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>');}
}    
if (!empty($_REQUEST['ANTAL']))
{$antal=$_REQUEST['ANTAL'];
 $faltlista=$faltlista.', ANTAL';
 $valuelist=$valuelist.', '.$antal;}
else 
{die ('Fel i f�ltet ANTAL:<br>Antal m�ste anges.
 <p><button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>');}
if (!empty($_REQUEST['aldrar']) && $_REQUEST['aldrar']!='-- v�lj h�r --')
{$age=$_REQUEST['aldrar'];
 $faltlista=$faltlista.', AGE_N';
 $valuelist=$valuelist.', '.$age;}
else
{$age='';}
if (!empty($_REQUEST['sex']) && $_REQUEST['sex']!='-- v�lj h�r --')
{$sex=$_REQUEST['sex'];
 $faltlista=$faltlista.', SEX_N';
 $valuelist=$valuelist.', '.$sex;}
else
{$sex='';}
if (!empty($_REQUEST['aktiv']) && $_REQUEST['aktiv']!='-- v�lj h�r --')
{$aktiv=$_REQUEST['aktiv'];
 $faltlista=$faltlista.', AKTIV_N';
 $valuelist=$valuelist.', '.$aktiv;}
else
{$aktiv='';}
if (!empty($_REQUEST['LOKAL']))
{$lokal=$_REQUEST['LOKAL'];
 $faltlista=$faltlista.', LOKAL';
 $valuelist=$valuelist.', "'.$lokal.'"';}
else
{die ('Fel i f�ltet LOKAL:<br>Lokal m�ste anges.
 <p><button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>');}
if (!empty($_REQUEST['FYND']))
{$fynd=$_REQUEST['FYND'];
 $faltlista=$faltlista.', FYND';
 $valuelist=$valuelist.', '.$fynd;}
else
{die ('Fel i f�ltet FYND:<br>Fyndnummer. m�ste anges. Se befintliga fyndlistor.
 <p><button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>');}
if (!empty($_REQUEST['IND']))
{$ind=$_REQUEST['IND'];
 $faltlista=$faltlista.', IND';
 $valuelist=$valuelist.', '.$ind;}
else
{die ('Fel i f�ltet IND:<br>Individsumma m�ste anges. Se befintliga fyndlistor.
 <p><button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>');}
if (!empty($_REQUEST['sveex']) && !empty ($_REQUEST['engex']))
{$sveex=$_REQUEST['sveex'];
 $engex=$_REQUEST['engex'];
 $faltlista=$faltlista.', SVEEXTRA, ENGEXTRA';
 $valuelist=$valuelist.', "'.$sveex.'", "'.$engex.'"';}
else
{$sveex='';
 $engex='';}
if (!empty ($_REQUEST['REF']))
{$ref=$_REQUEST['REF'];
 $faltlista=$faltlista.', REF';
 $valuelist=$valuelist.', "'.$ref.'"';}
else
{die ('Fel i f�ltet REF:<br>Referens m�ste anges. Se lista /l�gg till ny.
 <p><button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>');}
$faltlista=$faltlista.')';
$valuelist=$valuelist.')';
 
if (!empty($_REQUEST['kort']) && !empty ($_REQUEST['sve']) && !empty ($_REQUEST['eng']))
{//nya ref: 
 $kort=$_REQUEST['kort'];
 $sve=$_REQUEST['sve'];
 $eng=$_REQUEST['eng'];
 $sql_ref="INSERT into referenser (REF_KORT, REF_TEXT, REF_ENG)
 VALUES ('$kort', '$sve', '$eng')";
 mysqli_query($connect, $sql_ref);
 echo 'Ny referens har lagts till.';}
else
{$kort='';
 $sve='';
 $eng='';}

//db-uppdatering
$sql_add="INSERT into fyndlista $faltlista
VALUES $valuelist";
mysqli_query($connect, $sql_add);

echo 'Uppdateringar har verkst�llts enl. nedanst�ende f�r '.$sve_art.'.</p><p>';
// visa uppdatering
$sql_maxid="select art, max(Fynd_ID) as LATEST from fyndlista
WHERE art='$art' GROUP BY art";
$query_maxid=mysqli_query($connect, $sql_maxid);
while ($row=mysqli_fetch_assoc($query_maxid))
{$maxid=$row['LATEST'];}
$sql_visa="SELECT * from vy_svefynd
WHERE Fynd_ID='$maxid'";
$query_visa=mysqli_query($connect, $sql_visa);
echo '
<table border="0" cellspacing="0" width="850">
<tr class="tablehead">
     <td>Fynd_ID</td>
     <td>Art</td>
     <td>FDATUM</td>
     <td>SDATUM</td>
     <td align="right">ANTAL</td>
     <td width="5">&nbsp;</td>
     <td>�LDER</td>
     <td>K�N</td>
     <td>AKTIVITET</td>
     <td>LOKAL</td>
     <td align="right">FYND</td>
     <td align="right">IND</td>
     <td width="5">&nbsp;</td>
     <td align="center">EXTRA</td>
     <td width="5">&nbsp;</td>
     <td>REF</td>
</tr>';
while ($row=mysqli_fetch_assoc($query_visa))
{ echo '<tr>
  <td>'.$row['Fynd_ID'].'</td>
  <td>'.$row['SVNAMN'].'</td>
  <td>'.$row['FDATUM'].'</td>
  <td>'.$row['SDATUM'].'</td>
  <td align="right">'.$row['ANTAL'].'</td>
  <td width="5">&nbsp;</td>
  <td>'.$row['Alder'].'</td>
  <td>'.$row['SVESEX'].'</td>
  <td>'.$row['Aktivitet'].'</td>
  <td>'.$row['LOKAL'].'</td>
  <td align="right">'.$row['FYND'].'</td>
  <td align="right">'.$row['IND'].'</td>
  <td width="5">&nbsp;</td>';
  if ($row['SVEEXTRA']!='')
  {$sveinfo=$row['SVEEXTRA']; ?>
   <td align="center" width="40">
   <img border="0" align="center" src="bilder/info2.jpg"
   onMouseOver="overlib('<?php echo $sveinfo; ?>')" 
   onMouseOut="nd()">
   </td>
  <?php
  }
  else
  {echo '<td align="center" width="40">'.$row['SVEEXTRA'].'</td>';}
  echo '<td width="5">&nbsp;</td>
    <td>'.$row['REF'].'</td>
    </tr>';
 } 
 echo '</table>';
 echo '<form name="tillbaka" method="POST" action="artlistadm.php">
 <input type="hidden" name="R1" value="start">
 </p>
 <input type="submit" value="Tillbaka" class="submit" name="B1"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"> 
 </form>';
}
elseif (isset($_REQUEST['spara']) && $_REQUEST['act']=='radera_fynd')
{
//
//TA BORT FYND FR�N FYNDLISTAN 
//
 echo '<p><b>Fyndlistan</b></p>';
 if ($_REQUEST['bekrafta']=='J' || $_REQUEST['bekrafta']=='j')
 { 
 $idnr=$_REQUEST['idnummer'];
 $delart=$_REQUEST['arten'];
 $sve_art=$_REQUEST['svart'];
  
 $sql_del="DELETE from fyndlista WHERE Fynd_ID='$idnr'";
 mysqli_query($connect, $sql_del); 
 
 echo '<p>Fynd nr. '.$idnr.' '.$sve_art.' har tagits bort fr�n fyndlistan.';
 }
 else
 {echo 'Ett fel uppstod. Processen har avbrutits.';}  
 echo '<form name="tillbaka" method="POST" action="artlistadm.php">
 <input type="hidden" name="R1" value="start">
 </p>
 <input type="submit" value="Tillbaka" class="submit" name="B1"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"> 
 </form>';
}
else
//
//FORMUL�R F�R UPPDATERING AV ARTLISTAN
//
{if (isset($_REQUEST['B1']) && $_REQUEST['R1']=='V1')
 {echo '<p><b>Artlistan</p>
 <Form style="font-size=11px" name="Artl_upd" method="POST" action="artlistadm.php">
 V�lj ut art som ska uppdateras:</b><br>
 <select name="artval_1" 
 style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
 <option selected>-- arter som finns i artlistan --</option>';
// v�lj ut art som ska uppdateras
 $sql_artval="SELECT distinct artlista.ART, artnamn.SVNAMN from artlista, artnamn 
 WHERE artlista.ART=artnamn.ART order by artlista.SNR";
 $query_artval=mysqli_query($connect, $sql_artval);
 while ($row=mysqli_fetch_assoc($query_artval))
 {echo '<option value="'.$row['ART'].'">'.$row['SVNAMN'].'</option>';}
 echo '</select>
 <p><b>V�lj f�lt (kolumner) som ska �ndras (m�nad, h�ckning, fynd):</b><br>
 OBS. F�ltnamnet <b>m�ste</b> markeras f�r att �ndringen skall verkst�llas.</p>
 <table>
   <tr><td><input type="checkbox" style="border:0" name="falt[1]" value="JAN">&nbsp;<b>Januari</b></td>
   <td><select name="change[1]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[2]" value="FEB">&nbsp;<b>Februari</b></td>
   <td><select name="change[2]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[3]" value="MAR">&nbsp;<b>Mars</b></td>
   <td><select name="change[3]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[4]" value="APR">&nbsp;<b>April</b></td>
   <td><select name="change[4]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[5]" value="MAJ">&nbsp;<b>Maj</b></td>
   <td><select name="change[5]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[6]" value="JUN">&nbsp;<b>Juni</b></td>
   <td><select name="change[6]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[7]" value="JUL">&nbsp;<b>Juli</b></td>
   <td><select name="change[7]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[8]" value="AUG">&nbsp;<b>Augusti</b></td>
   <td><select name="change[8]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[9]" value="SEP">&nbsp;<b>September</b></td>
   <td><select name="change[9]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[10]" value="OKT">&nbsp;<b>Oktober</b></td>
   <td><select name="change[10]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[11]" value="NOV">&nbsp;<b>November</b></td>
   <td><select name="change[11]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[12]" value="DCE">&nbsp;<b>December</b></td>
   <td><select name="change[12]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej antr�ffad</option>
   <option value="1">1 mkt. s�llsynt</option>
   <option value="2">2 s�llsynt</option>
   <option value="3">3 sparsam</option>
   <option value="4">4 t�ml. allm�n</option>
   <option value="5">5 allm�n</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[13]" value="HAC">&nbsp;<b>H�ckning</b></td>
   <td><select name="change[13]">
   <option selected >-- v�lj h�r --</option>
   <option value="-">- ej h�ckande</option>
   <option value="(h)">(h) har h�ckat f�re 1980</option>
   <option value="h">h har h�ckat efter 1980</option>
   <option value="H">H h�ckar �rligen</option>
   </select></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[14]" value="FYN">&nbsp;<b>Visa fynd</b></td>
   <td><select name="change[14]">
   <option selected >-- v�lj h�r --</option>
   <option value="nej">nej - visa inte</option>
   <option value="ja">ja - visa fynd</option>
   </select></td></tr>
 </table>
 <p>
 <input type="hidden" name="act" value="uppdatera"> 
 <input name="spara" type="submit" value="Uppdatera" class="submit"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">
 <input name="Reset" type="reset" value="Avbryt" class="submit"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
 <button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>';
 }
 elseif (isset($_REQUEST['B1']) && $_REQUEST['R1']=='V2')
//
//FORMUL�R F�R ATT L�GGA TILL NY ART I ARTLISTAN 
//
 {echo '<p><b>Artlistan</p>
 <Form style="font-size=11px" name="Artl_nyart" method="POST" action="artlistadm.php">
 L�gg till en ny art:</b></p>
 <p>Markera den nya arten i listan:<br>
 <select name="ny_art" 
 style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
 <option selected>--------  arter som finns i namnlistan  --------</option>';
 $sql_nyart="select ART, SVNAMN from artnamn order by SNR";
 $query_nyart=mysqli_query($connect, $sql_nyart);
 while ($row=mysqli_fetch_assoc($query_nyart))
 {echo '<option value="'.$row['ART'].'">'.$row['SVNAMN'].'</option>';}
 echo '</select>';
 echo '<p><b>Ange m�nadsf�rekomst:</b><br>
 -: Ej antr�ffad.<br>
 1: Mycket s�llsynt. F�rre �n 10 fynd i aktuell m�nad.<br>
 2: S�llsynt. Arten f�rekommer s�llsynt men �rligen eller n�stan �rligen.<br>
 3: Sparsam. Arten f�rekommer regelbundet men sparsamt.<br>
 4: T�mligen allm�n. Arten f�rekommer t�mligen rikligt och chansen �r stor att p�tr�ffa den.<br>
 5: Allm�n. Arten f�rekommer rikligt och ses ofta.</p>
 <table border="0" width="550px" cellpadding="0" style="border-width:0; border-collapse: collapse" 
class="alt_tab_bg" id="table11">
 <tr>
 <td>Jan</td><td>Feb</td><td>Mar</td><td>Apr</td><td>Maj</td><td>Jun</td><td>Jul</td>
 <td>Aug</td><td>Sep</td><td>Okt</td><td>Nov</td><td>Dec</td>
 </tr>
 <tr>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="JAN"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="FEB"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="MAR"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="APR"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="MAJ"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="JUN"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="JUL"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="AUG"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="SEP"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="OKT"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="NOV"></td>
 <td><input type="text" style="font-size: 11 px; color: navy" size="3" name="DCE"></td>
 </tr></table>
 <p><b>Ange h�ckningsstatus: </b><input type="text" style="font-size: 11 px; color: navy" size="3" name="HAC"><br>
 -: Ej antr�ffad som h�ckande.<br>
 (h): Arten har h�ckat, dock inte efter 1980.<br>
 h: Arten har h�ckat efter 1980, dock ej �rligen.<br>
 H: Arten h�ckar regelbundet (�rligen).</p>
 <p><b> Visa fyndlista? J/N: </b>
 <input type="text" style="font-size: 11 px; color: navy" size="3" name="FYN">
 <input name="act" type="hidden" value="nyart">
 <p>
 <input name="spara" type="submit" value="L�gg till" class="submit"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">
 <input name="Reset" type="reset" value="Avbryt" class="submit"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
 <button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>';
 }
 elseif (isset($_REQUEST['B1']) && $_REQUEST['R1']=='V3')
 {
//
//FORMUL�R F�R ATT TA BORT EN ART FR�N ARTLISTAN
//
//KONTROLL OM BORTTAGNINGEN SKALL UTF�RAS
 if (isset($_REQUEST['skicka']) && $_REQUEST['artval_d']!='-- arter som finns i artlistan --')
  {echo '<p><b>Artlistan</b></p>';
   $del_art=$_REQUEST['artval_d'];
//ta ut svenskt artnamn
   $sql_snr="select SNR, SVNAMN from artnamn WHERE ART='$del_art'";
   $query_snr=mysqli_query($connect, $sql_snr);
   while($row=mysqli_fetch_assoc($query_snr))
   {
    $snr=$row['SNR'];
    $sve_art=$row['SVNAMN'];
   }
   echo '<form style="font-size=11px" name="confirm" method="POST" action="artlistadm.php">';
   echo '�r du helt s�ker p� att du vill ta bort '.$sve_art.'? J/N
   <input type="text" name="bekrafta" size="2">
   <input type="hidden" name="arten" value="'.$del_art.'">
   <input type="hidden" name="svart" value="'.$sve_art.'">
   <input type="hidden" name="act" value="radera_art">
   <p>
   <input name="spara" type="submit" value="Forts�tt" class="submit" 
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">
   <input name="Reset" type="reset" value="Avbryt" class="submit"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
   <button style="width: 65px" OnClick="javascript:history.back()"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button>
   </form>';
  }
  else
  {echo '<p><b>Artlistan</b></p>';
   echo '<Form style="font-size=11px" name="Artl_del_1" method="POST" action="artlistadm.php">
   V�lj ut art som ska tas bort:</b><br>
   <select name="artval_d" 
   style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
   <option selected>-- arter som finns i artlistan --</option>';
//v�lj ut art som ska tas bort
   $sql_artval="SELECT distinct artlista.ART, artnamn.SVNAMN from artlista, artnamn 
   WHERE artlista.ART=artnamn.ART order by artlista.SNR";
   $query_artval=mysqli_query($connect, $sql_artval);
   while ($row=mysqli_fetch_assoc($query_artval))
   {echo '<option value="'.$row['ART'].'">'.$row['SVNAMN'].'</option>';}
   echo '</select>
   <p>
   <input type="hidden" name="B1" value="XX">
   <input type="hidden" name="R1" value="V3">
   <input name="skicka" type="submit" value="Ta bort" class="submit"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">
   <input name="Reset" type="reset" value="Avbryt" class="submit"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
   <button style="width: 65px" OnClick="javascript:history.back()"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>';
  }
 } 
 elseif (isset($_REQUEST['B1']) && $_REQUEST['R1']=='V4')
//
//FORMUL�R F�R ATT �NDRA BEFINTLIGA FYND I FYNDLISTAN
//
 {echo '<p><b>Fyndlistan</b></p>';  
//3. OM FYND_ID �R VALT - SKICKA KORRUPPGIFTER 
  if(isset($_REQUEST['id_nr']))
  {$id=$_REQUEST['idlista'];
 // h�mta svenskt artnamn    
    $sve_art=$_REQUEST['SV1'];
   echo 'Korrigering av uppgifter f�r <b>'.$sve_art.'</b>, fynd ID: '.$id.':';
   echo '<Form style="font-size=11px" name="Fynd_falt" method="POST" action="artlistadm.php">
   <p><b>V�lj f�lt (kolumner) som ska �ndras och fyll i �ndringen:</b><br>
   OBS. F�ltnamnen <b>m�ste</b> vara markerade f�r att �ndringen ska tr�da i kraft.</p>
   <table>
   <tr><td><input type="checkbox" style="border:0" name="falt[1]" value="FDATUM">&nbsp;<b>F�rsta datum</b></td>
   <td><input type="text" size="10" name="change[1]"> ����-mm-dd</td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[2]" value="SDATUM">&nbsp;<b>Sista datum</b></td>
   <td><input type="text" size="10" name="change[2]"> ����-mm-dd</td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[3]" value="ANTAL">&nbsp;<b>Antal ind.</b></td>
   <td><input type="text" size="10" name="change[3]"></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[4]" value="AGE_N">&nbsp;<b>�lder</b></td>
   <td><select name="change[4]" 
   style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
   <option selected >-- v�lj h�r --</option>';
   $sql_age="Select * from ages order by Alder";
   $query_age=mysqli_query($connect, $sql_age);
   while ($row=mysqli_fetch_assoc($query_age))
   {echo '<option value="'.$row['Age_ID'].'">'.$row['Alder'].'</option>';}
   echo '<option value=" ">BLANK</option>';
   echo '</select> en sifferkod motsvarande den valda �lderskategorin l�ggs till i fyndlistan.
   BLANK tar bort inneh�llet och l�mnar f�ltet tomt.</td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[5]" value="SEX_N">&nbsp;<b>K�n</b></td>
   <td><select name="change[5]" 
   style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
   <option selected>-- v�lj h�r --</option>'; 
   $sql_sex="Select * from sex order by Sex_ID";
   $query_sex=mysqli_query($connect, $sql_sex);
   while ($row=mysqli_fetch_assoc($query_sex))
   {echo '<option value="'.$row['Sex_ID'].'">'.$row['Svesex'].'</option>';}
   echo '<option value=" ">BLANK</option>';
   echo '</select> en sifferkod motsvarande den valda k�nskategorin l�ggs till i fyndlistan.
   BLANK tar bort inneh�llet och l�mnar f�ltet tomt.</td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[6]" value="AKTIV_N">&nbsp;<b>Aktivitet</b></td>
   <td><select name="change[6]" 
   style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
   <option selected>-- v�lj h�r --</option>'; 
   $sql_akt="Select * from aktiv order by Aktiv_ID";
   $query_akt=mysqli_query($connect, $sql_akt);
   while ($row=mysqli_fetch_assoc($query_akt))
   {echo '<option value="'.$row['Aktiv_ID'].'">'.$row['Aktivitet'].'</option>';}
   echo '<option value=" ">BLANK</option>';
   echo '</select> en sifferkod motsvarande den valda aktiviteten l�ggs till i fyndlistan.
   BLANK tar bort inneh�llet och l�mnar f�ltet tomt.</td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[7]" value="LOKAL">&nbsp;
   <b>Lokal (max. 30 tkn.)</b><br>Skriv detaljer i Extra info.</td>
   <td><input type="text" size="50" maxlength="30" name="change[7]"></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[8]" value="FYND">&nbsp;<b>Fyndnr.</b></td>
   <td><input type="text" size="5" name="change[8]"></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[9]" value="IND">&nbsp;<b>Summa individer</b></td>
   <td><input type="text" size="5" name="change[9]"></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[10]" value="SVEEXTRA">&nbsp;<b>Extra info (sve)</b></td>
   <td><input type="text" maxlength="100" name="change[10]"></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[11]" value="ENGEXTRA">&nbsp;<b>Extra info (eng)</b></td>
   <td><input type="text" maxlength="100" name="change[11]"></td></tr>
   <tr><td><input type="checkbox" style="border:0" name="falt[12]" value="REF">&nbsp;<b>Referens (kort)</b></td>
   <td><input type="text" maxlength="20" name="change[12]"> t.ex. FiSk 2006</td></tr>
   </table>
   <p>
   <input type="hidden" name="SV1" value="'.$sve_art.'">
   <input type="hidden" name="F_id" value="'.$id.'">
   <input type="hidden" name="act" value="fynd_korr">
   <input name="spara" type="submit" value="�ndra" class="submit"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">
   <input name="Reset" type="reset" value="Avbryt" class="submit"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
   <button style="width: 65px" OnClick="javascript:history.back()"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button>
   </form>';
  }
//2. OM ARTVAL �R GJORT - V�LJ FYND_ID
  else 
  {if(isset($_REQUEST['valart']) && $_REQUEST['korrart']!='--arter som finns i fyndlistan--') 
   {$art=$_REQUEST['korrart'];
// h�mta svenskt artnamn    
    $sql_sv="SELECT SVNAMN from artnamn WHERE art='$art'";
    $query_sv=mysqli_query($connect, $sql_sv);
    while ($row=mysqli_fetch_assoc($query_sv))
    {$sve_art=$row['SVNAMN'];}
    echo '<Form style="font-size=11px" name="Fynd_id" method="POST" action="artlistadm.php">
    <p>Nedan visas de fynd av <b>'.$sve_art.'</b> som finns i listan.<br>
    Markera det fynd som skall �ndras.</p>
    <p><select name="idlista" 
    style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">';
    //Lista fynd
    $sql_id="SELECT Fynd_ID, ART, FDATUM from fyndlista WHERE ART='$art' ORDER BY FDATUM";
    $query_id=mysqli_query($connect, $sql_id);
    while ($row=mysqli_fetch_assoc($query_id))
    {echo '<option value="'.$row['Fynd_ID'].'">'.$row['Fynd_ID'].'&nbsp;'.$row['ART'].'&nbsp;'.$row['FDATUM'].'</option>';}
    echo '</select>
    <p>
    <input type="hidden" name="SV1" value="'.$sve_art.'">
    <input type="hidden" name="B1" value="x">
    <input type="hidden" name="R1" value="V4">
    <input name="id_nr" type="submit" value="V�lj fynd" class="submit"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">
    <input name="Reset" type="reset" value="Avbryt" class="submit"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
    <button style="width: 65px" OnClick="javascript:history.back()"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button>
    </form>';
   }
   else
//1. VAL AV ART
   {echo '<Form style="font-size=11px" name="Fynd_upd" method="POST" action="artlistadm.php">
    <p>V�lj art fr�n fyndlistan:</p>
    <select name="korrart" 
    style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
    <option selected>--arter som finns i fyndlistan--</option>';
//V�lj BEFINTLIG ART fr�n DD-meny
    $sql_artval="SELECT distinct fyndlista.ART, artnamn.SVNAMN from fyndlista, artnamn 
    WHERE fyndlista.ART=artnamn.ART order by fyndlista.snr";
    $query_artval=mysqli_query($connect, $sql_artval);
    while ($row=mysqli_fetch_assoc($query_artval))
    {echo '<option value="'.$row['ART'].'">'.$row['SVNAMN'].'</option>';}
    echo '</select>
    <p>
    <input type="hidden" name="B1" value="x">
    <input type="hidden" name="R1" value="V4">
    <input name="valart" type="submit" value="V�lj art" class="submit"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">
    <input name="Reset" type="reset" value="Avbryt" class="submit"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
    <button style="width: 65px" OnClick="javascript:history.back()"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button>
    </form>';
   }
  } 
 }   
 elseif (isset($_REQUEST['B1']) && $_REQUEST['R1']=='V5')
//
//FORMUL�R F�R ATT L�GGA TILL FYND I FYNDLISTAN F�R BEFINTLIGA/NYA ARTER
//
 {echo '<p><b>Fyndlistan</b></p>';
 echo '<Form style="font-size=11px" name="Fynd_upd" method="POST" action="artlistadm.php">
 <input type="radio" value="bef_art" name="F1">V�lj ut befintlig art*:
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 &nbsp;&nbsp;&nbsp;
 ...ELLER...&nbsp;
 <input type="radio" value="ny_art" name="F1">L�gg till en ny art*:<br>
 <select name="fyndart" 
 style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
 <option selected>--arter som finns i fyndlistan--</option>';
 //V�lj BEFINTLIG ART fr�n DD-meny
 $sql_artval="SELECT distinct fyndlista.ART, artnamn.SVNAMN from fyndlista, artnamn 
 WHERE fyndlista.ART=artnamn.ART order by fyndlista.SNR";
 $query_artval=mysqli_query($connect, $sql_artval);
 while ($row=mysqli_fetch_assoc($query_artval))
 {echo '<option value="'.$row['ART'].'">'.$row['SVNAMN'].'</option>';}
 echo '</select>';
//L�gg till NY ART vald fr�n DD-meny
 echo'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="ny_fyndart" 
 style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
 <option selected>--------  arter som finns i namnlistan  --------</option>';
 $sql_nyart="select ART, SVNAMN from artnamn order by SNR";
 $query_nyart=mysqli_query($connect, $sql_nyart);
 while ($row=mysqli_fetch_assoc($query_nyart))
 {echo '<option value="'.$row['ART'].'">'.$row['SVNAMN'].'</option>';}
 echo '</select>';
//OBSDATUM ANTAL
 echo '<p> Ange f�rsta obsdatum (����-mm-dd)*: <input type="text" size="10" name="FDAT"><br>
 Ange sista obsdatum (����-mm-dd, om det INTE �r samma som f�reg.): <input type="text" size="10" name="SDAT"><br>
 Ange antal individer: <input type="text" size="5" name="ANTAL"><br>';
//�LDER K�N AKTIVITET
 echo '<p>Om uppgifter finns...<br>
 Ange �lder: 
 <select name="aldrar" 
 style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
 <option selected >-- v�lj h�r --</option>';
 $sql_age="Select * from ages order by Alder";
 $query_age=mysqli_query($connect, $sql_age);
 while ($row=mysqli_fetch_assoc($query_age))
 {echo '<option value="'.$row['Age_ID'].'">'.$row['Alder'].'</option>';}
 echo '</select>
 &nbsp
 Ange k�n: 
 <select name="sex" 
 style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
 <option selected>-- v�lj h�r --</option>'; 
 $sql_sex="Select * from sex order by Sex_ID";
 $query_sex=mysqli_query($connect, $sql_sex);
 while ($row=mysqli_fetch_assoc($query_sex))
 {echo '<option value="'.$row['Sex_ID'].'">'.$row['Svesex'].'</option>';}
 echo '</select>
 &nbsp
 Ange aktivitet: 
 <select name="aktiv" 
 style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
 <option selected>-- v�lj h�r --</option>'; 
 $sql_akt="Select * from aktiv order by Aktiv_ID";
 $query_akt=mysqli_query($connect, $sql_akt);
 while ($row=mysqli_fetch_assoc($query_akt))
 {echo '<option value="'.$row['Aktiv_ID'].'">'.$row['Aktivitet'].'</option>';}
 echo '</select>';
//LOKAL FYND IND SVEEXTRA ENGEXTRA REF 
 echo '<p>Ange lokal (max. 30 tecken). F�r det inte plats, l�gg detaljer i Extrainfo.*:<br>
 <input type="text" size="50" maxlength="30" name="LOKAL">
 <p>Ange fyndnr*: 
 <input type="text" size="5" name="FYND">&nbsp;&nbsp;
 Ange individsumma*:
 <input type="text" size="5" name="IND">
 <p>Ange ev. extrainfo - OBS. m�ste fyllas i p� b�da spr�ken:<br>
 svensk:&nbsp;<input type="text" size="100" name="sveex"><br>
 English:&nbsp;<input type="text" size="100" name="engex"><br>
 <p>Ange referens (bef. f�rkortning)*:<br>
 <input type="text" size="30" maxlength="25" name="REF">&nbsp; 
 <button style="width:150px; font-size:10px" onclick="javascript:fonster(\'refer.php\')"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Hj�lp: Visa referenser</button>
 <p style="font-size:11 px">L�gg till ny referens:<br>
 F�rkortning.........: <input type="text" maxlength="25" name="kort"><br>
 Full text, svenska: <input type="text" size="100" name="sve"><br>
 Full text, English..: <input type="text" size="100" name="eng">
 <input name="act" type="hidden" value="fynd_add">
 <p>*=m�ste alltid fyllas i.
 <input name="spara" type="submit" value="L�gg till" class="submit"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">
 <input name="Reset" type="reset" value="Avbryt" class="submit"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
 <button style="width: 65px" OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button>
 </form>';
 }
 elseif (isset($_REQUEST['B1']) && $_REQUEST['R1']=='V6')
//
//FORMUL�R F�R ATT TA BORT FYND FR�N FYNDLISTAN
//
 {echo '<p><b>Fyndlistan</b></p>';
  
//3. OM FYND_ID �R VALT - BEKR�FTA
  if(isset($_REQUEST['id_nr']))
  {$id=$_REQUEST['idlista'];
   $artkod=$_REQUEST['RCkod'];
   $sve_art=$_REQUEST['SV1'];
   echo '<form style="font-size=11px" name="confirm" method="POST" action="artlistadm.php">';
   echo '�r du helt s�ker p� att du vill ta bort fyndet nr. '.$id.' '.$sve_art.'? J/N
   <input type="text" name="bekrafta" size="2">
   <input type="hidden" name="idnummer" value="'.$id.'">
   <input type="hidden" name="arten" value="'.$artkod.'">
   <input type="hidden" name="svart" value="'.$sve_art.'">
   <input type="hidden" name="act" value="radera_fynd">
   <p>
   <input name="spara" type="submit" value="Forts�tt" class="submit" 
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">
   <input name="Reset" type="reset" value="Avbryt" class="submit"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
   <button style="width: 65px" OnClick="javascript:history.back()"
   onMouseOver="this.style.color=\'blue\'" 
   onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button>
   </form>';
  } 
//2. OM ARTVAL �R GJORT - V�LJ FYND_ID
  else 
  {if(isset($_REQUEST['valart']) && $_REQUEST['delart']!='--arter som finns i fyndlistan--') 
   {$art=$_REQUEST['delart'];
// h�mta svenskt artnamn    
    $sql_sv="SELECT SVNAMN from artnamn WHERE art='$art'";
    $query_sv=mysqli_query($connect, $sql_sv);
    while ($row=mysqli_fetch_assoc($query_sv))
    {$sve_art=$row['SVNAMN'];}
    echo '<Form style="font-size=11px" name="Fynd_id" method="POST" action="artlistadm.php">
    <p>Nedan visas de fynd av <b>'.$sve_art.'</b> som finns i listan.<br>
    Markera det fynd som skall tas bort.</p>
    <p><select name="idlista" 
    style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">';
    //Lista fynd
    $sql_id="SELECT Fynd_ID, ART, FDATUM from fyndlista WHERE ART='$art' ORDER BY FDATUM";
    $query_id=mysqli_query($connect, $sql_id);
    while ($row=mysqli_fetch_assoc($query_id))
    {echo '<option value="'.$row['Fynd_ID'].'">'.$row['Fynd_ID'].'&nbsp;'.$row['ART'].'&nbsp;'.$row['FDATUM'].'</option>';}
    echo '</select>
    <p>
    <input type="hidden" name="SV1" value="'.$sve_art.'">
    <input type="hidden" name="RCkod" value="'.$art.'">
    <input type="hidden" name="B1" value="x">
    <input type="hidden" name="R1" value="V6">
    <input name="id_nr" type="submit" value="V�lj fynd" class="submit"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">
    <input name="Reset" type="reset" value="Avbryt" class="submit"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
    <button style="width: 65px" OnClick="javascript:history.back()"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button>
    </form>';
   }
   else
//1. VAL AV ART
   {echo '<Form style="font-size=11px" name="Fynd_delete" method="POST" action="artlistadm.php">
    <p>V�lj art fr�n fyndlistan:</p>
    <select name="delart" 
    style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080">
    <option selected>--arter som finns i fyndlistan--</option>';
//V�lj BEFINTLIG ART fr�n DD-meny
    $sql_artval="SELECT distinct fyndlista.ART, artnamn.SVNAMN from fyndlista, artnamn 
    WHERE fyndlista.ART=artnamn.ART order by fyndlista.snr";
    $query_artval=mysqli_query($connect, $sql_artval);
    while ($row=mysqli_fetch_assoc($query_artval))
    {echo '<option value="'.$row['ART'].'">'.$row['SVNAMN'].'</option>';}
    echo '</select>
    <p>
    <input type="hidden" name="B1" value="x">
    <input type="hidden" name="R1" value="V6">
    <input name="valart" type="submit" value="V�lj art" class="submit"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">
    <input name="Reset" type="reset" value="Avbryt" class="submit"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
    <button style="width: 65px" OnClick="javascript:history.back()"
    onMouseOver="this.style.color=\'blue\'" 
    onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button>
    </form>';
   }
  }
 }
 else
// 
// FORMUL�R F�R ATT V�LJA �TG�RD OCH LISTA
// 
 {echo '�NDRA ART- OCH FYNDLISTORNA.
 <p><b>Artlistan</b></p>';
 // formul�r f�r att v�lja �tg�rd och lista
 echo '<form method="POST" action="artlistadm.php">
 <input type="radio" style="border: 0" value="V1" name="R1"> �ndra befintliga arter i ARTLISTAN.<br>
 <input type="radio" style="border: 0" value="V2" name="R1"> L�gga till ny art i ARTLISTAN.<br>
 <input type="radio" style="border: 0" value="V3" name="R1"> Ta bort en art fr�n ARTLISTAN.</p>
 <p><b>Fyndlistan</b></p>
 <p>
 <input type="radio" style="border: 0" value="V4" name="R1"> �ndra befintliga fynd i FYNDLISTAN.<br>
 <input type="radio" style="border: 0" value="V5" name="R1"> L�gga till nya fynd i FYNDLISTAN.<br>
 <input type="radio" style="border: 0" value="V6" name="R1"> Ta bort ett fynd fr�n FYNDLISTAN.</p>
 </p>
 <input type="submit" value="Forts�tt" class="submit" name="B1"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"> 
 </form>';
 echo '<p>';
 }
}
// st�ng databaskopplingen 
 mysqli_close($connect);
?>
</body>

</html>
