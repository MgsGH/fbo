<?php 
include "../incl_filer/db_connect.php"; //databasanslutning
//include "../incl_filer/clean.php"; //tar bort elaka tecken 
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Administration av Bildgalleriet</title>
<LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
</head>

<body>
<div align="center">
H�r bearbetas formul�rdata och adderas till databasen.<br>
<?php
//Kolla att formul�ret har skickats och �r ifyllt med r�tt sorts data
if ($_REQUEST['start']<>'' && $_REQUEST['artkod']<>''
 && $_REQUEST['dag']<>'' && $_REQUEST['plats']<>'' && $_REQUEST['bildfil']<>''
 && $_REQUEST['fotograf']<>'' && $_REQUEST['kategori']<>'')
//data som ska l�ggas till i tab bilder
{
 $in_art=($_REQUEST['artkod']);
 $in_datum=($_REQUEST['dag']);
 $in_plats=($_REQUEST['plats']);
 $in_bildfil=($_REQUEST['bildfil']);
 if (!empty($_REQUEST['svetext']) && !empty($_REQUEST['engtext']))
 {$in_sveextra=$_REQUEST['svetext'];
  $in_engextra=$_REQUEST['engtext'];}
 else
 {$in_sveextra='Extra info saknas...';
  $in_engextra='No extra info...';}

//kontrollera att arten finns eller angivits som saknad.
  if ($in_art=='LAND' || $in_art=='land')
  {echo '<p>Art angiven som "LAND". OK.';
   $artkoll='OK';}
  else
  {$sqlart="SELECT art FROM artnamn WHERE art='$in_art'";
   $query=mysqli_query($connect, $sqlart);
   $rader=mysqli_num_rows($query);
   if ($rader=='0')
    {$artkoll='ERROR'; echo '<p><font color="red">Arten finns inte i namnlistan.</font>';}
   else
    {$artkoll='OK'; echo '<p>Artnamn OK.';}
  }
  
//kontrollera att datumet �r ett datum
 $year=substr($in_datum,0,4);
 $monad=substr($in_datum,5,2);
 $dag=substr($in_datum,8,2);
 if (checkdate($monad, $dag, $year)==true)
  {$datkoll='OK'; echo '<p>Datum OK.';}
 else 
  {$datkoll='ERROR'; echo '<p><font color="red">Felaktigt datum.</font>';}
 
//kontrollera att bildfilen finns
 if (file_exists('../galleri/maxipix/'.$bildfil)==true)
  {$filkoll='OK'; echo '<p>Bildfilen har hittats.';} 
 else
  {$filkoll='ERROR'; echo '<p><font color="red">Bildfilen kan inte hittas.</font>';}

 if ($artkoll=='OK' && $datkoll=='OK' && $filkoll=='OK')
   {echo '<p>�verf�r data till databasen';
    //thumbnail
	$in_thumb='Th_'.$in_bildfil;

	//fotograf FotID 
	$in_fot=$_REQUEST ['fotograf'];

	//ta ut BildID f�r den inmatade bilden
	$utsql="SELECT MAX(BildID) AS latest FROM bilder";
	$query=mysqli_query($connect, $utsql);
	while($row=mysqli_fetch_assoc($query))
	{$in_bnr=$row['latest']+1;}

	//l�gg in data i tabellen bilder
	if ($in_art=='LAND' || $in_art=='land')
	{
	 $insql="INSERT INTO bilder (BildID, fotograf, art, datum, plats, bildfil)
	 values
	 ('$in_bnr', '$in_fot', 'LAND', '$in_datum', '$in_plats', '$in_bildfil')";
	 mysqli_query($connect, $insql);
    }
    else
    {
     $insql="INSERT INTO bilder (BildID, fotograf, art, datum, plats, bildfil)
	 values
	 ('$in_bnr', '$in_fot', '$in_art', '$in_datum', '$in_plats', '$in_bildfil')";
	 mysqli_query($connect, $insql);
	} 

	//l�gg till data i tabellen thumbpix
	//h�r m�ste man ha BildID fr�n tab Bilder med
	$insql="INSERT INTO thumbpix (BildID, fotograf, thumbs)
	values
	('$in_bnr', '$in_fot', '$in_thumb')";
	mysqli_query($connect, $insql);

	// om startsida ing�r, l�gg till data i tabellen midibilder
	//h�r m�ste man ha BildID fr�n tab Bilder med
	if ($_REQUEST['start']=='1')
	{$in_sbildfil='500_'.$in_bildfil;
 	$insql="INSERT INTO midibilder (bildnr, bildfil)
 	values
 	('$in_bnr', '$in_sbildfil')";
 	mysqli_query($connect, $insql);}

	//lista �ver vilka KatID som ska g�lla f�r bilden
	//h�r m�ste man ha BildID fr�n tab Bilder med
	foreach ($_REQUEST ['kategori'] as $kat)
	{$insql="INSERT INTO grupp_bild (GruppID, BildID)
	values
	('$kat', '$in_bnr')";
	mysqli_query($connect, $insql);}
	
	//l�gg in ev extrainfo
	//h�r m�ste man ha BildID fr�n tab Bilder med
	$insql="INSERT INTO extrainfo(BildID, Info, Enginfo)
 	values
 	('$in_bnr', '$in_sveextra', '$in_engextra')";
 	mysqli_query($connect, $insql);
  
    echo '<p>Inmatade data har sparats i databasen.<br>
    Bilden kan nu ses i s�v�l det svenska som det engelska galleriet';
  } 
 else
  {echo '<p>N�got blev fel (se ovan).<br>
   G� tillbaka och f�rs�k p� nytt!';}
}
else
{ echo '<p>Formul�ret �r felaktigt ifyllt.<br>
  G� tillbaka och f�rs�k p� nytt!';
}
// st�ng databaskopplingen 
 mysqli_close($connect);
?>
<p align="center">
<button target="self" style="width=146" 
OnClick="location.href='bildadm_upl.php'">
<font onMouseOver="this.color='blue'" onMouseOut="this.color='#FFFFFF'">Tillbaka</font>
</button>
&nbsp;&nbsp;
<button target="self" style="width=146" OnClick="location.href='../galleri/bilder_ram.htm'">
<font onMouseOver="this.color='blue'" onMouseOut="this.color='#FFFFFF'">G� till galleriet</font>
</button>
</p>
</div>
</body>

</html>
