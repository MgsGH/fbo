
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Hantera best�llningar fr�n webshopen</title>
<LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
<style>
p
{
 margin-top: 6px;
 margin-bottom: 6px;
}
</style>
<base target="_self">
</head>

<body class="alt_tab_bg" style="background-image: url('')">
<?php
//best�llning
//echo '<p><b>Administrera best�llningar inkomna via mail:</b></p>';
if (isset($_REQUEST['leverans']))
{$levdatum=$_REQUEST['klarmark'];
 $kund=$_REQUEST['kunden'];
 $sql_lev="update varukund SET levdag='$levdatum' WHERE kundnr='$kund'";
 mysqli_query($connect, $sql_lev) or die (mysqli_error($connect));
 echo '<p>Best�llningen �r packad, fakturerad och klar att s�ndas iv�g.<br>
 Leveransdatum (=idag) har lagts in i kundlistan.</p>';
}	   
elseif (isset($_REQUEST['visa_kundnr']))
{$kund=ltrim($_REQUEST['kundnummer']);
 $sql_best="SELECT * , (varukorg.antal*varor.pris) AS summa from varor, varukorg
 WHERE varukorg.kundnr='$kund'
 AND varukorg.artnr=varor.artnr
 AND varukorg.buy='J'
 ORDER by varukorg.artnr";
 $query_best=mysqli_query($connect, $sql_best) or die (mysqli_error($connect));
//avs�ndare 
 $sql_avs="SELECT * from varukund WHERE kundnr='$kund'";
 $query_avs=mysqli_query($connect, $sql_avs) or die (mysqli_error($connect));
 
 echo '<table cellpadding="3" cellspacing="0" width="600">
  <tr class="tablehead">
  <td colspan="6">
  Best�llning fr�n kundnr: '.$kund.'
  </td></tr>	  
  <tr class="tablehead">
  <td width="33" align="right">Antal</td><td width="360">Artikel</td><td>Storlek</td><td>&nbsp;</td>
  <td align="right">Pris/st.</td><td align="right">Summa</td></tr>';
  $farg='#FFFFFF';
  $totalt=0.00;
  while ($row=mysqli_fetch_assoc($query_best))
  {if ($farg=='#FFFFFF')
   {$farg='#E1E8F7';}
   else
   {$farg='#FFFFFF';}
   echo 
   '<tr bgcolor='.$farg.'>
    <td width="33" align="right">'.$row['antal'].'</td>
    <td width="360">'.$row['artikel'].'</td>
    <td>'.$row['size'].'</td>
    <td>Kr.</td>
    <td align="right">'.str_replace('.', ',', $row['pris']).'</td>
    <td align="right">'.str_replace('.', ',', $row['summa']).'</td>
    </tr>';
    $totalt=$totalt+$row['summa'];
  }
  echo '<tr class="tablehead">
  <td colspan="4">&nbsp;</td>
  <td align="right">Totalt:</td><td align="right">'.$totalt.',00</td>
  </tr>
  <tr class="alt_tab_bg"><td colspan="6" align="right">
  Postens avgifter tillkommer p� ovanst�ende summa.</td></tr>
 </table>';
 
 //best�llare
 while ($row=mysqli_fetch_assoc($query_avs))
  {echo '<p>Best�llt av: <br>'.$row['fnamn'].' '.$row['enamn'].'<br>'
   .$row['adress'].'<br>'
   .$row['postnr'].' '.$row['ort'].' '.$row['land'].'<br>'
   .$row['epost'].'</p>';
  }   
  echo '<p>1. Kopiera best�llningen, klista i den i ett mail och skicka till avs�ndaren.</p>';
  echo '<p>2. Packa de best�llda varorna (st�ng inte) och v�g f�rs�ndelsen.</p>';
  echo '<p>3. Skriv faktura. Klistra in kopian av best�llningen och l�gg till porto.</p>';
  echo '<p>4. Skriv ut fakturan i 2 ex. En skickas med f�rs�ndelsen, en skall KP ha.</p>';
  echo '<p>5. Klarmarkera. Dagens datum l�ggs till kunduppgifterna under "Levererat den..."</p>';
  $levdag=date('Y-m-d');
  echo '<form name="klar" method="POST" action="'.$_SERVER['PHP_SELF'].'">
  <input type="hidden" name="klarmark" value="'.$levdag.'">
  <input type="hidden" name="kunden" value="'.$kund.'">
  <p><input type="submit" name="leverans" value="Klar? Klicka h�r." class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'"></p> 
  </form>';
}
else
{echo '<form name="best_kundnr" method="POST" action="'.$_SERVER['PHP_SELF'].'">
 Klistra in kundnumret som kom med best�llningsmailet h�r:<br>
 <input type="text" size="50" name="kundnummer">
 <p><input type="submit" name="visa_kundnr" value="Visa best�llning" class="submit"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"></p>
 </form>';
}
?>
<p>&nbsp;</p>
<p><b>Administrera databastabellerna Varukorg och Varukund.</b></p>
<p> ej klart...</p>
</body>
</html>
