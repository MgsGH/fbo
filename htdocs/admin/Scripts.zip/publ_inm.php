<?php 
include "../incl_filer/db_connect.php"; //databasanslutning
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 

<html lang="sv">

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta http-equiv="content-style-type" content="text/css">
<meta name="author" content="FF">
<meta name="keywords" content="">
<meta http-equiv="imagetoolbar" content="no">
<title>Inmatning av nya publikationer</title>
<link rel="stylesheet" href="../bluemall.css" type="text/css">
<script type="text/javascript" LANGUAGE="JavaScript">
function fonster(URL)
{
//url är sökvägen till filen som öppnas i fönstret linkfonster
var oppna = open(URL, 'linkfonster', 'directories=no,location=no,menubar=no,status=no,toolbar=no,scrollbars=yes,resizable=yes,width=530,height=600,top=60,left=310')
}
</script>

<script type="text/javascript" language="JavaScript" src="../overlib.js">
</script>
<script type="text/javascript" language="JavaScript">
  var ol_width=100;
</script>
</head>

<body style="margin-top: 3px">
<div id="page-container2">
<p style="margin-top:0; margin-bottom:3px">&nbsp;</p>
<!--
<table align="center" style="width:960px; background-color: #F2F5FF; padding:10px; border=0">
-->
<table cellpadding="10px" class="table_none" align="center" style="width:960px">
<tr><td valign="top" style="width:620px">
<p class="stortext_fet">Formulär för inmatning av Fbomeddelanden.</p>
<form name="pubform" method="post" action="publ_inm.php">
<p><b>Meddelande nr.</b>:&nbsp;<input name="mno" type="text" size="3"></input>&nbsp;&nbsp;
<b>Publiceringsår</b>: 
<input type="text" size="4" name="pubaar">&nbsp;&nbsp;&nbsp;<b>PDF</b>&nbsp;<input type="checkbox" style="border:0" name="pdf" value="J"> 
Bocka för om Pdf finns.</p>
<p><b>Författare</b> (skriv så här:&nbsp;ex. Presley, E., Månsson, K.J. &amp; Borg, B.):<br>
<input name="forf" type="text" size="100"></input></p>
<b>Titel</b> (på originalspråk):<br>
<input name="sve_tit" type="text" size="100"></input><p><b>Engelsk titel</b> 
(om det t.ex. är en publikation på svenska med engelsk sammanfattning):<br>
<input name="eng_tit" type="text" size="100"></input></p>
<p><b>Tidskrift, årgång och sidor</b> (ex. Anser 60: 1-60.): <br>
<input name="journal" type="text" size="100"></input></p>
<p>
Ange här för sökningar:<br>
<b>Författares efternamn</b> skrivs: förf1,förf2,förf3 etc.<br>
<input name="forf_enamn" type="text" size="100"></input></p>
<p><b>Art</b> anges när artikeln handlar om en eller ett fåtal arter.<br>
Alltså ej i sträck-, ringmärknings-, inventeringsrapporter o.dyl. Svenskt artnamn räcker.<br> 
<b>Befintliga arter</b>, välj i listan:<br>
<select name="arter[]" size="10" multiple>
<?php
$sqlval_2="Select Sve_art from fbomedd_arter ORDER by Sve_art";
$query_2=mysqli_query($connect, $sqlval_2) or die (mysqli_error($connect));
while($row=mysqli_fetch_assoc($query_2))
{echo '<option value="'.$row['Sve_art'].'">'.$row['Sve_art'].'</option>';}
?>
</select>
&nbsp;
<br>
och/eller skriv in <b>nya arter</b> här (flera arter skrivs: art1,art2,art3):<br>
<input name="artnamn" type="text" size="100"></p>
<!--
<p>Standardsökord för rapporter<br>
(välj typ av rapport nedan så läggs sökord till automatiskt):<br>
<select name="rapport[]">
<option selected>-------------- välj i listan ------------------</option>'
<option value="ringm_fisk">Ringmärkningsrapport till FiSk</option>
<option value="ringm_lst">Ringmärkningsrapport till Lst</option>
<option value="str_fisk">Sträckrapportrapport till FiSk</option>
<option value="inv_lst">Inventeringsrapport till Lst</option>
<option value="avocet">Skärfläckerapport</option>
</select>
</p>
-->
<p><b>Befintliga svenska sökord</b>, välj i listan, motsvarande engelska läggs 
till automatiskt:<br>
<select name="sokord[]" size="10" multiple>
<?php
$sqlval_3="Select Svesearch from fbomedd_svsearch order by Svesearch";
$query_3=mysqli_query($connect, $sqlval_3) or die (mysqli_error($connect));
while($row=mysqli_fetch_assoc($query_3))
{echo '<option value="'.$row['Svesearch'].'">'.$row['Svesearch'].'</option>';}
?>
</select>
<br>
och/eller skriv in <b>nya svenska sökord</b> här (flera ord skrivs: ord1,ord2,ord3 etc.):<br>
<input name="sve_sok" type="text" size="100"></input>
</p>
<p>
<b>Nya engelska sökord</b>, flera ord skrivs: ord1,ord2,ord3 etc.: <br>
OBS. Endast om nya 
svenska ord skrivits in och då
i samma ordningsföljd.<br>
<input name="eng_sok" type="text" size="100"></input>
</p>
<p>
<input name="ny_inm" type="submit" value="Skicka" class="submit"
  onMouseOver="this.style.color='blue'" 
  onMouseOut="this.style.color='#FFFFFF'">&nbsp;
<input type="reset" value="Radera" class="submit"
  onMouseOver="this.style.color='blue'" 
  onMouseOut="this.style.color='#FFFFFF'">
</form>
</p>
</td>
<td style:"width:10px">&nbsp;</td>
<td valign="top" style="width:330px">
<?php
//data levererade från inmatningsformulär
if (isset($_REQUEST['ny_inm']) && isset($_REQUEST['mno']) && isset($_REQUEST['pubaar'])  
&& isset($_REQUEST['forf']) && isset($_REQUEST['sve_tit']) && isset($_REQUEST['journal']) && isset($_REQUEST['forf_enamn'])
&& (isset($_REQUEST['arter']) || isset($_REQUEST['artnamn']) || isset($_REQUEST['sokord']) || isset($_REQUEST['sve_sok'])))
{
 //DIREKT INMATNING TILL HUVUDLISTAN
 $ny_num=$_REQUEST['mno'];
 $ny_aar=$_REQUEST['pubaar'];
 $ny_pdf=$_REQUEST['pdf']; //måste justeras för J eller N
 $ny_forf=$_REQUEST['forf'];
 $ny_sve_tit=$_REQUEST['sve_tit'];
 $ny_eng_tit=$_REQUEST['eng_tit'];
 $ny_journal=$_REQUEST['journal'];
 //SÖKORD M.M.
 $ny_forf_enamn=$_REQUEST['forf_enamn']; //TEXT
 //$_REQUEST['arter'] arter som finns, ARRAY 
 $ny_art=$_REQUEST['artnamn']; //arter som ska läggas till TEXT
 //$_REQUEST['rapport'] Kan vara tom 
 //$_REQUEST['sokord'] sökord som finns ARRAY
 $ny_sve_sok=$_REQUEST['sve_sok']; //sökord som ska läggas till TEXT
 $ny_eng_sok=$_REQUEST['eng_sok']; //sökord som ska läggas till TEXT

 $artlista=implode(',', $_REQUEST['arter']);
 $soklista=implode(',', $_REQUEST['sokord']);
 //pdf finns-finns ej
 if($ny_pdf!='J')
 {
  $ny_pdf='N';
  $pdftxt='pdf finns inte.';
 }
 else
 {
  $ny_pdf='J';
  $pdftxt='pdf finns.';
 }
 /*
 echo $ny_num.'<br>'.$ny_aar.'<br>'.$ny_pdf.'<br>'.$ny_forf.'<br>'.$ny_sve_tit.'<br>'.$ny_eng_tit.'<br>'.$ny_journal.'
 <br>'.$ny_forf_enamn.'<br>'.$artlista.'<br>'.$ny_art.'<br>'.$soklista.'<br>'.$ny_sve_sok.'<br>'.$ny_eng_sok;
 */
 echo '<p><b>Dina inmatningar:</b></p>
 <p>Meddelande nr.: <b>'.$ny_num.', '.$pdftxt.'</b></p>
 <p>Författare: <b>'.$ny_forf.'</b></p>
 <p>Publiceringsår: <b>'.$ny_aar.'</b></p>
 <p>Titel: <b>'.$ny_sve_tit.'</b></p>
 <p>Summary: <b>'.$ny_eng_tit.'</b></p>
 <p>Tidskrift: <b>'.$ny_journal.'</b></p>
 <p>Art(er) från bef. artlista: <b>'.$artlista.'</b></p>
 <p>Nyinskrivna arter: <b>'.$ny_art.'</b></p>
 <p>Sökord från bef. lista: <b>'.$soklista.'</b></p>
 <p>Nyinskrivna svenska sökord: <b>'.$ny_sve_sok.'</b></p>
 <p>Nyinskrivna engelska sökord: <b>'.$ny_eng_sok.'</b></p>
 <p>Om allt är OK, tryck "Skicka till databas".<br>Behöver något ändras, tryck "Tillbaka".
 <p>Listor med arter och sökord kompletteras vid inmatningen till databasen.</p>
 <form name="pubform2" method="post" action="publ_adm.php">
 <input type="hidden" name="mno2" value="'.$ny_num.'"></input>
 <input type="hidden" name="pubaar2" value="'.$ny_aar.'"></input>
 <input type="hidden" name="pdf2" value="'.$ny_pdf.'"></input>
 <input type="hidden" name="forf2" value="'.$ny_forf.'"></input>
 <input type="hidden" name="sve_tit2" value="'.$ny_sve_tit.'"></input>
 <input type="hidden" name="journal2" value="'.$ny_journal.'"></input>
 <input type="hidden" name="eng_tit2" value="'.$ny_eng_tit.'"></input> 
 <input type="hidden" name="forf_enamn2" value="'.$ny_forf_enamn.'"></input>
 <input type="hidden" name="arter2" value="'.$artlista.'"></input>
 <input type="hidden" name="artnamn2" value="'.$ny_art.'"></input>
 <input type="hidden" name="sokord2" value="'.$soklista.'"></input>
 <input type="hidden" name="sve_sok2" value="'.$ny_sve_sok.'"></input>
 <input type="hidden" name="eng_sok2" value="'.$ny_eng_sok.'"></input>
 <p>
 <input name="ny_inm2" type="submit" value="Skicka till databas" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
 </form>
 <button OnClick="javascript:history.back()"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button></p>';

}
?>
</td></tr>
</table>
</div>
</body>
</html>