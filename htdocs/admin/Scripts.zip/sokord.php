<?php
include "../incl_filer/db_connect.php"; //databasanslutning
  $ny_bef_sokord='andf�glar,anpassning';
  //ta ut motsv s�kord ur den engelska listan
  $bef_word='';
  $array_bef_ord=explode(',', $ny_bef_sokord);
  foreach($array_bef_ord as $sok)
  {
   $sql_motsv="select * from fbomedd_svsearch, fbomedd_ensearch where Svesearch='$sok' and s_id=e_id";
   $query_motsv=mysqli_query($connect, $sql_motsv) or die (mysqli_error($connect));
   while($row=mysqli_fetch_assoc($query_motsv))
   {
    $sokw=$row['Engsearch'];
    if ($bef_word=='')
    {
     $bef_word=$sokw;
    }
    else
    {
     $bef_word=$bef_word.','.$sokw;
    } 
   }
  }
  $input_sok_s=$ny_bef_sokord; //inmatning till fbomeddelanden sve_search
  $input_sok_e=$bef_word; //inmatning till fbomeddelanden eng_search
  echo $input_sok_s.'<br>'.$input_sok_e;    //TESTRAD - SKA TAS BORT       FUNKAR INTE - BARA SISTA S�KORDET KOMMER MED.
?>  