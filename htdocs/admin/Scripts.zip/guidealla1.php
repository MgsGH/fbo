<?php 
include "../incl_filer/db_connect.php"; //databasanslutning 
//lista 
$sql_glist="SELECT * from guidade ORDER BY year";
$query_glist=mysqli_query($connect, $sql_glist) or die (mysqli_error($connect));
$mvdiv=mysqli_num_rows($query_glist)-1;

//summa
$sql_gsum="SELECT SUM(no_spring) AS sumno_s, SUM(grp_spring) AS sumgrp_s, 
SUM(no_autumn) AS sumno_a, SUM(grp_autumn) AS sumgrp_a, 
SUM(no_year) AS sumno_y, SUM(grp_year) AS sumgrp_y from guidade";
$query_gsum=mysqli_query($connect, $sql_gsum) or die (mysqli_error($connect));

//medelv�rde
$sql_gmv="SELECT ROUND(SUM(no_spring)/$mvdiv,0) AS mvno_s, ROUND(SUM(grp_spring)/$mvdiv,0) AS mvgrp_s, 
ROUND(SUM(no_autumn)/$mvdiv,0) AS mvno_a, ROUND(SUM(grp_autumn)/$mvdiv,0) AS mvgrp_a, 
ROUND(SUM(no_year)/$mvdiv,0) AS mvno_y, ROUND(SUM(grp_year)/$mvdiv,0) AS mvgrp_y from guidade";
$query_gmv=mysqli_query($connect, $sql_gmv) or die (mysqli_error($connect));

//max min
$sql_gmax="SELECT MAX(no_spring) AS maxno_s, MAX(grp_spring) AS maxgrp_s, 
MAX(no_autumn) AS maxno_a, MAX(grp_autumn) AS maxgrp_a, 
MAX(no_year) AS maxno_y, MAX(grp_year) AS maxgrp_y from guidade";
$query_gmax=mysqli_query($connect, $sql_gmax) or die (mysqli_error($connect));
while ($row=mysqli_fetch_assoc($query_gmax))
{$mxno_s=$row['maxno_s'];
 $mxgrp_s=$row['maxgrp_s'];
 $mxno_a=$row['maxno_a'];
 $mxgrp_a=$row['maxgrp_a'];
 $mxno_y=$row['maxno_y'];
 $mxgrp_y=$row['maxgrp_y'];
}
$sql_gmin="SELECT MIN(no_spring) AS minno_s, MIN(grp_spring) AS mingrp_s, 
MIN(no_autumn) AS minno_a, MIN(grp_autumn) AS mingrp_a, 
MIN(no_year) AS minno_y, MIN(grp_year) AS mingrp_y from guidade";
$query_gmin=mysqli_query($connect, $sql_gmin) or die (mysqli_error($connect));
while ($row=mysqli_fetch_assoc($query_gmin))
{$mnno_s=$row['minno_s'];
 $mngrp_s=$row['mingrp_s'];
 $mnno_a=$row['minno_a'];
 $mngrp_a=$row['mingrp_a'];
 $mnno_y=$row['minno_y'];
 $mngrp_y=$row['mingrp_y'];
}
$end_year=date('Y')-1;

//r�knarens st�llning
$sql_rakn="SELECT * from guide_count";
$query_rakn=mysqli_query($connect, $sql_rakn) or die (mysqli_error($connect));
while ($row=mysqli_fetch_assoc($query_rakn))
{$year_r=$row['year'];
 $nosp_r=$row['no_spring'];
 $grsp_r=$row['grp_spring'];
 $noau_r=$row['no_autumn'];
 $grau_r=$row['grp_autumn'];
 $noye_r=$row['no_year'];
 $grye_r=$row['grp_year'];
} 
?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html lang="sv">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="imagetoolbar" content="no">
<title>Totallista 1980 ff</title>
<LINK REL=STYLESHEET TYPE="text/css" HREF="../bluemall.css">
<script language="JavaScript" src="../overlib.js">
</script>
<script type="text/javascript">
<!--
  var ol_width=165; //s�tter bredden p� opuprutan
//-->
</script>
<style>
p
{
 margin-top: 6px;
 margin-bottom: 6px;
}
</style>
</head>

<body>
<div align="center"> 
<table width="860" cellpadding="0" style="cell-spacing:0; border:0; border-collapse: collapse; 
background: bilder/trans.gif">
<tr>
<td width="5"></td>
<td width="400" align="left" valign="top" padding-left="5" padding-right="5">
<p><span style="font-size:12px"><b>ANTAL GUIDADE PERSONER/GRUPPER<br>
1980-<?php echo $end_year; ?></b></span></p>
<p>Max- och min-v�rden visas i tabellen<br>med <b>fet</b> resp. <i>kursiv</i> stil i varje kolumn.</p>
<p>Medelv�rdet l�ngst ner i tabellen omfattar inte det<br>
senast tillagda �ret (f�r j�mf�relsens skull).</p>
<p>Nya �r l�ggs till automatiskt <i><b>efter</b></i> varje �rsskifte.</p>
<p><span style="font-size:12px"><b>F�RE 1980:</b></span><br>
Guidningar har f�rekommit l�ngt tillbaka i f�gelstationens historia. I b�rjan var det i t�mligen oorganiserad form 
och endast sporadiska anteckningar i dagb�ckerna vittnar om att verksamheten f�rekom. Fr�n mitten av 1970-talet blev 
guidningarna mera frekvent noterade i dagboken men ej komplett. Fr.o.m. 1977, d� vi fick ekonomiskt st�d fr�n Naturv�rdsverket till att anst�lla 
en guide under h�sten blev det ocks� noterat&nbsp;hur m�nga som varit h�r. Guidningar under v�rs�songerna var d�remot 
fortsatt f�. Nedanst�ende lista visar guidningar 1974-79, enligt anteckningar i 
dagboken.</p>
<table width="390" style="cell-padding:5px; border-collapse: collapse">
<tr height="21" class="tablehead">
<td align="center" width="32">�r</td>
<td align="right">Ant. V�r</td><td align="right">Grp. V�r</td>
<td align="right">Ant. H�st</td><td  align="right">Grp. H�st</td>
<td align="right">Ant. �r</td><td align="right">Grp. �r</td></tr>
<tr height="21" bgcolor="#E1E8F7">
<td width="35">1974</td><td align="right">136</td><td align="right">5</td>
<td align="right">780</td><td align="right">21</td><td align="right">916</td><td align="right">26</td></tr>
<tr height="21" bgcolor="#FFFFFF">
<td width="35">1975</td><td align="right">210</td><td align="right">4</td>
<td align="right">saknas</td><td align="right">---</td><td align="right">210</td><td align="right">4</td></tr>
<tr height="21" bgcolor="#E1E8F7">
<td width="35">1976</td><td align="right">205</td><td align="right">5</td>
<td align="right">560</td><td align="right">16</td><td align="right">765</td><td align="right">21</td></tr>
<tr height="21" bgcolor="#FFFFFF">
<td width="35">1977</td><td align="right">120</td><td align="right">3</td>
<td align="right">2478</td><td align="right">65</td><td align="right">2598</td><td align="right">68</td></tr>
<tr height="21" bgcolor="#E1E8F7">
<td width="35">1978</td><td align="right">50</td><td align="right">3</td>
<td align="right">2685</td><td align="right">74</td><td align="right">2735</td><td align="right">77</td></tr>
<tr height="21" bgcolor="#FFFFFF">
<td width="35">1979</td><td align="right">30</td><td align="right">3</td>
<td align="right">2198</td><td align="right">69</td><td align="right">2228</td><td align="right">72</td></tr>
<tr height="21" bgcolor="#E1E8F7">
<td width="35">Totalt</td><td align="right">751</td><td align="right">23</td>
<td align="right">8701</td><td align="right">245</td><td align="right">9452</td><td align="right">268</td></tr>
</table></p>
<p>&nbsp;</p>
<p><font style="font-size:12px"><b>R�KNAREN</b></font></p>
<p>Systemet har en r�knare f�r innevarande �r som uppdateras<br>
varje g�ng man bes�ker sidan "Visa hittills guidade".<br>
R�knaren uppdaterar ocks� totallistan automatiskt efter varje �rsskifte.</p>
<p><b>R�knarens st�llning just nu (g�ller <?php echo $year_r; ?>):</b></p>
<table width="350" style="cell-padding:5px; border-collapse: collapse">
<tr height="21" class="tablehead">
<td align="right">Ant. V�r</td><td align="right">Grp. V�r</td>
<td align="right">Ant. H�st</td><td  align="right">Grp. H�st</td>
<td align="right">Ant. �r</td><td align="right">Grp. �r</td></tr>
<tr height="21" bgcolor="#E1E8F7">
<?php
echo '<td align="right">'.$nosp_r.'</td> 
<td align="right">'.$grsp_r.'</td>
<td align="right">'.$noau_r.'</td>
<td align="right">'.$grau_r.'</td>
<td align="right">'.$noye_r.'</td>
<td align="right">'.$grye_r.'</td>';
?>
</tr>
</table>
<p>&nbsp;</p>
<p>
<button OnClick="javascript:history.back()"
 onMouseOver="this.style.color='blue'" 
 onMouseOut="this.style.color='#FFFFFF'">Tillbaka</button></p>
</td>
<td width="5"></td>
<td>
<table width="450" style="cell-padding:5px; border-collapse: collapse">
 <tr height="21" class="tablehead">
 <td>�r</td><td align="right">Ant. V�r</td><td align="right">Grp. V�r</td>
 <td align="right">Ant. H�st</td><td  align="right">Grp. H�st</td>
 <td align="right">Ant. �r</td><td align="right">Grp. �r</td></tr>
<?php 
 $farg='#FFFFFF';
 while ($row=mysqli_fetch_assoc($query_glist))
 {if ($farg==('#FFFFFF'))
  {$farg='#E1E8F7';}
  else
  {$farg='#FFFFFF';}
  echo'<tr height="21" bgcolor="'.$farg.'">
  <td>'.$row['year'].'</td>';
  if ($row['no_spring']==$mxno_s)
   {echo '<td align="right"><b>'.$row['no_spring'].'</b></td>';}
  elseif ($row['no_spring']==$mnno_s)
   {echo '<td align="right"><i>'.$row['no_spring'].'</i></td>';}
  else
   {echo '<td align="right">'.$row['no_spring'].'</td>';}
  
  if ($row['grp_spring']==$mxgrp_s)
   {echo '<td align="right"><b>'.$row['grp_spring'].'</b></td>';}
  elseif ($row['grp_spring']==$mngrp_s)
   {echo '<td align="right"><i>'.$row['grp_spring'].'</i></td>';}
  else
   {echo '<td align="right">'.$row['grp_spring'].'</td>';}
  
  if ($row['no_autumn']==$mxno_a)
   {echo '<td align="right"><b>'.$row['no_autumn'].'</b></td>';}
  elseif ($row['no_autumn']==$mnno_a)
   {echo '<td align="right"><i>'.$row['no_autumn'].'</i></td>';}
  else
   {echo '<td align="right">'.$row['no_autumn'].'</td>';}
  
  if ($row['grp_autumn']==$mxgrp_a)
   {echo '<td align="right"><b>'.$row['grp_autumn'].'</b></td>';}
  elseif ($row['grp_autumn']==$mngrp_a)
   {echo '<td align="right"><i>'.$row['grp_autumn'].'</i></td>';}
  else
   {echo '<td align="right">'.$row['grp_autumn'].'</td>';}
  
  if ($row['no_year']==$mxno_y)
   {echo '<td align="right"><b>'.$row['no_year'].'</b></td>';}
  elseif ($row['no_year']==$mnno_y)
   {echo '<td align="right"><i>'.$row['no_year'].'</i></td>';}
  else
   {echo '<td align="right">'.$row['no_year'].'</td>';}

  if ($row['grp_year']==$mxgrp_y)
   {echo '<td align="right"><b>'.$row['grp_year'].'</b></td>';}
  elseif ($row['grp_year']==$mngrp_y)
   {echo '<td align="right"><i>'.$row['grp_year'].'</i></td>';}
  else
   {echo '<td align="right">'.$row['grp_year'].'</td>';}

echo '</tr>';
 }
 while ($row=mysqli_fetch_assoc($query_gsum))
 {if ($farg==('#FFFFFF'))
  {$farg='#E1E8F7';}
  else
  {$farg='#FFFFFF';}
  echo'<tr height="21" bgcolor="'.$farg.'">
  <td><b>Summa</b></td>
  <td align="right"><b>'.$row['sumno_s'].'</b></td><td align="right"><b>'.$row['sumgrp_s'].'</b></td>
  <td align="right"><b>'.$row['sumno_a'].'</b></td><td align="right"><b>'.$row['sumgrp_a'].'</b></td>
  <td align="right"><b>'.$row['sumno_y'].'</b></td><td align="right"><b>'.$row['sumgrp_y'].'</b></td></tr>';
 }
 while ($row=mysqli_fetch_assoc($query_gmv))
 {if ($farg==('#FFFFFF'))
  {$farg='#E1E8F7';}
  else
  {$farg='#FFFFFF';}
  echo'<tr height="21" bgcolor="'.$farg.'">
  <td><i>Mv.</i></td>
  <td align="right"><i>'.$row['mvno_s'].'</i></td><td align="right"><i>'.$row['mvgrp_s'].'</i></td>
  <td align="right"><i>'.$row['mvno_a'].'</i></td><td align="right"><i>'.$row['mvgrp_a'].'</i></td>
  <td align="right"><i>'.$row['mvno_y'].'</i></td><td align="right"><i>'.$row['mvgrp_y'].'</i></td></tr>';
 }
?>
</table> 
</td>
</tr></table>
</div>
</body>
</html>