<title>Aktuella siffror</title>
<?php
//Ska läggas i en egen fil som kan inkluderas på övriga sidor.

//Bestäm vilket halvår det är:
//Pågående
{$idag=date('Y-m-d');
$helaar=substr($idag,0,4);
$moonday=substr($idag,5,5);
}

if ($moonday>='01-01' && $moonday<='06-30') //första halvåret
{
//antalet inbokade grupper:
$sql_ingrup="SELECT * from besokstider  
WHERE G_klar='N' 
AND substr(besokstider.Datum,1,4)='$helaar'
AND substr(besokstider.Datum,6,5)>='01-01' 
AND substr(besokstider.Datum,6,5)<='06-30'";
$query_ingrup=mysqli_query($connect, $sql_ingrup) or die(mysqli_error($connect));
$ant_ingr=mysqli_num_rows($query_ingrup);

//antalet guidade grupper:
$sql_utgrup="SELECT * from besokstider  
WHERE G_klar='J' 
AND substr(besokstider.Datum,1,4)='$helaar'
AND substr(besokstider.Datum,6,5)>='01-01' 
AND substr(besokstider.Datum,6,5)<='06-30'";
$query_utgrup=mysqli_query($connect, $sql_utgrup) or die(mysqli_error($connect));
$ant_utgr=mysqli_num_rows($query_utgrup);

//antal inbokade/guidade personer
$inbokade=0;
$guidade=0;
$sql_booked="SELECT G_klar, SUM(G_antal) AS booked from besokstider  
WHERE substr(besokstider.Datum,1,4)='$helaar' AND 
substr(besokstider.Datum,6,5)>='01-01' AND substr(besokstider.Datum,6,5)<='06-30'
GROUP BY G_klar ORDER BY G_klar";
$query_booked=mysqli_query($connect, $sql_booked) or die(mysqli_error($connect));
while ($row=mysqli_fetch_assoc($query_booked))
{if($row['G_klar']=='J')
 {$guidade=$row['booked'];}
 else
 {$inbokade=$row['booked'];}
}
$next=2;
}
else //andra halvåret
{
//antalet inbokade grupper:
$sql_ingrup="SELECT * from besokstider  
WHERE G_klar='N' 
AND substr(besokstider.Datum,1,4)='$helaar'
AND substr(besokstider.Datum,6,5)>='07-01' 
AND substr(besokstider.Datum,6,5)<='12-31'";
$query_ingrup=mysqli_query($connect, $sql_ingrup) or die(mysqli_error($connect));
$ant_ingr=mysqli_num_rows($query_ingrup);

//antalet guidade grupper:
$sql_utgrup="SELECT * from besokstider  
WHERE G_klar='J' 
AND substr(besokstider.Datum,1,4)='$helaar'
AND substr(besokstider.Datum,6,5)>='07-01' 
AND substr(besokstider.Datum,6,5)<='12-31'";
$query_utgrup=mysqli_query($connect, $sql_utgrup) or die(mysqli_error($connect));
$ant_utgr=mysqli_num_rows($query_utgrup);

//antal inbokade/guidade personer
$inbokade=0;
$guidade=0;
$sql_booked="SELECT G_klar, SUM(G_antal) AS booked from besokstider  
WHERE substr(besokstider.Datum,1,4)='$helaar' AND 
substr(besokstider.Datum,6,5)>='07-01' AND substr(besokstider.Datum,6,5)<='12-31'
GROUP BY G_klar ORDER BY G_klar";
$query_booked=mysqli_query($connect, $sql_booked) or die(mysqli_error($connect));
while ($row=mysqli_fetch_assoc($query_booked))
{if($row['G_klar']=='J')
 {$guidade=$row['booked'];}
 else
 {$inbokade=$row['booked'];}
}
$next=1;
}
//nästa halvår
if ($next==1)
{$helaar=$helaar+1;
 $f_moon='01-01';
 $s_moon='06-30';
}
else
{$f_moon='07-01';
 $s_moon='12-31';
}
//antal inbokade personer nästa halvår
$inbokadenext=0;
$sql_bookednext="SELECT G_klar, SUM(G_antal) AS booked from besokstider  
WHERE substr(besokstider.Datum,1,4)='$helaar' AND 
substr(besokstider.Datum,6,5)>='$f_moon' AND substr(besokstider.Datum,6,5)<='$s_moon'
AND G_klar='N' GROUP BY G_klar";
$query_bookednext=mysqli_query($connect, $sql_bookednext) or die(mysqli_error($connect));
while ($row=mysqli_fetch_assoc($query_bookednext))
$inbokadenext=$row['booked'];

//antal inbokade grupper nästa halvår
$sql_ingrupnext="SELECT * from besokstider  
WHERE G_klar='N' 
AND substr(besokstider.Datum,1,4)='$helaar'
AND substr(besokstider.Datum,6,5)>='$f_moon' 
AND substr(besokstider.Datum,6,5)<='$s_moon'";
$query_ingrupnext=mysqli_query($connect, $sql_ingrupnext) or die(mysqli_error($connect));
$ant_ingrnext=mysqli_num_rows($query_ingrupnext);

$personprognos=$inbokade+$guidade;
$grupprognos=$ant_ingr+$ant_utgr;
echo '
<table width="320" border="0" cellpadding="3" cellspacing="0">
<tr class="tablehead">
<td colspan="2">Aktuella siffror, pågående säsong (halvår)</td></tr> 
<tr><td width="140">Inbokade (ca.):</td><td width="180" align="right">'.$inbokade.' personer i '.$ant_ingr.' grupper.</td></tr>
<tr><td width="140">Hittills guidade:</td><td width="180" align="right">'.$guidade.' personer i '.$ant_utgr.' grupper.</td></tr>
<tr><td width="140">Prel. säsongssumma:</td><td width="180" align="right">'.$personprognos.' personer i '.$grupprognos.' grupper.</td></tr>
<tr class="tablehead">
<td colspan="2">Nästa säsong (halvår)</td></tr>
<tr><td width="140">Inbokade (ca.):</td><td width="180" align="right">'.$inbokadenext.' personer i '.$ant_ingrnext.' grupper.</td></tr>
</table>';
?>
