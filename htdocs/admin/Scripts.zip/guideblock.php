<?php
include "../incl_filer/db_connect.php"; //databasanslutning
?>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Bokning av guidningar</title>
<LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
<SCRIPT LANGUAGE="JavaScript">
<!-- Göm skriptet
function fonster(URL)
{
//url är sökvägen till filen som öppnas i fönstret lankfonster
var oppna = open(URL, "lankfonster", "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, width=600, height=250, top=270, left=288")
}
function openWindow(form) 
{
 var url = "guideadd.php?";
 url += "gruppen=" + form.gruppen.value + "&id=" + form.id.value;
 window.open(url,"addwin","toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, left=50, top=157, width=400, height=300");
}

// Sluta gömma -->
</SCRIPT>
<script language="JavaScript" src="../overlib.js">
</script>
<script type="text/javascript">
<!--
  var ol_width=140; //sätter bredden på popuprutan
//-->
</script>
<style>
p
{
 margin-top: 6px;
 margin-bottom: 6px;
}
</style>
</head>

<body>
<p align="center"><span style="font-size:12px"><b>BOKNING AV GUIDNING - NY BESTÄLLNING</b></span></p>
<table width="100%" border="0" cell-padding="5" class="alt_tab_bg">
<tr>
<td width="50%" valign="top">
<b>Ny beställning.</b> Oavsett om beställaren önskar boka en eller flera tider:<br>
<b>Börja alltid med att boka in en tid med kompletta data och spara den.</b><br>
Då får man upp en knapp som länkar till formulär för ytterligare tidsbokningar.<br>
<b>Mer info:</b> Sätt muspekaren på fältrubrikerna i formuläret nedan.</p>
<?php
//om formuläret är ifyllt och skickat - lägg till (ny) post
if (isset($_REQUEST['bokning'])) 
{if (!empty($_REQUEST['grupp']) && !empty($_REQUEST['G_gata'])
 && !empty($_REQUEST['G_pnr']) && !empty($_REQUEST['G_stad']) && !empty($_REQUEST['datum'])
 && !empty($_REQUEST['tid']) && !empty($_REQUEST['G_deltant']) && !empty($_REQUEST['best_av'])
 && !empty($_REQUEST['B_tel1'])) 
 {$grupp=$_REQUEST['grupp'];
  $G_gatan=$_REQUEST['G_gata'];
  $G_pnr=$_REQUEST['G_pnr'];
  $G_stad=$_REQUEST['G_stad'];
  $datum=$_REQUEST['datum'];
  $tid=$_REQUEST['tid'];
  $delt=$_REQUEST['G_deltant'];
  $alder=$_REQUEST['G_alder'];
  $best_av=$_REQUEST['best_av'];
  $B_tel1=$_REQUEST['B_tel1'];
  $B_tel2=$_REQUEST['B_tel2'];
  $B_epost=$_REQUEST['B_epost'];
  $faktura=$_REQUEST['faktura'];
  $F_idnr=$_REQUEST['F_idnr'];
  $F_gata=$_REQUEST['F_gata'];
  $F_pnr=$_REQUEST['F_pnr'];
  $F_stad=$_REQUEST['F_stad'];
  $extra_1=$_REQUEST['extra_1'];
  $extra_2=$_REQUEST['extra_2'];
  //spara adress
  if (isset($_REQUEST['spar']) && $_REQUEST['spar']=='J')
  {$spar_adr='J';}
  elseif (isset($_REQUEST['spar']) && $_REQUEST['spar']=='U')
  {
   $spar_adr='J';
   $gidnr=$_REQUEST['old_id'];
   $sql_andr="UPDATE guidebokning SET spar='N' WHERE G_ID='$gidnr'";
   mysqli_query($connect, $sql_andr) or die (mysqli_error($connect));
  }
  else
  {$spar_adr='N';} 
  
 //NY BOKNING lägg till i tabell för grupper och beställare
   $sql_bokn="INSERT into guidebokning (Grupp, G_gatuadr, G_postnr, G_ort, Best_namn, Best_tel1, Best_tel2,
   Best_epost, Fakt_namn, Fakt_idnr, Fakt_adr, Fakt_postnr, Fakt_ort, Anm_1, Anm_2, Spar) VALUES 
   ('$grupp', '$G_gatan', '$G_pnr', '$G_stad', '$best_av', '$B_tel1', '$B_tel2', '$B_epost', '$faktura', 
   '$F_idnr', '$F_gata', '$F_pnr', '$F_stad', '$extra_1', '$extra_2', '$spar_adr')";
   mysqli_query($connect, $sql_bokn) or die (mysqli_error($connect));
 
 //Ta ut nytt bokningsID
   $sql_id="Select max(G_ID) as ID from guidebokning";
   $query_id=mysqli_query($connect, $sql_id);
   while ($row=mysqli_fetch_assoc($query_id))
   {$idnr=$row['ID'];}
   
//lägg till data i tabell för besökstider
  $sql_visit="INSERT into besokstider (G_ID, Datum, Tid, G_antal, G_alder, G_klar)
  values ('$idnr', '$datum', '$tid', '$delt', '$alder', 'N')";
  mysqli_query($connect, $sql_visit) or die (mysqli_error($connect));
  echo '<p> Inmatade uppgifter har lagts till i databasen.<br>
  Aktuellt bokningsnummer för <b>'.$grupp.'</b> är <b>'.$idnr.'</b><br>
  För att boka in fler tider från samma beställare - 
  <form style="margin-top:8" name="fler_tider">
  <input type="hidden" value="'.$grupp.'" name="gruppen">
  <input type="hidden" value="'.$idnr.'" name="id">
  <input type="submit" value="Klicka här" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'"
  onclick="openWindow(document.fler_tider)">
  </form>
  
  Om uppgifterna är OK, kan du skriva ut en bokningsbekräftelse här.<br>
  <p>
  <button style="width:200px" onclick="location.href=\'bokn_bekr.php?id='.$idnr.'\'"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">Visa bokningsbekräftelse</button>
  </p>
  <p>&nbsp;</p>
  <p>
  Gå tillbaka till första sidan:
  <p><button style="width:97px" onclick="location.href=\'guideblock.php\'"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">Tillbaka</button>';
 }
 else
 {echo '<p>Formuläret är felaktigt ifyllt.<a href="guideblock.php">Försök igen!</a>';
 }
}
elseif (isset($_REQUEST['Koll']))
{$idnr=$_REQUEST['grupplista'];
 //ta ut bokningsuppgifter för redan inskriven
 $sql_boknuppg="SELECT * from guidebokning WHERE G_ID='$idnr'"; 
 $query_boknuppg=mysqli_query($connect, $sql_boknuppg) or die (mysqli_error($connect));
  
//ta ut tidsuppgifter för vald bokning 
 $sql_tidsuppg="SELECT * from besokstider WHERE G_ID='$idnr' ORDER by Datum,Tid";
 $query_tidsuppg=mysqli_query($connect, $sql_tidsuppg) or die (mysqli_error($connect));
 
//visa
 while ($row=mysqli_fetch_assoc($query_boknuppg))
 {$gidnr=$row['G_ID'];
  $grupp=$row['Grupp'];
  $gatuadr=$row['G_gatuadr'];
  $ponr=$row['G_postnr'];
  $town=$row['G_ort'];
  $best=$row['Best_namn'];
  $btel_1=$row['Best_tel1'];
  $btel_2=$row['Best_tel2'];
  $bepost=$row['Best_epost'];
  $faknamn=$row['Fakt_namn'];
  $fakid=$row['Fakt_idnr'];
  $fakgata=$row['Fakt_adr'];
  $fakponr=$row['Fakt_postnr'];
  $faktown=$row['Fakt_ort'];
  $anm1=$row['Anm_1'];
  $anm2=$row['Anm_2'];
 }
 echo '
 <form name="bokning" method="POST" action="'.$_SERVER['PHP_SELF'].'">
 <table width="100%" class="alt_tab_bg" style="cell-padding:3px; border: 0px; border-collapse: collapse">
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Är beställaren en privatperson, skriv bara Privat här.\');"
 onMouseOut="nd();">
 Grupp (skola, org. etc.):
 </td><td width="60%">
 <input type="text" size="40" value="'.$grupp.'" name="grupp">*
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Saknas gatuadress? Skriv en fiktiv, t.ex. gatan 13.\');"
 onMouseOut="nd();">
 Gatuadress/box:
 </td><td width="60%">
 <input type="text" size="40" value="'.$gatuadr.'" name="G_gata">*
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Saknas postnummer? Skriv 000 00.\');"
 onMouseOut="nd();">
 Postnummer (000 00):
 </td><td width="60%">
 <input type="text" size="10" value="'.$ponr.'" name="G_pnr">*
 </td></tr>
 <tr><td width="40%" align="right">
 Ort:
 </td><td width="60%">
 <input type="text" size="30" value="'.$town.'" name="G_stad">*
 </td></tr>
 <tr><td width="40%" align="right">
 Besöksdatum (åååå-mm-dd):
 </td><td width="60%">
 <input type="text" size="10" name="datum">*
 </td></tr>
 <tr><td width="40%" align="right">
 Klockan (tt:mm):
 </td><td width="60%">
 <input type="text" size="5" name="tid">*
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Antal okänt? Skriv ett troligt antal.\');"
 onMouseOut="nd();">
 Uppskattat antal deltagare:
 </td><td width="60%">
 <input type="text" size="3" name="G_deltant">*
 </td></tr>
 <tr><td width="40%" align="right">
 Åldersgrupp (t.ex. åk 5):
 </td><td width="60%">
 <input type="text" size="10" name="G_alder">
 </td></tr>
 <tr><td width="40%" align="right">
 Beställare (person):
 </td><td width="60%">
 <input type="text" size="40" value="'.$best.'" name="best_av">*
 </td></tr>
 <tr><td width="40%" align="right">
 Best. telefon 1:
 </td><td width="60%">
 <input type="text" size="15" value="'.$btel_1.'" name="B_tel1">*
 </td></tr>
 <tr><td width="40%" align="right">
 Best. telefon 2: 
 </td><td width="60%">
 <input type="text" size="15" value="'.$btel_2.'" name="B_tel2">
 </td></tr>
 <tr><td width="40%" align="right" 
 onMouseOver="overlib(\'Behövs för utskick av bokningsbekräftelse.\');"
 onMouseOut="nd();">
 Best. e-postadress:
 </td><td width="60%">
 <input type="text" size="40" value="'.$bepost.'" name="B_epost">
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Om annan än ovan.\');"
 onMouseOut="nd();">
 Fakturamottagare: 
 </td><td width="60%">
 <input type="text" size="40" value="'.$faknamn.'" name="faktura">
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Nummer eller kod som angivits av beställaren.\');"
 onMouseOut="nd();">
 Faktura_idnr: 
 </td><td width="60%">
 <input type="text" size="40" value="'.$fakid.'" name="F_idnr">
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Om annan än ovan.\');"
 onMouseOut="nd();">
 Faktura_gatuadress/box:
 </td><td width="60%">
 <input type="text" size="40" value="'.$fakgata.'" name="F_gata">
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Om annat än ovan.\');"
 onMouseOut="nd();">
 Faktura postnummer (000 00):
 </td><td width="60%">
 <input type="text" size="10" value="'.$fakponr.'" name="F_pnr">
 </td></tr>
 <tr><td width="40%" align="right"
 onMouseOver="overlib(\'Om annan än ovan.\');"
 onMouseOut="nd();">
 Faktura_ort:
 </td><td width="60%">
 <input type="text" size="30" value="'.$faktown.'" name="F_stad">
 </td></tr>
 <tr><td width="40%" align="right">
 Anm. 1:
 </td><td width="60%">
 <input type="text" size="30" value="'.$anm1.'" name="extra_1">
 </td></tr>
 <tr><td width="40%" align="right">
 Anm. 2:
 </td><td width="60%">
 <input type="text" size="30" value="'.$anm2.'" name="extra_2">
 </td></tr>
 <tr><td width="40%" align="right">
 Uppdatera adresslista: 
 </td><td width="60%">
 <input type="checkbox" style="border:0" value="U" name="spar">
 </td></tr></table>
 <input type="hidden" value="'.$gidnr.'" name="old_id">
 <p>
 <input name="bokning" type="submit" value="Skicka bokning" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
 <input type="reset" value="Avbryt" class="submit"
  onMouseOver="overlib(\'Avbryter inmatningen. Nyinskrivna data sparas inte.\'); this.style.color=\'blue\'" 
  onMouseOut="nd(); this.style.color=\'#FFFFFF\'"
  onClick="location.href=\'Guideblock.php\'">&nbsp;
  Fält markerade med * måste alltid fyllas i.
</form>
';
}
else
{
//första formuläret
//Kontrollera om gruppen varit här förut
echo '<p 
onMouseOver="overlib(\'Om gruppen finns: markera och välj. Formuläret fylls då i automatiskt. Fyll i tid och antal. Kontrollera adressuppgifter och ändra vid behov.\');"
onMouseOut="nd();">Kontrollera först om gruppen finns i databasen:</p>';
$sql_koll="SELECT G_ID, Grupp, G_ort from guidebokning WHERE Spar='J' ORDER BY Grupp";
$query_koll=mysqli_query($connect, $sql_koll) or die (mysqli_error($connect));
echo '
<form style="margin-top:6; margin-bottom:6" name="gruppkoll" method="POST" action="'.$_SERVER['PHP_SELF'].'">
<select name="grupplista" 
style="border-style:solid; border-width:1px; font-family: Verdana; font-size: 11px; color: #000080"
onMouseOver="overlib(\'Om gruppen finns: markera och välj. Formuläret fylls då i automatiskt. Fyll i tid och antal. Kontrollera adressuppgifter och ändra vid behov.\');"
onMouseOut="nd();">
<option selected>----------------------- sök grupp -----------------------</option>'; 
while ($row = mysqli_fetch_assoc($query_koll))
{echo '<option value="'.$row['G_ID'].'">'.$row['Grupp'].', '.$row['G_ort'].'</option>';}
echo '</select>
&nbsp;&nbsp; 
<input name="Koll" type="submit" value="Välj" class="submit"
onMouseOver="this.style.color=\'blue\'" 
onMouseOut="this.style.color=\'#FFFFFF\'">
</form>';

echo '
<form style="margin-top:6" name="bokning" method="POST" action="'.$_SERVER['PHP_SELF'].'">
<table width="100%" class="alt_tab_bg" style="cell-padding:3px; border: 0px; border-collapse: collapse">
<tr><td width="40%" align="right"
onMouseOver="overlib(\'Är beställaren en privatperson, skriv bara <b>Privat</b> här.\');"
onMouseOut="nd();"> 
Grupp (skola, org. etc.):
</td><td width="60%">
<input type="text" size="40" name="grupp">*
</td></tr>
<tr><td width="40%" align="right"
onMouseOver="overlib(\'Saknas gatuadress? Skriv en fiktiv, t.ex. gatan 13.\');"
onMouseOut="nd();">
Gatuadress/box:
</td><td width="60%">
<input type="text" size="40" name="G_gata">*
</td></tr>
<tr><td width="40%" align="right"
onMouseOver="overlib(\'Saknas postnummer? Skriv 000 00.\');"
onMouseOut="nd();">
Postnummer (000 00):
</td><td width="60%">
<input type="text" size="10" name="G_pnr">*
</td></tr>
<tr><td width="40%" align="right">
Ort:
</td><td width="60%">
<input type="text" size="30" name="G_stad">*
</td></tr>
<tr><td width="40%" align="right">
Besöksdatum (åååå-mm-dd):
</td><td width="60%">
<input type="text" size="10" name="datum">*
</td></tr>
<tr><td width="40%" align="right">
Klockan (tt:mm):
</td><td width="60%">
<input type="text" size="5" name="tid">*
</td></tr>
<tr><td width="40%" align="right"
onMouseOver="overlib(\'Antal okänt? Skriv ett troligt antal.\');"
onMouseOut="nd();">
Uppskattat antal deltagare:
</td><td width="60%">
<input type="text" size="3" name="G_deltant">*
</td></tr>
<tr><td width="40%" align="right">
Åldersgrupp (t.ex. åk 5):
</td><td width="60%">
<input type="text" size="10" name="G_alder">
</td></tr>
<tr><td width="40%" align="right">
Beställare (person):
</td><td width="60%">
<input type="text" size="40" name="best_av">*
</td></tr>
<tr><td width="40%" align="right">
Best. telefon 1: 
</td><td width="60%">
<input type="text" size="15" name="B_tel1">*
</td></tr>
<tr><td width="40%" align="right">
Best. telefon 2:
</td><td width="60%">
<input type="text" size="15" name="B_tel2">
</td></tr>
<tr><td width="40%" align="right" 
 onMouseOver="overlib(\'Behövs för utskick av bokningsbekräftelse.\');"
 onMouseOut="nd();">
Best. e-postadress: 
</td><td width="60%">
<input type="text" size="40" name="B_epost">
</td></tr>
<tr><td width="40%" align="right"
onMouseOver="overlib(\'Om annan än ovan.\');"
onMouseOut="nd();">
Fakturamottagare: 
</td><td width="60%">
<input type="text" size="40" name="faktura">
</td></tr>
<tr><td width="40%" align="right"
onMouseOver="overlib(\'Nummer eller kod som anges av beställaren.\');"
onMouseOut="nd();">
Faktura_idnr: 
</td><td width="60%">
<input type="text" size="40" name="F_idnr">
</td></tr>
<tr><td width="40%" align="right"
onMouseOver="overlib(\'Om annan än ovan.\');"
onMouseOut="nd();">
Faktura_gatuadress/box:
</td><td width="60%">
<input type="text" size="40" name="F_gata">
</td></tr>
<tr><td width="40%" align="right"
onMouseOver="overlib(\'Om annat än ovan.\');"
onMouseOut="nd();">
Faktura postnummer (000 00):
</td><td width="60%">
<input type="text" size="10" name="F_pnr">
</td></tr>
<tr><td width="40%" align="right"
onMouseOver="overlib(\'Om annan än ovan.\');"
onMouseOut="nd();">
Faktura_ort:
</td><td width="60%">
<input type="text" size="30" name="F_stad">
</td></tr>
<tr><td width="40%" align="right">
Anm. 1:
</td><td width="60%">
<input type="text" size="30" name="extra_1">
</td></tr>
<tr><td width="40%" align="right">
Anm. 2: 
</td><td width="60%">
<input type="text" size="30" name="extra_2">
</td></tr>
<tr><td width="40%" align="right"
onMouseOver="overlib(\'Gäller visning i rullgardinsmenyn ovan.<br>Tumregel: Skolor, föreningar etc. sparas.<br><b>EJ privatpersoner!</b> \');"
onMouseOut="nd();">
Spara i adresslista: 
</td><td width="60%">
<input type="checkbox" style="border:0" name="spar" value="J">
</td></tr></table>

<p>
<input name="bokning" type="submit" value="Skicka bokning" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
<input type="reset" value="Radera" class="submit"
  onMouseOver="this.style.color=\'blue\'" 
  onMouseOut="this.style.color=\'#FFFFFF\'">&nbsp;
  Fält markerade med * måste alltid fyllas i.
</form>';
}
echo '
<p>
<button style="width:200px" onclick="location.href=\'guideklara.php\'"
 onMouseOver="this.style.color=\'blue\'; overlib(\'Pågående säsong \(halvår\) eller tidigare.\')"  
 onMouseOut="this.style.color=\'#FFFFFF\'; nd()">Visa hittills guidade</button>
</p>
<p>&nbsp;</p>';
include "guidestats.php";
?>
</td>
<td width="50%" valign="top">
<b>Inbokade tider.</b> Sätt markören över gruppnamnet för att se kontaktperson.<br>
Klicka på gruppnamnet för ändringar m.m.</p>
<?php
setlocale(LC_TIME, 'swedish');
$idag=date("Y-m-d");
$farg='#FFFFFF';
$sql_uppt="SELECT *, guidebokning.grupp, guidebokning.G_ort, guidebokning.Best_namn, guidebokning.Best_tel1 
from besokstider, guidebokning
WHERE besokstider.G_ID=guidebokning.G_ID AND besokstider.G_klar='N'
ORDER BY besokstider.Datum, besokstider.Tid";
$query_uppt=mysqli_query($connect, $sql_uppt) or die(mysqli_error($connect));
if (mysqli_num_rows( $query_uppt) > 0 ){
    echo '<table width="100%" style="cell-padding:3px; border-collapse: collapse">
    <tr height="21" class="tablehead">
    <td width="55">Dag</td><td width="75">Datum</td><td width="50">Tid</td>
    <td width="160">Grupp</td><td width="150">Ort</td></tr>';
    while ($row=mysqli_fetch_assoc($query_uppt)){
        $encoding = 'UTF-8';
        $timestamp = strtotime($row['Datum']); 
        $dag = utf8_encode(strftime("%A", $timestamp));
        $firstChar = mb_substr($dag, 0, 1, $encoding);
        $then = mb_substr($dag, 1, null, $encoding);
        $veckodag = mb_strtoupper($firstChar, $encoding) . $then;        
        
        if ($farg==('#FFFFFF'))
            {$farg='#E1E8F7';}
        else {
            $farg='#FFFFFF';
            
        }
        echo '<tr height="21" bgcolor='.$farg.'> 
        <td width="55">'.$veckodag .'</td><td width="75">'.$row['Datum'].'</td><td width="50">'.  $row['Tid'].'</td>
        <td width="170">
        <a href="guidelistan.php?id='.$row['G_ID'].'"
        onMouseOver="overlib(\''.$row['Best_namn'].'<br>'.$row['Best_tel1'].'\')" 
        onMouseOut="nd()">'.$row['Grupp'].'</a>
        </td><td width="140">'.$row['G_ort'].'</td></tr>';
    }
    echo '</table>';
    } else {
        echo '<b>Inga tider inbokade.</b>';
        
    } 
mysqli_close($connect);
?>
</td>
</tr>
</table>
</body>
</html>