<?php
include '../incl_filer/db_connect.php'; //databasanslutning
setlocale(LC_ALL, 'swedish');
date_default_timezone_set('CET');
?>

<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Bokade tider</title>
    <LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
    <script language="JavaScript" src="../overlib.js">
    </script>
    <script type="text/javascript">
        <!--
        var ol_width = 140; //sätter bredden på popuprutan
        //-->
    </script>
    <style>
        p {
            margin-top: 6px;
            margin-bottom: 6px;
        }
    </style>
</head>


<body class="alt_tab_bg"
">
<div align="center">
    <center>
        <p><b>Inbokade tider.</b></p>
        <p><b>OBS. Dessa tider är redan reserverade för angiven grupp.</b><br>
            Räkna med 1 tim 15 min intervall mellan varje bokningstid.</p>
        <?php
        $idag = date("Y-m-d");
        $farg = '#FFFFFF';
        $sql_uppt = "SELECT Datum, Tid, Grupp from besokstider, guidebokning
WHERE Datum>'$idag' AND besokstider.G_ID=guidebokning.G_ID
ORDER BY Datum, Tid";
        $query_uppt = mysqli_query($connect, $sql_uppt) or die(mysqli_error($connect));

        if (mysqli_num_rows($query_uppt) > 0) {
            echo '<table width="390" style="cell-padding:3px; border-collapse: collapse">
 <tr height="21" class="tablehead">
 <td width="60">Dag</td><td width="85">Datum</td><td width="45">Tid</td>
 <td width="200">Grupp</td>
 </tr>';
            while ($row = mysqli_fetch_assoc($query_uppt)) {
                $encoding = 'UTF-8';
                $timestamp = strtotime($row['Datum']);
                $dag = utf8_encode(strftime("%A", $timestamp));
                $firstChar = mb_substr($dag, 0, 1, $encoding);
                $then = mb_substr($dag, 1, null, $encoding);
                $veckodag = mb_strtoupper($firstChar, $encoding) . $then;
                //$veckodag = ucfirst(strftime("%A", $timestamp));
                if ($farg == ('#FFFFFF')) {
                    $farg = '#E1E8F7';

                } else {
                    $farg = '#FFFFFF';
                }
                echo '<tr height="21" bgcolor=' . $farg . '> 
        <td width="60">' . $veckodag . '</td><td width="85">' . $row['Datum'] . '</td><td width="45">' . $row['Tid'] . '</td>
        <td width="200">' . $row['Grupp'] . '</td>
        </tr>';
            }
            echo '</table>';
        } else {
            echo '<b>Inga tider inbokade.</b>';
        }
        ?>
        <p>
            <button
                    onMouseOver="this.style.color='blue'"
                    onMouseOut="this.style.color='#FFFFFF'"
                    onclick="javascript: window.close()">Stäng
            </button>
        </p>
    </center>
</div>
</body>
</html>
