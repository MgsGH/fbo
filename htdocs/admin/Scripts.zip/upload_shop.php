<?php
include "../incl_filer/db_connect_skofsales.php"; //databasanslutning
/*
Mycket enkelt upload-script av jostor.
F�r anv�ndas fritt.
Ska fungera p� alla PHP-versioner �ver 4.1.0,
och p� de flesta system.
*/
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Language" content="sv">
<title>Ladda upp en fil</title>
<link rel="stylesheet" type="text/css" href="../bluemall.css">
</head>

<body style="background: #F2F5FF">

<?php
/*
if (isset($_FILES['uplfile']))
{	
	  // mappen d�r filerna ska hamna
  	$bildmap=$_REQUEST['bildmapp'];
	$upload_dir='../sales/bilder/'.$bildmap.'/'; 
	
	// De till�tna filtyperna, separerade med komman, utan mellanrum
	$filetypes = 'jpg,gif,png';
	// Den st�rsta till�tna storleken (350 kB)
	$maxsize = (1024*350);

	// Kontrollera att det angavs en fil
	if(empty($_FILES['uplfile']['name']))
		die('Ingen fil har valts');	
		
	// Kontrollera storleken
	if($_FILES['uplfile']['size'] > $maxsize)
		die('Filen du valde �r f�r stor. Maxstorleken �r '.(string)($maxsize/1024).' KB.');

	// Kontrollera filtypen
	$types = explode(',', $filetypes);
	$file = explode('.', $_FILES['uplfile']['name']);
	$extension = $file[sizeof($file)-1];
	if(!in_array(strtolower($extension), $types))
		die('Du har en felaktig filtyp. Endast .jpg, .gif och .png �r till�tna!');

	$thefile = $_FILES['uplfile']['name'];
	
	// Flytta filen r�tt
	if (is_uploaded_file($_FILES['uplfile']['tmp_name']) && move_uploaded_file($_FILES['uplfile']['tmp_name'],$upload_dir.$thefile))
	{
	 echo 'Filen laddades upp! St�ng f�nstret.<br>';
	} 
	else 
	{
	 echo 'Ett fel uppstod och filen kunde inte laddas upp.<br>';
	}
}
else
{  

echo '<b>Ladda upp bilder till ';
 if ($_REQUEST['bildtyp']=='shop_varor')
 {echo 'WEBSHOPEN --- Aktuellt artikelnr: '.$_REQUEST['num'];
  $bildtyp=$_REQUEST['bildtyp'];
  $bildmap=$_REQUEST['mapp'];
  $bildstorlek='att minibilderna ska vara 100 px breda. De stora bilderna ska vara 300 px h�ga.';
  $extext='G�r s� h�r:<br> 
  1. Bl�ddra fram filen som ska laddas upp.<br>
  2. H�gerklicka p� filnamnet och v�lj Byt namn. Notera aktuellt artikelnr (ovan).<br>
  3. Nya namn: artikelnr_stor.jpg f�r stora bilder och artikelnr_mini.jpg f�r sm�.<br>
  4. Ladda upp filen.<br>
  5. St�ng f�nstret.';
 }  
 elseif ($_REQUEST['bildtyp']=='shop_kat')
 {$bildtyp=$_REQUEST['bildtyp']
  $K_nr=$_REQUEST['num'];
  echo 'WEBSHOPEN --- Aktuellt kategorinr: '.$K_nr;

  $sql_mapp="SELECT katnr, bildmapp from sortiment WHERE katnr=$K_nr";
  $query_mapp=mysqli_query($connect, $sql_mapp) or die (mysqli_error($connect));
  if (mysqli_num_rows($query_mapp)==0)
  {
   $varning='<b><i>Bildmapp saknas. Mata in eller �ndra data via formul�ret.</i></b><br>';
  } 
  else
  {
   while ($row = mysqli_fetch_assoc($query_mapp))
   {
    $bildmap=$row['bildmapp'];
    $varning='';
   } 
  } 

  $bildstorlek='bilderna f�r vara h�gst 180 px breda.';
  $extext=$varning.
  'G�r s� h�r:<br> 
  1. Bl�ddra fram filen som ska laddas upp.<br>
  2. Ladda upp filen.<br>
  3. St�ng f�nstret.';
  mysqli_close($connect);
 }  

 echo '
 <p><b>T�nk p�:</b><br>
 att redigera bilderna innan du laddar upp dem.<br> 
 att kontrollera att uppl�sningen �r 72 dpi.<br>
 att minimera filstorleken (anv�nd &quot;Spara f�r webben&quot; i Photoshop).<br>
 att filnamnet f�r <b>inte</b> inneh�lla bokst�verna �,�,�.<br>
 '.$bildstorlek.'</p>
 <form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="multipart/form-data">
 <b>Ange exakt filnamn (inkl. filtyp. t.ex. skatbo.jpg):</b><br>'.$extext.'<br>
 <input type="file" name="uplfile" size="60" style="font-family: Verdana; font-size: 11px">&nbsp;</input><br>
 <input type="hidden" value="'.$bildtyp.'" name="bildkat"></input>
 <input type="hidden" value="'.$bildmap.'" name="bildmapp"></input>
 <p>
 <input type="submit" value="Ladda upp filen" class="submit" 
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"></input>
 </p></form>'; 
}
*/
 $extext='<p><b>G�r s� h�r:</b><br> 
 1. Bl�ddra fram filen som ska laddas upp.<br>
 2. H�gerklicka p� filnamnet och v�lj Byt namn. Notera aktuellt artikelnr (ovan).<br>
 3. Nya namn: artikelnr_stor.jpg f�r stora bilder och artikelnr_mini.jpg f�r sm�.<br>
 4. Ladda upp filen.<br>
 5. St�ng f�nstret.</p>';
 echo '
 <p><b>T�nk p�:</b><br>
 att redigera bilderna innan du laddar upp dem.<br> 
 att kontrollera att uppl�sningen �r 72 dpi.<br>
 att minimera filstorleken (anv�nd &quot;Spara f�r webben&quot; i Photoshop).<br>';
 echo '
 <form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="multipart/form-data">
 '.$extext.'<br>
 <input type="file" name="uplfile" size="60" style="font-family: Verdana; font-size: 11px">&nbsp;</input><br>';
// <input type="hidden" value="'.$bildtyp.'" name="bildkat"></input>
// <input type="hidden" value="'.$bildmap.'" name="bildmapp"></input>
 echo '<p>
 <input type="submit" value="Ladda upp filen" class="submit" 
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'"></input>
 </p></form>'; 
?>

<p> 
<button
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'" 
onclick="javascript: window.close()">St�ng</button>
</p>

<?php
/*
//
//	� Enkelt uppladdnings-skript av RiC]-[iE �
//
//	- skapat 2003.07.26 f�r PHPportalen Wiki -
//

// har formul�ret skickats?
if(isset($_FILES['userfile']))
{
  // mappen d�r filerna ska hamna
  $upload_dir = '/www/root/usr/files/uploads/';
  // de till�tna fil-typerna
  $filetypes = 'jpg,jpeg,gif,png,tif';
  // den st�rsta till�tna storleken ( 500 kB )
  $maxsize = (1024*500);
  
  // kolla om en fil har blivit angedd
  if(empty($_FILES['userfile']['name']))
    die('Du m�ste ange en fil som du vill ladda upp.');
  
  // kolla storleken p� filen
  if($_FILES['userfile']['size'] > $maxsize)
    die('Den st�rsta till�tna filstorleken �r '.round($maxsize / 1024).' kB.');
  
  // h�mta filtypen
  $types = explode(',',$filetypes);
  $file = explode('.',$_FILES['userfile']['name']);
  $extension = $file[sizeof($file)-1];
  // kolla filtypen
  if(!in_array($extension,$types))
    die('Endast filer av typerna '.$filetypes.' f�r laddas upp.');
  
  // flytta filen
  if(is_uploaded_file($_FILES['userfile']['tmp_name']))
    move_uploaded_file($_FILES['userfile']['tmp_name'],$upload_dir.$_FILES['userfile']['name']);
  // skriv ut ett meddelande
  echo "Filen ".$_FILES['userfile']['name']." laddades upp utan problem!";
}
else
{
  // skriv ut formul�ret
  echo "<form action=\"".$_SERVER['PHP_SELF']."\" method=\"post\" enctype=\"multipart/form-data\"/>\n";
  echo "<input type=\"file\" name=\"userfile\"/><br/>\n";
  echo "<input type=\"submit\" value=\"Ladda upp filen\"/>\n";
  echo "</form>\n";
}
*/
?>
</body>
</html>