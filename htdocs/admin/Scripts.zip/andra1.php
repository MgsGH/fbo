<!--DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd" -->
<html lang="sv">

<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-style-type" content="text/css">
<title>�ndra dagbokstext</title>
<link rel="stylesheet" type="text/css" href="../bluemall.css">
<base target="_self">
</head>

<body>
<p align="center">H�r kan du g�ra �ndringar i dagbokstexten. Observera att 
texten �ven inneh�ller htmlkod.
</p>
<p align="center">
<?php
if (isset($_REQUEST['spara']))
 {
 file_put_contents($_REQUEST['path'], $_REQUEST['text']);
 echo '<b>Texten �r sparad med �ndringar.</b> 
 <p align="center">
 <button style="width:120px" onclick=location.href="javascript:window.close();">St�ng f�nstret</button></a>';
 }
 else if (isset($_REQUEST['avbryt']))
 {
 echo '<b>Texten �r sparad utan �ndringar.</b>
 <p align="center">
 <button style="width:120px" onclick=location.href="javascript:window.close();">St�ng f�nstret</button></a>';
 }
else
{$andrtext=$_REQUEST['datum'].'.txt';
$txtdir=substr($andrtext,0,4);
echo
'<form name="andform" method="POST" action="'. $_SERVER['PHP_SELF'].'">
<p align="center">
<textarea name="text" cols="75" rows="25">';
      if (isset($_POST['text']))
      {
      $FIL = fopen('../news/dagbok/'.$txtdir.'/'.$andrtext, 'w') or die('kan inte �ppna filen');
      fwrite($FIL, $_POST['text']);
      fclose($FIL);
      }
      echo implode('',file('../news/dagbok/'.$txtdir.'/'.$andrtext));
echo '</textarea>
<p align="center">
<input type="hidden" name="path" value="../news/dagbok/'.$txtdir.'/'.$andrtext.'">
<input type="submit" name="spara" value="Spara �ndringar" class="submit"> 
<input type="submit" name="avbryt" value="Avbryt" class="submit">
</form>';
 }
 ?>
</body>
</html>