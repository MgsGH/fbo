<?php
include "../incl_filer/db_connect.php"; //databasanslutning
include "guidecounter.php";
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Genomf�rda guidningar</title>
<LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
<script language="JavaScript" src="../overlib.js">
</script>
<script type="text/javascript">
<!--
  var ol_width=140; //s�tter bredden p� popuprutan
//-->
</script>
<style>
p
{
 margin-top: 6px;
 margin-bottom: 6px;
}
</style>
</head>

<body>
<div align="center">
<?php
setlocale(LC_TIME, 'sve');
$sasinfo='S�songerna �r uppdelade halv�rsvis: 1 januari-30 juni resp. 1 juli-31 december.';
if (isset($_REQUEST['visalista'])) 
//om specifik s�song s�kes, kan �ven vara p�g�ende
{echo '<p align="center"><font style="font-size:12px"><b>GENOMF�RDA GUIDNINGAR,
 '.$_REQUEST['season'].' '.$_REQUEST['yer'].'</b></font><br>'.$sasinfo.'</p>';
 $p_year=$_REQUEST['yer'];
//huvudtabell som delar in sidan i tv� spalter
echo '<table width="930" valign="top" style="cell-padding:0; cell-spacing:0; border:0; border-collapse: collapse; 
background: bilder/trans.gif">
<tr><td>';
 if ($_REQUEST['season']=='V�REN')
 {$p_season="1";
  $sql_klar="SELECT *, guidebokning.grupp, guidebokning.G_ort, guidebokning.Best_namn, 
  guidebokning.Best_tel1 
  from besokstider, guidebokning
  WHERE besokstider.G_ID=guidebokning.G_ID AND besokstider.G_klar='J'
  AND substring(besokstider.Datum,1,4)='$p_year'
  AND substring(besokstider.Datum,6,5)>='01-01' and substring(besokstider.Datum,6,5)<='06-30'
  ORDER BY besokstider.Datum, besokstider.Tid";
  //antal guidade
  $sql_booked="SELECT G_klar, SUM(G_antal) AS booked from besokstider  
  WHERE substr(Datum,1,4)='$p_year' AND G_klar='J'
  AND substr(Datum,6,5)>='01-01' AND substr(Datum,6,5)<='06-30'
  GROUP BY G_klar ORDER BY Datum";
  $query_booked=mysqli_query($connect, $sql_booked) or die(mysqli_error($connect));
  while ($row=mysqli_fetch_assoc($query_booked))
  {$guidade_x=$row['booked'];}
 }
 else
 {$p_season="2";
  $sql_klar="SELECT *, guidebokning.grupp, guidebokning.G_ort, guidebokning.Best_namn, 
  guidebokning.Best_tel1  
  from besokstider, guidebokning
  WHERE besokstider.G_ID=guidebokning.G_ID AND besokstider.G_klar='J'
  AND substring(besokstider.Datum,1,4)='$p_year'
  AND substring(besokstider.Datum,6,5)>='07-01' and substring(besokstider.Datum,6,5)<='12-31'
  ORDER BY besokstider.Datum, besokstider.Tid";
//antal guidade
  $sql_booked="SELECT G_klar, SUM(G_antal) AS booked from besokstider  
  WHERE substring(besokstider.Datum,1,4)='$p_year' AND besokstider.G_klar='J'
  AND substring(besokstider.Datum,6,5)>='07-01' AND substring(besokstider.Datum,6,5)<='12-31'
  GROUP BY G_klar ORDER BY Datum";
  $query_booked=mysqli_query($connect, $sql_booked) or die(mysqli_error($connect));
  while ($row=mysqli_fetch_assoc($query_booked))
  {$guidade_x=$row['booked'];}
 }
  $query_klar=mysqli_query($connect, $sql_klar) or die(mysqli_error($connect));
  $numro=mysqli_num_rows($query_klar);
  if ($numro==0)
  {echo '<b>Ingen guidning har genomf�rts under s�songen.</b>';}
  else
  {
 //tabell i v�nstra spalten
 $i_aar=date('Y');
 $i_fjol=$i_aar-1;
 echo '<table width="500" style="cell-padding:3px; border-collapse: collapse">
 <tr height="21" class="tablehead">
 <td width="75">Datum</td>
 <td width="250">Grupp</td><td width="100">Ort</td><td width="30" align="right">Antal</td></tr>';
 $farg='#FFFFFF';
 while ($row=mysqli_fetch_assoc($query_klar))
 {if ($farg==('#FFFFFF'))
  {$farg='#E1E8F7';}
  else
  {$farg='#FFFFFF';}
  echo '<tr height="21" bgcolor='.$farg.'> 
  <td width="75">'.$row['Datum'].'</td>';
  if ($p_year<$i_fjol)
  {echo '<td width="250">'.$row['Grupp'].'</td>';}
  else
  {echo '<td width="250">
   <a href="guidelistan.php?id='.$row['G_ID'].'"
   onMouseOver="overlib(\''.$row['Best_namn'].'<br>'.$row['Best_tel1'].'\')" 
   onMouseOut="nd()">'.$row['Grupp'].'</a></td>';
  } 
  echo '<td width="100">'.$row['G_ort'].'</td>
  <td width="30" align="right">'.$row['G_antal'].'</td></tr>';
 }
 echo '<tr height="21">
 <td><b>Summa</b></td><td><b>Grupper: '.$numro.'</b></td><td width="100"><b>Personer:</b></td>
 <td width="30" align="right"><b>'.$guidade_x.'</b></td></tr></table>';
//vid visning av f�rdiga listor visas  SKRIV UT
 echo
 '<p align="center">
 <button style="width:200px" onclick="location.href=\'guideutskr.php?ar='.$p_year.'&sasong='.$p_season.'\'"
 onMouseOver="this.style.color=\'blue\'" 
 onMouseOut="this.style.color=\'#FFFFFF\'">Utskriftsversion</button>
 </p></td>';
//h�r slutar v�nsterspalten
}
}
else 
//visa p�g�ende s�song
{
echo '<p align="center"><font style="font-size:12px"><b>GENOMF�RDA GUIDNINGAR, P�G�ENDE S�SONG</b></font>
<br>'.$sasinfo.'</p>';
//ta ut data f�r lista - s�songsvis
$idag=date('Y-m-d');
$thisyear=substr($idag,0,4);
$monday=substr($idag,5,5);
if ($monday>='01-01' && $monday<='06-30')
{$sql_klar="SELECT *, guidebokning.grupp, guidebokning.G_ort, guidebokning.Best_namn, guidebokning.Best_tel1 
from besokstider, guidebokning
WHERE besokstider.G_ID=guidebokning.G_ID AND besokstider.G_klar='J'
AND substring(besokstider.Datum,1,4)='$thisyear' AND substring(besokstider.Datum,6,5)>='01-01' and substring(besokstider.Datum,6,5)<='06-30'
ORDER BY besokstider.Datum, besokstider.Tid";}
else
{$sql_klar="SELECT *, guidebokning.grupp, guidebokning.G_ort, guidebokning.Best_namn, guidebokning.Best_tel1 
from besokstider, guidebokning
WHERE besokstider.G_ID=guidebokning.G_ID AND besokstider.G_klar='J'
AND substring(besokstider.Datum,1,4)='$thisyear' AND substring(besokstider.Datum,6,5)>='07-01' and substring(besokstider.Datum,6,5)<='12-31'
ORDER BY besokstider.Datum, besokstider.Tid";}
$query_klar=mysqli_query($connect, $sql_klar) or die(mysqli_error($connect));
$numro=mysqli_num_rows($query_klar);
//huvudtabell
echo '<table width="930" style="cell-padding:0; cell-spacing:0; border:0; border-collapse: collapse; 
background: bilder/trans.gif">
<tr><td valign="top">';
if ($numro==0)
{echo '<b>Ingen guidning har hittills genomf�rts under s�songen.</b>';}
else
{
 //tabell
 echo '<table width="500" style="cell-padding:3px; border-collapse: collapse">
 <tr height="21" class="tablehead">
 <td width="75">Datum</td><td width="50">Tid</td>
 <td width="200">Grupp</td><td width="100">Ort</td><td width="30" align="right">Antal</td></tr>';
 $farg='#FFFFFF';
 while ($row=mysqli_fetch_assoc($query_klar))
 {if ($farg==('#FFFFFF'))
  {$farg='#E1E8F7';}
  else
  {$farg='#FFFFFF';}
  echo '<tr height="21" bgcolor='.$farg.'> 
  <td width="75">'.$row['Datum'].'</td><td width="50">'.$row['Tid'].'</td>
  <td width="170">
  <a href="guidelistan.php?id='.$row['G_ID'].'"
  onMouseOver="overlib(\''.$row['Best_namn'].'<br>'.$row['Best_tel1'].'\')" 
  onMouseOut="nd()">'.$row['Grupp'].'</a>
  </td><td width="100">'.$row['G_ort'].'</td>
  <td width="30" align="right">'.$row['G_antal'].'</td></tr>';
 }
 echo '</table>';
}
echo '</td>';
}
echo '<td align="center" valign="top">';
include "guidestats.php";
?>
<p>
<form method="post" action="guideklara.php">
H�r kan listor fr�n tidigare s�songer (halv�r) v�ljas ut<br>f�r p�seende och utskrift.<br>
V�lj �r: <input type="text" size="4" name="yer"
onMouseOver="overlib('Fr.o.m. (h�sten) 2008.')" onMouseOut="nd()">&nbsp;&nbsp;
V�lj s�song: <input type="radio" style="border:0" value="V�REN" name="season"
onMouseOver="overlib('1 januari-30 juni')" onMouseOut="nd()">V�r&nbsp;&nbsp;
<input type="radio" style="border:0" value="H�STEN" name="season"
onMouseOver="overlib('1 juli-31 december')" onMouseOut="nd()">H�st<p> 
<input type="submit" value="Visa lista" name="visalista" class="submit"
onMouseOver="this.style.color='blue'" onMouseOut="this.style.color='#FFFFFF'">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="reset" value="�terst�ll" name="visainte" class="submit"
onMouseOver="this.style.color='blue'" onMouseOut="this.style.color='#FFFFFF'">
</form>
<p align="center">
<button style="width:230px" onclick="location.href='guidealla.php'"
 onMouseOver="this.style.color='blue'" 
 onMouseOut="this.style.color='#FFFFFF'">Visa sammanst�llning av alla �r</button>
</p>
<p>&nbsp;</p>
<p align="center">
<button style="width:230px" onclick="location.href='guideblock.php'"
 onMouseOver="this.style.color='blue'" 
 onMouseOut="this.style.color='#FFFFFF'">Tillbaka till bokningssidan</button>
</p>
</td></tr></table>
</div>
</body>
</html>

