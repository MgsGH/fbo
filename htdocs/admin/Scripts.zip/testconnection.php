<?php

$connection = getGrylleDbConnection();

$str = '<h1>We are OK</h1>';
if (!$connection){
    $str = '<h1>You have no contact with the database</h1>';
}
echo ($str);


function getGrylleDbConnection(){

    $mysql_server = 'localhost';
    //$mysql_server = 'cpsrv11.misshosting.com';
    $mysql_user = 'cekbkxow_web';
    $mysql_password = '15!ankor';
    $mysql_database = 'cekbkxow_fbodata';

    $connection = mysqli_connect($mysql_server, $mysql_user, $mysql_password, $mysql_database);

    return $connection;

}


function getFboDbConnection(){

    //$mysql_server = 'localhost';
    $mysql_server = 'cpsrv04.misshosting.com';
    $mysql_user = 'hkghbhzh_web';
    $mysql_password = '15!ankor';
    $mysql_database = 'hkghbhzh_fbodata';
    //Detta �r anslutningen till missH p� den nuvarande hemsidan.

    $connection = mysqli_connect($mysql_server, $mysql_user, $mysql_password, $mysql_database);

    return $connection;

}
