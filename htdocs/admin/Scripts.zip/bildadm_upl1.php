<?php 
include "../incl_filer/db_connect.php"; //databasanslutning 
?>
<html>
<head>
<SCRIPT LANGUAGE="JavaScript">
<!-- G�m skriptet
function fonster(URL)
{
//url �r s�kv�gen till filen som �ppnas i f�nstret lankfonster
var oppna = open(URL, "lankfonster", "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, width=600, height=300, top=220, left=288")
}
function openWindow(form) 
{
 var url="upload.php?";
 url += "bildtyp=" + form.typ.value;
 window.open(url, "editwin","toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, left=273, top=157, width=668, height=480");
}

// Sluta g�mma -->
</SCRIPT>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Administration av Bildgalleriet</title>
<LINK REL=STYLESHEET HREF="../bluemall.css" TYPE="text/css">
</head>

<body>
<table width="100%" padding-top="0px">
<tr><td colspan="2" align="center"><p style="margin-bottom:3px"><b>Administration av Bildgalleriet.</b></p></td></tr>
<tr><td width="50%" valign="top">
<b>Steg 1: Ladda upp bilder.</b>
<p>
Innan man laddar upp bilderna skall f�ljande beaktas:<br>
<b>Bildstorlek</b> (standard):<br>
F�r galleriet: 800x438 px<br>
F�r startsidan: 500x300 px (m�ste vara exakt)<br>
Thumbs: 170x93 px<br>
Bilduppl�sning: 72 dpi<br>
Max. filstorlek: 500 Kb<br>
Minimera filstorleken (anv�nd "Spara f�r webben" i Photoshop).</p>
<p>
<b>Bildnamn</b>:<br>
F�r galleriet: 'bildnamn'.jpg <b>OBS: alltid sm� bokst�ver - aldrig �,�,�</b><br>
F�r startsidan: 500_'bildnamn'.jpg (valbart alternativ)<br>
Thumbs: Th_'bildnamn'.jpg<br>
Alla versionerna har s�ledes samma 'bildnamn' (cit.tecken skrivs INTE!).<br>
Obs. Startsidebilder f�r allts� tre versioner, t.ex.<br>
blmes.jpg (galleriet), 500_blmes.jpg (startsida) och Th_blmes.jpg (thumbnail)</p>
<p>
<b>Ladda upp till:</b></p>
<p>
<input type="submit" value="Galleriet" class="submit"
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'"
onclick="javascript:fonster('upload.php?bildtyp=galleri')">
</p><p>
<input type="submit" value="Startsidan" class="submit"
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'"
onclick="javascript:fonster('upload.php?bildtyp=startsida')">
</p><p>
<input type="submit" value="Thumbnails" class="submit"
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'"
onclick="javascript:fonster('upload.php?bildtyp=thumbs')">
</p></td>
<td width="50%" valign="top">
<b>Steg 2: Skriva in bilddata i databasen.<br>
OBS. Bilderna M�STE f�rst laddas upp!
</b>
<Form name="Bilddata" method="POST" action="bildadm2.php">
<b>Ing�r bild f�r startsidan?</b> 
<input type="radio" style="border:0" name="start" value="0"> Nej 
<input type="radio" style="border:0" name="start" value="1"> Ja
<br>
Om Ja:<br>
Kom ih�g att markera Startsidor under Bildkategori nedan!
<p style="margin-top: 4px; margin-bottom: 4px">
<b>Bildkategori:</b><br>
F�r att markera mer �n ett alternativ (t.ex. s�ngare, ringm�rkning):<br> 
H�ll ned CTRL och klicka. Om kategorin saknas i listan - l�gg till 
<a href=javascript:fonster("ny_kategori.php")><b>h�r.</b></a><br>
Uppdatera (F5) sedan denna sida och markera i listan som vanligt.<br>
<select name="kategori[]" multiple style="font-size: 11 px; color: navy"> 
<?php
$katsql="SELECT	* FROM grupper ORDER BY GSYSNR";
$query=mysqli_query($connect, $katsql) or die (mysqli_error($connect));
while($row=mysqli_fetch_assoc($query))
{echo '<option value="'.$row['GruppID'].'">'.$row['Gruppnamn'].'</option>';}
echo '</select><br></p>
<p style="margin-top: 4px; margin-bottom: 4px">
<b>Fotograf</b>:<br> Om fotografen saknas i listan - l�gg till 
<a href=javascript:fonster("ny_fotograf.php")><b>h�r.</b></a><br>
Uppdatera (F5) sedan denna sida och markera i listan som vanligt.<br>
<select name="fotograf" style="font-size: 11 px; color: navy">
<option selected>------ v�lj h�r ------</option>';
$fotsql="SELECT	* FROM fotografer ORDER BY FotID";
$query=mysqli_query($connect, $fotsql) or die (mysqli_error($connect));
while($row=mysqli_fetch_assoc($query))
{echo '<option value="'.$row['FotID'].'">'.$row['Fotograf'].'</option>';}
echo '</select><br>';
// st�ng databaskopplingen 
 mysqli_close($connect);
?>
<p style="margin-top: 4px; margin-bottom: 4px">
<b>Art</b> (RC-kod i VERSALER. Skriv LAND om art saknas, t.ex. vid landskapsbilder):<br>
<input type="text" style="font-size: 11 px; color: navy" size="5" name="artkod"><br>
<b>Datum</b> (����-mm-dd):<br>
<input type="text" style="font-size: 11 px; color: navy" size="10" name="dag"><br>
<b>Plats</b> d�r bilden togs (t.ex. Falsterbo, Nabben):<br>
<input type="text" style="font-size: 11 px; color: navy" size="50" name="plats"><br>
<b>Bildfilens namn</b>:<br>
<input type="text" style="font-size: 11 px; color: navy" size="50" name="bildfil"><br>
<b>Extra info</b> fylls i p� <b>b�da</b> spr�ken alt. <b>b�da</b> l�mnas tomma.<br>
Extra info <b>SVE</b> (�lder, k�n, fynd, speciella omst�ndigheter):
<textarea name="svetext" style="font-size: 11 px; color: navy" cols="75" rows="2" wrap="virtual"></textarea><br>
Extra info <b>ENG</b> (age, sex, record, special circumstances):
<textarea name="engtext" style="font-size: 11 px; color: navy" cols="75" rows="2" wrap="virtual"></textarea>
<p style="margin-top: 3px; margin-bottom: 3px"> 
<input name="Send" type="submit" value="Skicka" class="submit"
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'"> 
<input name="Reset" type="reset" value="�ngra" class="submit"
onMouseOver="this.style.color='blue'" 
onMouseOut="this.style.color='#FFFFFF'"> 
</p>
</form>
</td>
</tr>
</table>
</body>

</html>
