<?php 
include "../incl_filer/db_connect_skofsales.php"; //databasanslutning
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="imagetoolbar" content="no">
<title>Formul�rresultat f�r varulager i webshopen.</title>
<LINK REL=STYLESHEET TYPE="text/css" HREF="../bluemall.css">
<script type="text/javascript" language="JavaScript" 
src="../overlib.js">
</script>
<script type="text/javascript" language="JavaScript">
<!--
 var ol_width=165; //s�tter bredden p� opuprutan
//-->
</script>
</head>

<body style="margin-top: 10px; margin-bottom: 0px; margin-left: 10px; margin-right: 10px;">
<div style="width: 980px; margin-left: auto; margin-right: auto">
<table width="100%" class="alt_tab_bg" cellspacing="0" cellpadding="10">
<tr><td colspan="2" valign="top">
<?php
if (isset($_REQUEST['send_K3']))  // TA BORT KATEGORI och alla varor i kategorin
{
 echo '<p align="center">
 <span style="font-size:18px">
 ***** Borttagning fr�n databasen SkOF-SALES, 
 tabell: '.$_REQUEST['tabell'].', kategori: '.$_REQUEST['kategoritxt'].'. *****
 </span></p>';
 $var_x='sortiment';
 echo 'TA BORT kategori (test)...<br>';
 $kate_bort=$_REQUEST['kategorival'];
 $kate_namn=$_REQUEST['kategoritxt'];
 $kate_bmap=$_REQUEST['bildmapp'];

//TA BORT kategorin fr�n tab sortiment 
 $sql_tabortkat="DELETE from sortiment WHERE katnr='$kate_bort'";
 mysqli_query($connect, $sql_tabort);

//TA BORT bildmapp 
 if (is_dir('../sales/bilder/'.$kate_bmap)==true)
 {
  rmdir ('../sales/bilder/'.$kate_bmap);
 }  

//TA BORT varorna i kategorin
 $sql_tabortvar="DELETE from varor WHERE katnr='$kate_bort'";
  mysqli_query($connect, $sql_tabort);
 echo 'Kategorin <b>'.$katnamn.'</b> har tagits bort fr�n kategorilistan.<br>
 Alla varor i kategorin har tagits bort fr�n varulistan.<br>
 Bildmappen <b>'.$kate_bmap.'</b> med inneh�ll har tagits bort.<br>
 OBS. T.v. m�ste man sj�lv �ndra i menyn t.v. p� f�rs�ljningssidorna.'; 
}
elseif (isset($_REQUEST['send_V3']))  // TA BORT VAROR
{
 echo '<p align="center">
 <span style="font-size:18px">
 ********** Borttagning fr�n databasen SkOF-SALES, tabell: '.$_REQUEST['tabell'].'. **********
 </span></p>
 <table align="center" width="300px" class="alt_tab_bg">
 <tr><td>
 Tar bort artikel nr:<br>';
 $faltrad=$_POST['falten'];
 $falten=explode(' ',$faltrad);
 foreach ($falten AS $vara)
 {
  $sql_admdata="SELECT varor.artnr, varor.katnr, varor.artikel, sortiment.bildmapp FROM varor, sortiment
  WHERE varor.artnr='$vara' AND varor.katnr=sortiment.katnr";
  $query_admdata=mysqli_query($connect, $sql_admdata);
  while ($row=mysqli_fetch_assoc($query_admdata))
  {
   $bildmappen=$row['bildmapp'];
   $artikeln=$row['artikel'];
   echo $vara.' '.$artikeln.' '.$kat.'<br>';
  }

 // ta bort bilder i bildmappen
  $storbild=$vara.'_stor.jpg';
  $litenbild=$vara.'_mini.jpg';
  unlink ('../sales/bilder/'.$bildmappen.'/'.$storbild);
  unlink ('../sales/bilder/'.$bildmappen.'/'.$litenbild); 
 // ta bort varan ur databasen  
  $sql_tabort="DELETE from varor WHERE artnr='$vara'";
  mysqli_query($connect, $sql_tabort);

 } 
 echo '</td></tr></table><p align="center"><b>Varan/varorna har tagits bort! �tg�rden g�r inte att �ngra.</b><p>';
}
?>
</td></tr>
<tr><td colspan="2" valign="top">
<p align="center">
<button style="width:300px" OnClick="location.href='webshop2.php'"
 onMouseOver="this.style.color='blue'" 
 onMouseOut="this.style.color='#FFFFFF'">Tillbaka till startsidan</button></p> 
</p>
</td></tr>
</table></div>
</body>
</html>
